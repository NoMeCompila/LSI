/**
 * DEscripcion: permite crear objetos de tipo rectangulo asi como tambien calcular su area y perimetro a demas de calcular la distancia entre 2 objetos rectangulo
 * 
 * @author (Caballero, Fernando) 
 * @version (1) fecha 29/08/2019
 */
public class Rectangulo{
   //atributos
   private  Punto origen;
   private  double ancho;
   private  double alto;
   
   //setters
   /**
    * Descripcion: Metodo setter para el atributo origen
    * @param recibe un parametro de tipo Punto 
    */
   
   private void setOrigen(Punto p_origen){
       this.origen = p_origen;
    }
   
    /**
     * Descripcion: Metodo setter para el atributo ancho 
     * @param recibe un parametro de tipo double p_ancho (pancho xd)
     */
   
    private void setAncho(double p_ancho){
        this.ancho = p_ancho; //(pancho xddd)
   }
   
   /**
    * Descripcion: Metodo setter para el atributo alto
    * @param recibe un parametro del tipo double p_altura
    */
   
   private void setAltura(double p_alto){
       this.alto = p_alto;
   }
   
   //getters
   
   /**
    * Descripcion: Metodo getter para el atributo origen
    * @return retorna un tipo Punto
    */
   
   public Punto getOrigen(){
       return this.origen;
   }
   
   /**
    *Descripcion: Metodo getter para el atributo ancho 
    * @return retorna un double ancho
    */
   
   public double getAncho(){
       return this.ancho;
   }
   
   /**
    * Descripcion: Metodo getter para el atributo alto  
    * @return retorna un double alto
    */
   public double getAlto(){
        return this.alto;
   }
   
   //constructores
   
   /**
    * Descripcion: Constructor de la clase Rectangulo
    * @param Punto p_origen, double p_ancho, double p_alto
    */
   
   public Rectangulo(Punto p_origen, double p_ancho, double p_alto){
       this.setOrigen(p_origen);
       this.setAncho(p_ancho);
       this.setAltura(p_alto);
   }
   
   /**
    * Descripcion: Costructor sobrecargado de la clase Rectangulo 
    * @paramdouble p_ancho, double p_alto
    */
   
   public Rectangulo(double p_ancho, double p_alto){
       this.setOrigen(new Punto ());
       this.setAncho(p_ancho);
       this.setAltura(p_alto);
   }
   
   //metodos 
   /** 
   * Descripcion: permite desplazar un rectangulo desde su origen sin modificar sus caracteristicas
   * @param recibe 2 parametros double p_dx y double p_dy
   */
    public void desplazar(double p_dx, double p_dy){
        this.getOrigen().desplazar(p_dx,p_dy);
   }
   
   
   /**
    * Descripcion: Permite saber el perimetro de un rectanglo
    * @return retorna un double que será el perimetro del rectangulo
    */  
   public double perimetro(){
       return 2 * this.getAlto() + 2 * this.getAncho();
   }
   
   /**
   * Descripcion: permite calcular la superficie de un rectangulo
   * @return retorna un double la superficie
   */
   public double superficie(){
       return this.getAlto() * this.getAncho();
   }
   
   /**
    * Descripcion: permite mostrar las caracteristicas de un rectangulo
    */
   
   public void caracteristicas(){
       System.out.println("*******RECTANGULO*******");
       System.out.println("Origen: "+this.getOrigen().coordenadas()+" - Alto: "+this.getAlto()+" - Ancho: "+this.getAncho());
       System.out.println("superficie: "+this.superficie());
   }
   
   /**
    * Descripcion: permite saber la distancia entre dos objetos de tipo rectangulo
    * @return retorna un double la distancia entre dos rectangulos
    */
   public double distancia(Rectangulo p_rectangulo){
       return Math.sqrt( (Math.pow(this.origen.getX() - p_rectangulo.origen.getX(),2)) +  (Math.pow(this.origen.getY() - 
       p_rectangulo.origen.getY(),2)));
   }
   
   /**
    * Descripcion: permite saber cual es el mayor entre 2 rectangulos segun su superficie y si son iguales retornara null
    * @return retorna un tipo Rectangulo (el mayor)
    */
   public Rectangulo elMayor(Rectangulo p_rectangulo){
      if(this.superficie() > p_rectangulo.superficie() ){
           return this;
      }else if(this.superficie() < p_rectangulo.superficie()){
           return p_rectangulo;
      }else return null;
   }
   
}
