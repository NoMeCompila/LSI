/**
 * Descripcion:  esta clase permite crear objetos del tipo Paciente a demas de mostrar en pantalla sus datos
 * 
 * @author (Caballero, Fernando) 
 * @version (1) Fecha: 31/08/2019
 */
public class Paciente{
    //Atributos
    private int historiaClinica;
    private String nombre;
    private String domicilio;
    private Localidad localidadNacido;
    private Localidad localidadVive;
    //setters
    
    /**
     * Descripcion: setter para el atributo historiaClinica
     * @param int p_historiaClinica
     */
    private void setHistoriaClinica(int p_historiaClinica){
        this.historiaClinica = p_historiaClinica;
    }
     /**
     * Descripcion: setter para el atributo nombre
     * @param String p_nombre
     */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }    
     /**
     * Descripcion: setter para el atributo domicilio
     * @param String p_domicilio
     */
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }    
     /**
     * Descripcion: setter para el atributo localidadNacido
     * @param Localidad p_localidadNacido
     */
    private void setLocalidadNacido(Localidad p_localidadNacido){
        this.localidadNacido = p_localidadNacido;
    }    
     /**
     * Descripcion: setter para el atributo localidadVive
     * @param Localidad p_localidadVive
     */
    
    private void setLocalidadVive(Localidad p_localidadVive){
        this.localidadVive = p_localidadVive;
    }
    
    //getters
    /**
     * Descripcion: getter para el atributo historiaClinica
     * @return int historiaClinica
     */
    public int getHistoriaClinica(){
        return this.historiaClinica;
    }
     /**
     * Descripcion: getter para el atributo nombre
     * @return String domicilio
     */
    public String getNombre(){
        return this.nombre;
    }
     /**
     * Descripcion: getter para el atributo domicilio
     * @return String domicilio
     */
    public String getDomicilio(){
        return this.domicilio;
    }
     /**
     * Descripcion: getter para el atributo localidadNacido
     * @return Localidad localidadNacido
     */
    public Localidad getLocalidadNacido(){
        return this.localidadNacido;
    }
     /**
     * Descripcion: getter para el atributo localidadVive
     * @return Localidad localidadVive
     */
    public Localidad getLocalidadVive(){
        return this.localidadVive;
    }
    
    //constructor
    /**
     * Descripcion: constructor para los objetos de la clase Paciente
     * @param 
     */
    
    public Paciente(int p_historiaClinica, String p_nombre, String p_domicilio, Localidad p_localidadNacido, Localidad p_localidadVive){
        this.setHistoriaClinica(p_historiaClinica);
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setLocalidadNacido(p_localidadNacido);
        this.setLocalidadVive(p_localidadVive);
    }
    
    //metodos
    /**
     * Descripcion: muestra los datos de un paciente en pantalla
     */
    
    public void mostrarDatosPantalla(){
        System.out.println("Paciente: "+this.getNombre()+"\t Historia Clinica: "+this.getHistoriaClinica()+"\tDomicilio: "
        +this.getDomicilio());
        System.out.println("Localidad: "+this.getLocalidadNacido().getNombre()+"\t Provincia: "+this.getLocalidadVive().getProvincia());
    }
    
    /**
     * Descripcion: muestra los datos de un paciente pero en una sola linea
     */
    
    public String cadenaDeDatos(){
        return this.getNombre()+"\t"+this.getHistoriaClinica()+"\t"+this.getDomicilio()+"\t"+this.getLocalidadNacido().getNombre()+"\t"+
        this.getLocalidadVive().getProvincia();
    }
}
