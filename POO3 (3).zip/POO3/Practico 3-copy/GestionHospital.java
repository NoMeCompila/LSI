import java.util.Scanner;
public class GestionHospital{
    public static void main(String args[]){
        
        
        Scanner teclado = new Scanner(System.in);
        teclado.useDelimiter("\n");
        System.out.println("\nIngrese nombre Hospital");
        String nombreH = teclado.next();
        System.out.println("\nIngrese nombre Director del Hospital");
        String nombreD = teclado.next();
        Hospital hospi = new Hospital(nombreH, nombreD);
        System.out.print("\nIngrese el numero de historia Clinica: ");
        int p_historiac = teclado.nextInt();
        System.out.print("\nIngrese el nombre del paciente: ");
        String p_nom = teclado.next();
        System.out.print("\nIngrese el domicilio del paciente: ");
        String p_dom = teclado.next();
        Localidad loc1 = new Localidad("Santo Tome","Corrientes");  
        Localidad loc2 = new Localidad("Corrientes","Corrientes Capital");
        Paciente p1 = new Paciente (p_historiac, p_nom, p_dom, loc1, loc2);
        hospi.consultaDatosFiliatorios(p1);
        

        /* //inicio instancia Localidad
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese localidad donde nacio: ");
        String locN1 = input.next();
        System.out.println("Ingrese provincia donde vive: ");
        String locV1 = input.next();
        Localidad loc1 = new Localidad(locN1,locV1);
        
        System.out.println("Ingrese localidad donde vive: ");
        String locN2 = input.next();
        System.out.println("Ingrese provincia donde vive: ");
         String locV2 = input.next();
        Localidad loc2 = new Localidad(locN2,locV2);
        //fin instancia Localidad
        
        //inicio instancia Paciente
        System.out.println("Ingrese codigo de historia clinica: ");
        int hist = input.nextInt();
        System.out.println("Ingrese nombre del paciente: ");
        String nom = input.next();
        System.out.println("Ingrese domicilio del paciente: ");
        String dom = input.next();
        Paciente pac = new Paciente(hist,nom,dom,loc1,loc2);
        
        //inicio instancia Hospital
        System.out.println("Ingrese nombre del hospital ");
        String nomH = input.next();
        System.out.println("Ingrese nombre del Dr: ");
        String nomD = input.next();
        Hospital hos = new Hospital(nomH,nomD);
        hos.consultaDatosFiliatorios(pac);
        //fin instancia Hospital
    }*/
    
}}
