import java.util.Random;
public class CrearFigura{
    public static void main(String args  []){
        Punto p0 = new Punto ();
        double a = Double.valueOf(args[0]);
        double b = Double.valueOf(args[1]);
        Punto p1 = new Punto (a,b);
        
        
        Circulo c0 = new Circulo();
        double rad = Double.valueOf(args[2]);
        Circulo c1 = new Circulo(rad,p1);
        
        c1.caracteristicas();
        double c = Double.valueOf(args[3]);
        double d = Double.valueOf(args[4]);
        Punto p2 = new Punto(c,d);
        
        double rad1 = Double.valueOf(args [5]);
        Circulo c3 = new Circulo(rad1,p2);
        System.out.println("Distancia entre los 2 circulos: " +c1.distanciaA(c3));
        
        double e = Double.valueOf(args[6]);
        double f = Double.valueOf(args[7]);
        c1.getCentro().desplazar(e, f);
        c1.caracteristicas();
        
        Punto p3 = new Punto();
        Random unNumero = new Random();
        double radio = unNumero.nextDouble() * 100.0;
        //System.out.println("radio: "+radio);
        
        Circulo c2 = new Circulo(radio, p3); 
        System.out.println("el mayor es: "+c1.elMayor(c2));
        
        
        
        //rectangulo
        
        
    
        double ancho = Double.valueOf(args[2]);
        double alto = Double.valueOf(args[3]);
        Rectangulo r1 = new Rectangulo(p1, ancho, alto);
        r1.caracteristicas();
        Random uunNumero = new Random();
        double  ancho1 = uunNumero.nextDouble() * 100.0;
        double  alto1 = uunNumero.nextDouble() * 100.0;
        Rectangulo r0 = new Rectangulo(p0,ancho1,alto1);
        r0.desplazar(40,-20);
        r0.caracteristicas();
        double  ancho2 = uunNumero.nextDouble() * 100.0;
        double  alto2 = uunNumero.nextDouble() * 100.0;
        Punto p4 = new Punto(7.4,4.5);
        Rectangulo r2 = new Rectangulo(p4,ancho2,alto2);
        r2.caracteristicas();
        
        System.out.println("el mayor es: "+r2.elMayor(r0));
        
        System.out.println("Distancia: "+r0.distancia(r2));
        //{"2","2","4","4"} 
        
        
        
        
        
        
        
        
        
        
        
        
    }
    //{"4","5","6","1","2","3","6","1"}
}
