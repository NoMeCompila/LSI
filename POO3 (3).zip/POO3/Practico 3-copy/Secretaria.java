public class Secretaria{
   public static void main(String args[]){
       Docente doc = new Docente("Elisa Sanchez","Secundario",1600,1290);
       Escuela esc = new Escuela("Manuel Belgrano","Irigoyen 1580","Leopoldo Juez");
       esc.imprimirRecibo(doc);
    }
}
