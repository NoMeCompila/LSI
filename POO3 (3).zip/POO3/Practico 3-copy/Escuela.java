/**
 * Write a description of class Escuela here.
 * 
 * @author (Caballero, Fernando) 
 * @version (1) Fecha(30/08/2019)
 */
public class Escuela{
    //atributos
    private String  nombre;
    private String  domicilio;
    private String  direccion;
    //private Docente p_docente;
    
    //Setters
    
    /**
     * Descripcion: setter para ela tributo nombre 
     * @param String p_nombre
     */
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
     /**
     * Descripcion: setter para el atributo domicilio void 
     * @param String p_domicilio
     */
    private void setDomicilio(String p_domicilio){
        this.domicilio = p_domicilio;
    }
     /**
     * Descripcion: setter para el atributo director
     * @param String p_director
     */
    private  void setDirector(String p_direccion){
        this.direccion = p_direccion;
    }
    
    //getters 
    /**
     * Descripcion: getter para el atributo nombre
     * @return String Nombre
     */
     public String getNombre(){
         return this.nombre;
      }
     /**
     * Descripcion: getter para el atributo 
     * @return String domicilio 
     */
    public String getGrado(){
        return this.domicilio;
    }
     /**
     * Descripcion: getter para el atributo 
     * @return String direccion
     */
    public String getDirecctor(){
        return this.direccion;
    }
    
    //constructor
    /**
     * Descripcion: constructor de objetos de la clase Escuela
     * @param String p_nombre ,String p_domicilio, String p_direccion
     */
    public Escuela(String p_nombre ,String p_domicilio, String p_direccion){
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setDirector(p_direccion);
    }
    
    //metodos
    /**
     * Descripcion: este metodo permite imprimir un recibo de sueldo de un docente
     */
    
    public void imprimirRecibo(Docente p_docente){//tipo concimiento por parametro
        System.out.println("Escuela: "+this.getNombre()+"  Domicilio: "+this.domicilio+"  Director: "
        +this.getDirecctor());//para seguir la norma
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("Docente:    "+p_docente.getNom());
        System.out.println("Sueldo:.....................U$D"+p_docente.calcularSueldo());
        System.out.println("Sueldo Basico:.....................U$D"+p_docente.getSueldoBasico());
        System.out.println("Asignacion Familiar:.....................U$D"+p_docente.getAsignacionFamiliar());
    }
}
