/**
 * descripcion: Esta clase crea objetos del tipo localidad y muestra en pantalla esos datos
 * 
 * @author (Caballero, Fernando) 
 * @version (1) Fecha 31/08/2019
 */
public class Localidad{
   //Atributos 
   private String nombre;
   private String provincia;
   
   //setters
   /**
    * Descripcion: setter para el atributo nombre
    * @param String p_nombre
    */

   private void setNombre(String p_nombre){
       this.nombre = p_nombre;
   }
   
   /**
    * Descripcion: setter para el atributo provincia
    * @param String p_provincia
    */
   
   private void setProvincia(String p_provincia){
       this.provincia = p_provincia;
   }
   
   //getters
   
   /**
    * Descripcion getter para el atributo
    * @return String nombre
    */
   
   public String getNombre (){
       return this.nombre;
   }
   
    /**
    * Descripcion getter para el atributo
    * @return Strung provincia
    */
   
      public String getProvincia (){
         return this.provincia;
   }
   
   
   //constructor
   /**
    * Descripcion: constructor para objetos de la clase localidad
    * @param  String p_nombre, String p_provincia
    */
   
   public Localidad(String p_nombre, String p_provincia){
       this.setNombre(p_nombre);
       this.setProvincia(p_provincia);
   }
   
   //metodos
   /**
    * Descripcion: muetra por pantalla los datos de locaclidad y provincia de un paciente
    */
   public void mostrar(){
       System.out.println("Localidad: "+this.getNombre()+"\tProvincia: "+this.getProvincia());
   }
}
