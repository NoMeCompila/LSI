public class GestionStock{
    public static void main (String args []){
        //objetos
        Laboratorio lab = new Laboratorio("Colgate","Perugorria 228","37940006302", 100, 10);
        Producto prod = new Producto(6969, "Higiene", "dentifrico", 2, lab);
        
        //metodos
        prod.ajuste(500);
        prod.stockValorizado();
        prod.mostrar();
        prod.ajuste(-200);
        prod.mostrar();
        System.out.println("Precio en Lista: U$D "+prod.precioLista());
        System.out.println("Precio al contado: U$D "+prod.precioContado());
    }
}