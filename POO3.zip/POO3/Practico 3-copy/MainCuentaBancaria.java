public class MainCuentaBancaria{
    public static void main(String args[]){
        Persona p1 = new Persona( 35123456, "Juan" , "Perez", 1997);
        CuentaBancaria acc1 = new CuentaBancaria(6969,5000,p1);
        acc1.mostrar();
        System.out.println(acc1.toString());
    }
}
