import java.util.*;
public class MainCuentaBancaria{
    public static void main(String args[]){
        Scanner teclado = new Scanner(System.in);
        System.out.print("\nIngrese el anio de nacimiento de la parsona: ");
        int p_anio=teclado.nextInt();
        System.out.print("\nIngrese el mes de nacimiento de la parsona: ");
        int p_mes=teclado.nextInt();
        System.out.print("\nIngrese el dia de nacimiento de la parsona: ");
        int p_dia=teclado.nextInt();
        Calendar fecha = new GregorianCalendar(p_anio,p_mes,p_dia);
        //muestro la fecha de nacimiento;
        System.out.print("\n\n\t FECHA DE NACIMIENTO: "
                        +fecha.get(Calendar.DATE)+"/"
                        +fecha.get(Calendar.MONTH)+"/"
                        +fecha.get(Calendar.YEAR)+"\n");
        
        Persona p1 = new Persona( 35123456, "Juan" , "Perez", fecha);
        CuentaBancaria acc1 = new CuentaBancaria(6969,5000,p1);
        acc1.mostrar();
        System.out.println(acc1.toString());
    }
}
