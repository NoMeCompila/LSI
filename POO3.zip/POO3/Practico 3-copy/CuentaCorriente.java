/**
 * Descripcion: esta clase permite crear objetos de la clase cuenta corriente y 
 * adminisstrar sus atributos
 * @author (Caballero, Fernando) 
 * @version (1)
 */
public class CuentaCorriente{
    //atribtutos
    private int nroCuenta;
    private double  saldo;
    private double descubrimiento;
    private Persona titular;
    //setters
    
          /**
     * Descripcion: setter para el atributo nroDeCuenta
     * @param recibe un int p_nroDeCuenta
     */    
    private void setNroDecuenta (int p_nroDeCuenta){
        this.nroCuenta=p_nroDeCuenta;
    }
    
    /**
     * Descripcion: setter para el atributo saldo
     * @param recibe un double p_saldo
     */
    private void  setSaldo (double p_saldo){
        this.saldo = p_saldo;
    }
    
     /**
     * Descripcion: setter para el atributo extarccionesPosibles
     * @param recibe un double p_limiteDescubrimiento
     */
    private void  setLimiteDescubrimiento (int p_limiteDescubrimiento){
        this.descubrimiento = p_limiteDescubrimiento;
    }
    
     /**
     * Descripcion: setter para el atributo titular
     * @param recibe un Persona p_titular
     */
    private void  setTitular (Persona p_titular){
        this.titular = p_titular;
    }
    
        //getters
     /**
     * Descripcion: getter para el atributo nroDecuenta
     * @return retorna un int nroDecuenta
     */
    public int getNroDeCuenta(){
        return this.nroCuenta; 
    }
     
    /**
     * Descripcion: getter para el atributo saldo
     * @return retorna un double saldo
     */
    public double getSaldo(){
        return this.saldo; 
    }
    
     /**
     * Descripcion: getter para el atributo descubrimirnto
     * @return retorna un double descubrimiento
     */
    public double getLimiteDescubrimiento(){
        return this.descubrimiento;        
    }  
     /**
     * Descripcion: getter para el atributo titular
     * @return retorna un Persona Titular
     */
    public Persona getTitular(){
        return this.titular; 
    }
    
    //constructores
    /**
     * Descripcion: constructor de objetos de la clase CuentaCorriente
     * @param int p_nroDeCuenta, Persona p_titular
     */
    public CuentaCorriente(int p_nroDeCuenta, Persona p_titular){
        this.setNroDecuenta(p_nroDeCuenta);
        this.setTitular(p_titular);
        this.setSaldo(0);
        this.setLimiteDescubrimiento(500);
    }
    
     /** Descripcion: constructor de objetos de la clase CuentaCorriente
     * @param int p_nroDeCuenta, Persona p_titular, double p_saldo
     */
    
    public CuentaCorriente(int p_nroDeCuenta, Persona p_titular, double p_saldo){
        this.setNroDecuenta(p_nroDeCuenta);
        this.setTitular(p_titular);
        this.setSaldo(p_saldo);
        this.setLimiteDescubrimiento(500);
    }
    
    //metodos
   /**
   * Descripcion: este metodo permite depositar dinero de una cuenta corriente
   * @param recibe un double p_importe
   */
   public void depositar(double p_importe){
        this.setSaldo(this.getSaldo() + p_importe);
   }
   /**
    * Descripcion: permite mostrar en pantalla los datos del titular y su cuente corriete
    */
     public void mostrar(){
      System.out.println("      Cuenta Corriente");
      System.out.println("Nro. Cuenta: "+this.getNroDeCuenta()+" - Saldo: U$D: "+this.getSaldo());
      System.out.println("Titular: "+this.getTitular().nomYApe());
      System.out.println("Descubierto: "+this.getLimiteDescubrimiento());
  }
  
    /**
   * Descripcion: este metodo permite saber si un titular puede extraer o no fondos de su cuenta
   * corriente
   * @param recibe un doble p_imoporte
   * @return retorna un boolean
   */
  
  public boolean puedeExtraer(double p_importe){
      return ((p_importe < this.getSaldo()) && (this.getSaldo() + this.getLimiteDescubrimiento() > p_importe));
  }
  
  /**
  * Descripcion: este metodo permite extraer dinero de una cuenta corriente
  * @param recibe un double p_importe
  */
 
   public void extraccion(double p_importe){
      this.setSaldo(this.getSaldo() - p_importe);
  }
  
  /**
   * Descripcion: estemetodo permite coordinar al metodo puedeExtraer() con extraccion() y realizar 
   * la extraccion o en su defecto mostrar por pantalla el motiv o por el cual no se pudo completar 
   * la operacion
   * 
   * @param recibe un double p_importe
   */
  public void extraer(double p_importe){
      if(this.puedeExtraer(p_importe) && ((this.getSaldo() + this.getLimiteDescubrimiento()) > p_importe)){
        this.extraccion(p_importe);
      }else 
        System.out.println("El importe de extraccion sobrepasa el limite de descuento!");
  }
  
}
