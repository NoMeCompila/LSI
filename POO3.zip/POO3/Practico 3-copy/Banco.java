public class Banco{
    public static void main(String args[]){
        Persona1 p1 = new Persona1( 35123456, "Juan" , "Perez", 1997);
        CajaDeAhorro caja = new CajaDeAhorro(6969,p1,5000);
        
        
        caja.mostrar();
        caja.extraer(300);
        caja.mostrar();
        
        CuentaCorriente cc= new CuentaCorriente(6969,p1,1205);
        cc.mostrar();
    }
}
