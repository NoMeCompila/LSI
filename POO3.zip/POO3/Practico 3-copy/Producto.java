/**
 * Descripcion: 
 * @author (Caballero Fernando) 
 * @version 1 Fecha: 28/08/2019
 */
public class Producto{
    //Atributos
    private int codi;
    private String rubro;
    private String descripcion;
    private double costo;
    private int stock;
    private double porcPtoRepo;
    private int existMin;
    private Laboratorio lab;
    
    //setters
   /**
     * Descripcion:setter para atributo codigo
     * @param recibe un entero p_codi (codigo del producto)
     */
   private void setCodi(int p_codi){
        this.codi   =  p_codi;
   }
   /**
   * Descripcion: setter para atributo rubro
   * @param recibe un String p_rubro (rubro del producto)
     */
    private void setRubro(String p_rubro){
        this.rubro  =   p_rubro;
   }
   /**
    *Descripcion: setter para el atributo descripcion
    *@param recibe una cadena String p_descripcion 
    */
    private void setDescripcion(String p_descri){
        this.descripcion    =   p_descri;
   }
    /**
    *Descripcion: setter para el atributo costo
    *@param recibe un double p_costo (valor del producto)
    */
    
   private void setCosto(double p_costo){
       this.costo   =   p_costo;
   }
   /**
    * descripcion: setter para el atributo stock
    * @param recibe un entero p_stock (reservas del producto)
    */
   private void setStock(int p_stock){
       this.stock   =   p_stock;
   }
   
   /**
    * Descripcion: setter para el atributo porcPtoRepo
    * @param recibe un double p_porcPtoRepo ()
    */
   private void setPorcPtoRepo(double p_porcPtoRepo){
       this.porcPtoRepo =   p_porcPtoRepo;
   }
   
   /**
    * Descripcion: setter del atributo existMin
    * @param recibe un entero p_existMin (cantidad minima de productos en satock)
    */
   private void setExistMin(int p_existMin){
       this.existMin    =   p_existMin;
   }
   
   /**
    * Descripcion: setter del atributo lab
    * @param recibe un dato tipo Laboratorio lab
    */
   private void setLab(Laboratorio  p_lab){
       this.lab =   p_lab;
   }
   
   //getters
   /**
    * descripcion: getter para el atributo codi
    * @return retorna un entero codi (codigo del producto)
    */
   public int getCodi(){
       return this.codi;
   }
   
   /**
    * Descripcion: getter para el atributo rubro
    * @return retorna un String rubro
    */
   public String getRubro(){
       return this.rubro;
   }
   
   /**
    * Descripcion: getter para el atributodescripcion
    * @return retorna una cadena descripcion (del producto)
    */
   public String getDescipcion(){
       return this.descripcion;
   }
   
   /**
    * Descripcion: getter para el atributo costo
    * @return retorna un double costo
    */
   public double getCosto(){
       return this.costo;
    }
    
   /**
    * Descripcion: getter para el atributo stock
    * @return retorna un entero stock
    */
   public int getStock(){
       return this.stock;
    }
    
   /**
    * Descripcion: getter para el atributo porcPtoRepo 
    * @return devueve un double porcPtoRepo
    */
   public double getPorcPtoRepo(){
    return this.porcPtoRepo;
   }
   
   /**
    * Descripcion: getter para el atributo existMin
    * @return retorna un entero existMin
    */
   
   public int getExistMin(){
       return this.existMin;
   }
   
   /**
    * Descripcion: getter para el atributo lab
    * @return retorna un parametro de tipo lab
    */
   public Laboratorio getLab(){
       return this.lab;
    }
    
   //cosntructores

    /**
    * Descripcion: Constructor para la clase Producto
    * @param p_codi, p_rubro, p_descri, p_costo, p_lab
    */
   
   public Producto (int p_codi, String p_rubro, String p_descri, double p_costo, Laboratorio p_lab){
       this.setCodi(p_codi);
       this.setRubro(p_rubro);
       this.setDescripcion(p_descri);
       this.setCosto(p_costo);
       this.setStock(0);
       this.setPorcPtoRepo(0);
       this.setExistMin(0);
       this.setLab(p_lab);
   }
   
    /**
    * Descripcion: Constructor sobrecargado para la clase Producto
    * @param p_codi, p_rubro, p_descri, p_costo, p_porcPtoRepo, p_lab, p_existMin
    */
   public Producto(int p_codi, String p_rubro, String p_descri, double p_costo, double p_porcPtoRepo, int p_existMin,Laboratorio p_lab){
       this.setCodi(p_codi);
       this.setRubro(p_rubro);
       this.setDescripcion(p_descri);
       this.setCosto(p_costo);
       this.setStock(0);
       this.setPorcPtoRepo(p_porcPtoRepo);
       this.setExistMin(p_existMin);
       this.setLab(p_lab);
   }
   //metodos
   /**
    * Descripcion: Muestra en pantalla los datos de un producto
    */
   public void mostrar(){
      System.out.println("\t\t\tINFORMACION SOBRE EL PRODUCTO");//comunicacion 
      System.out.println("*Laborarotio: "+this.getLab().getNom());
      System.out.println("*Domicilio: "+this.getLab().getDom());
      System.out.println("*Telefono: "+this.getLab().getTel());
      System.out.println("*Codigo del producto: "+this.getCodi());
      System.out.println("*Rubro: "+this.getRubro());
      System.out.println("*Descripcion: "+this.getDescipcion());
      System.out.println("*Precio: U$D "+this.getCosto());
      System.out.println("*Stock: "+this.getStock() + " - Stock valorizado: U$D "+this.stockValorizado());
   }
   
   /**
    * Descripcion: permite agregar o quitar cantidad al stock
    */
   public void ajuste(int p_cantidad){
       this.setStock(this.getStock() + p_cantidad);
   }
   
   /**
    * Descripcion: ermite calcular el valor de todos los productos en stock 
    * @return retruna un double valor del stock
    */
   
   public double stockValorizado(){    
       return this.getStock() * (this.getCosto() + (this.getCosto() * 0.12));
   }
   
   /**
    * Descripcion: permite saber el precio del producto en lista es decir loq ue debe pagar el consumidor por el
    * @return retorna un double precio en lista
    */
   
   public double precioLista(){
       return this.getCosto() + (this.getCosto() * 0.12);
   }
   
   /**
    * Descripcion: permite saber cuanto se debe pagar en efectivo
    * @return retorna un double precio al contado
    */
   
   public double precioContado(){
       return this.precioLista() - (this.precioLista() * 0.5);
   }
   
   /**
    * Descripcion: Muestra en pantalla en una sola linea los datos mas relevantes del producto 
    * @return retorna una cadena con los datos importantes de un producto
    */
   
   public String mostrarLinea(){
       return this.getDescipcion()+"\t"+this.getCosto()+"\t"+this.precioContado();
   }
   
   /**
    * Descripcion: este metodo permite modificar la reposicion 
    * @return retorna un double 
    */
   
   public void ajustarPtoRepo(double p_ajustarPtoRepo){
       this.setPorcPtoRepo(p_ajustarPtoRepo);
    }
   
   /**
   * Descripcion: permite modificar la "existencia minima de un producto
   */
   
   public void ajustarExistMin(int p_existMin){
       this.setExistMin(p_existMin);
   }
}

