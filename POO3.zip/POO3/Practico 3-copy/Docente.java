
/**
 * Descripcion: esta clase permite crear y administrar objetos de la clase docente 
 * @author (Caballero, Fernando) 
 * @version (1) Fecha: 30/08/2019
 */
public class Docente{
    //atributos
    private String  nom; 
    private String  grado;
    private  double SuedoBasico;
    private double asignacionFamiliar;
    
    //setters
    /**
     * Descripcion: setter para el atributo nom
     * @param String p_nom
     */
     private void setNom(String p_nom){
         this.nom = p_nom;
     }
    
     /**
     * Descripcion: setter para el atributo grado
     * @param String p_grado
     */
    private void setGrado(String p_grado){
        this.grado = p_grado;
    }
    
     /**
     * Descripcion: setter para el atributo sueldoBasico
     * @param String p_sueldoBasico
     */
    private void setSueldoBasico(double p_sueldoBasico){
        this.SuedoBasico = p_sueldoBasico;
    }
    
     /**
     * Descripcion: setter para el atributo asignacionFamiliar
     * @param ouble p_asignacionFamiliar
     */
    private void setAsignacionFamiliar(double p_asignacionFamiliar){
        this.asignacionFamiliar = p_asignacionFamiliar;
    }
    
    //getters
    /**
     * Descripcion: getter para el atributo nombre
     * @return String nom
     */
    public String getNom(){
        return this.nom;
    }
    
    /**
     * Descripcion: getter para el atributo grado
     * @return Strung grado
     */
    
    public String getGrado(){
        return this.grado;
    }
    /**
     * Descripcion: getter para el atributo sueldoBasico
     * @return double sueldoBasico
     */
    public double getSueldoBasico(){
        return this.SuedoBasico;
    }
    
    /**
     * Descripcion: getter para el atributo asignacionFamiliar
     * @return double asignacionFamiliar 
     */
    
    public double getAsignacionFamiliar(){
        return this.asignacionFamiliar;
    }
    
    
    //constructores
    
    /**
     * Descripcion: constructor para el objeto de clase docente
     * @param 
     */
    
    public Docente(String p_nom, String p_grado, double p_sueldoBasico, double p_asignacionFamiliar){
        this.setNom(p_nom);
        this.setGrado(p_grado);
        this.setSueldoBasico(p_sueldoBasico);
        this.setAsignacionFamiliar(p_asignacionFamiliar);
    }
    
    //metodos
    /**
     * Descripcion: este metodo permite calcular el sueldo de un docente
     * @return retorna un double (el sueldo del docente)
     */
    
    public double calcularSueldo(){
        return  this.getSueldoBasico() + this.getAsignacionFamiliar();
    }
}