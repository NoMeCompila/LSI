/**
 * Descripcion: esta clase genera objetos de la clase  Hombre y ademas se puede visualizar en pantalla
 * sus datos
 * 
 * @author (Cabellero, Fernando) 
 * @version (1) Fecha: 31/08/2019
 */
public class Hombre{
   //atributos
   private String nombre;
   private String apellido;
   private int edad;
   private String estadoCivil;
   private Mujer esposa;
   
   //setters
   /**
    * Descripcion: setter para el atributo  nombre
    * @param String p_nombre
    */
   private void setNombre(String p_nombre){
       this.nombre=p_nombre;
   }
    
   /**
    * Descripcion: setter para el atributo apellido 
    * @param String p_apellido
    */
   private void setApellido(String p_apellido){
       this.apellido=p_apellido;
   }
   /**
    * Descripcion: setter para el atributo  edad
    * @param int p_edad
    */
    private void setEdad(int p_edad){
       this.edad=p_edad;
   }
   /**
    * Descripcion: setter para el atributo estado civil 
    * @param String p_estadoCivil
    */
   private void setEstadoCivil(String p_estadoCivil){
       this.estadoCivil=p_estadoCivil;
   }
    /**
    * Descripcion: este metodo permite establecer un vinculo conyugal con una pareja
    * @param Hombre p_esposo
    */
   private void setEsposa(Mujer p_esposa){
       this.esposa=p_esposa;
   }
   
   //getters
   /**
    * Descripcion: getter para el atributo nombre
    * @return String nombre
    */
   public String getNombre(){
       return this.nombre;
   }
    
    /**
    * Descripcion: getter para el atributo apellido
    * @return String apellido
    */
   public String getApellido(){
       return this.apellido;
   }
    
    /**
    * Descripcion: getter para el atributo edad
    * @return int edad
    */
   public int getEdad(){
       return this.edad;
   }
    
    /**
    * Descripcion: getter para el atributo estado civil
    * @return String estado civil
    */
   public String getEstadoCivil(){
       return this.estadoCivil;
   }
      /**
    * Descripcion:  getter para el atributo esposa
    * @return Hombre esposo;
    */
   private Mujer getEsposa(){
       return this.esposa;
   }
    
    //constructores
    /**
     * Descripcion: constructor de objetos de la clase Hombre
     * @param String p_nombre, String p_apellido, int edad
     */
   public Hombre(String p_nombre, String p_apellido, int p_edad){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEstadoCivil("Soltero");
   }
   
    /**
     * Descripcion: constructor de objetos de la clase Hombre
     * @param String p_nombre, String p_apellido, int edad
     */
   public Hombre(String p_nombre, String p_apellido, int p_edad, Mujer p_esposa){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEstadoCivil("Soltero");
   }
   
   //metodos
   
      /**
    * Descripcion: este metodo permite crear una relacion conyugal con su pareja
    */
   public void casarseCon(Mujer p_esposa){
       if((this.getEsposa()==null)&&(p_esposa.getEstadoCivil()!= "casada")){
           this.setEsposa(p_esposa);
           p_esposa.casarseCon(this);
           this.setEstadoCivil("casado");
       }
   }
    /**
     * Descripcion: este metodo permite realizar un divorcio sobre el objeto mujer
     * @param Mujer p_esposa
     */
   public void divorcio(Mujer p_esposa){
        if ((this.getEsposa() == p_esposa)&&( p_esposa.getEstadoCivil() == "casada")){
            this.setEstadoCivil("Divorciado");
            p_esposa.divorcio(this);
            this.setEsposa(null); 
        }
   }
   
   /**
    * Descripcion: este metodo permite mostrar en pantalla los datos de un objeto clase hombre 
    */
   
   public void datos(){
       System.out.println(this.getNombre()+" "+this.getApellido()+" de "+this.getEdad()+" años");
   }
   
   /**
    * Descripcion: permite obtener el estado civil del objeto
    */
   
   
   /**
    * Descripcion: permite mostrar en pantalla con quien esta casado el objeto de ser asi el caso
    */
   public void casadoCon(){
       if(this.getEstadoCivil()=="casado"){
           System.out.println(this.getNombre()+" "+this.getApellido()+" de"+this.getEdad()+
           " años esta casado con "+this.getEsposa().getNombre()+" "
           +this.getEsposa().getApellido()+" de "+this.getEsposa().getEdad()+" años");
       }else 
            System.out.println(" No esta casado");
   } 
   
   public void mostrarEstadoCivil(){
       System.out.println(this.getNombre()+" "+this.getApellido()+" esta "+this.getEstadoCivil()+" con "+this.getEsposa().getNombre()+" "+
       this.getEsposa().getApellido() );
   }
}