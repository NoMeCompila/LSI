public class RegistroCivil{
    public static void main(String args[]){
        
        
        Hombre H = new Hombre("Juan","Perez",27);
        Mujer M = new Mujer("Maria","Gomez",25);
       
       H.casarseCon(M);
        
       M.datos();
       System.out.println(M.getEstadoCivil());
       H.datos();
       System.out.println(H.getEstadoCivil());
       
       
       
       M.mostrarEstadoCivil();
       H.mostrarEstadoCivil();
        
    }
}
