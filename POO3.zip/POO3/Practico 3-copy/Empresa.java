import java.util.*;
public class Empresa{
    public static void main(String args[]){
        Calendar fecha = new GregorianCalendar(10,9,1995);
        Calendar fecha1 = new GregorianCalendar(10,9,1995);
        Empleado emp1 = new Empleado(12345,"Perez","Juan",500,1997);
        emp1.mostrar();
        emp1.aniversario();
        EmpleadoConJefe jef = new EmpleadoConJefe(567,"Bulgheri", "Gregorio",800,fecha1);
        EmpleadoConJefe emp2=new EmpleadoConJefe(4321,"Ramirez","Daiana",500,fecha, jef);
        jef.mostrar();
        emp2.mostrar();
    }
}
