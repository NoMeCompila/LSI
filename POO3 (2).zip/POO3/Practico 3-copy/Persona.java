import java.util.*;
/**
 * Descripcion: esta clase genera objetos en el cual se puede manipular y ver el saldo de los clientes  
 * @author Caballero, Fernando
 * @version 1 Fecha: 26/08/2019
 */
public class Persona{
    private int nroDni;
    private String nombre;
    private String apellido;
    private int anioNacimiento;

    //setters
    /**
     * descripcion: metodo setter para Dni
     * @param recibe un parametro de tipo entero p_dni
     */
    private void setnroDni(int p_dni){
        this.nroDni=p_dni;
    }
    
     /**
     * descripcion: metodo setter para anio
     * @param recibe un parametro de tipo entero p_anio
     */
    private void setAnioNacimiento(int p_anio){
        this.anioNacimiento=p_anio;
    }
    
     /**
     * descripcion: metodo setter para nombre
     * @param recibe un parametro de tipo String p_nombre
     */
    private void setNombre(String p_nombre){
        this.nombre=p_nombre;
    }
     /**
     * descripcion: metodo setter para apellido
     * @param recibe un parametro de tipo String p_apellido
     */
    private void setApellido(String p_apellido){
        this.apellido=p_apellido;
    }

    //getters
     /**
     * descripcion: metodo getter para dni
     * @return devuelve un entero nroDni
     */
    public int getNroDni(){
        return this.nroDni;
    }
    
     /**
     * descripcion: metodo getter para nombre
     * @return devuelve un String nombre
     */
    public String getNombre(){
        return this.nombre;
    }
    
     /**
     * descripcion: metodo getter para apellido
     * @return devuelve un String apellido
     */
    public String getApellido(){
        return this.apellido;
    }
    
     /**
     * descripcion: metodo getter para anioNacimiento
     * @return devuelve un entero anioNacimiento
     */
    public int getAnioNacimiento(){
        return this.anioNacimiento;
    }

    /**
     * descripcion: constructor para los objetos de clase Persona
     */
    //constructor
    public Persona(int p_dni, String p_nombre, String p_apellido, int p_anio){
        
        this.setnroDni(p_dni);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setAnioNacimiento(p_anio);
    }

    //metodos
    /**
     * Descripcion: este método cacula la edad de una persona en funcion del año actual y su año de nacimiento 
     * @return retorna un entero anios
     */
    
    public int edad(){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        int anios = anioHoy - this.getAnioNacimiento();
        return anios;
    }

    /**
     * Descripcion: metodo que retorna una cadena de caracteres con el apellido y nombre de una persona
     * @return ape y nom en una cadena de string
     */
    public String apeYNom(){
        return this.getApellido() + " " + this.getNombre();
    }

     /**
     * Descripcion: metodo que retorna una cadena de caracteres con el nombre y apellido de una persona
     * @return nom y ape en una cadena de string
     */
    public String nomYApe(){
        return this.getNombre() + " " + this.getApellido();
    }

    /**
     * Descripcion: este metodo muestra en pantalla los datos de una persona 
     */
    public void mostrar(){
        System.out.println("Los datos de la persona son: ");
        System.out.println(this.nomYApe() + "\nDNI: "+this.getNroDni() +"\tEdad: "+this.edad() + " "+ "años");
    }
    
}