import java.util.*;
/**
 * description: permite crear objetos de calse Alojamiento
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public abstract class Alojamiento{
    //atributos
    private String nombre;
    private double precioBase;
    private int diasAlquiler;
    private ArrayList <Servicio> servicios;
    //constructor que recibe el primer elemento
    public Alojamiento(String p_nombre, double p_precioBase, int p_diasAlquiler, Servicio p_servicio){
        this.setNombre(p_nombre);
        this.setPrecioBase(p_precioBase);
        this.setDiasAlquiler(p_diasAlquiler);
        this.setServicios(new ArrayList <Servicio>());
        this.agregarServicio(p_servicio);
    }
    
    //constructor que se usa cuando ya tiene algun elemento 
    public Alojamiento(String p_nombre, double p_precioBase, int p_diasAlquiler, 
                       ArrayList <Servicio> p_servicio){
        this.setNombre(p_nombre);
        this.setPrecioBase(p_precioBase);
        this.setDiasAlquiler(p_diasAlquiler);
        this.setServicios(p_servicio);
    }
    //getter y setters
    private void setNombre(String p_nombre){
        this.nombre=p_nombre;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    private void setPrecioBase(double p_precioBase){
        this.precioBase=p_precioBase;
    }
    
    public double getPrecioBase(){
        return this.precioBase;
    }
    
    private void setDiasAlquiler(int p_diasAlquiler){
        this.diasAlquiler=p_diasAlquiler;
    }
    
    public int getDiasAlquiler(){
        return this.diasAlquiler;
    }
    
    private void setServicios(ArrayList <Servicio> p_servicios){
        this.servicios=p_servicios;
    }
    
    public ArrayList <Servicio> getServicios(){
        return this.servicios;
    }
    
    //agregar y quitar de la coleccion
    public boolean agregarServicio(Servicio p_servicio){
        return this.getServicios().add(p_servicio);
    }
    
    public boolean quitarServicio(Servicio p_servicio){
        return this.getServicios().remove(p_servicio);
    }
    
    //metodos
    /**
     * descripcion: con este metodo se puede saber cuantas cabañas o habitaciones de hotel estan 
     * alquilados
     * @return int  
     */
    public abstract int contar(String p_alojamiento);
    
    /**
     * descripcion: permite saber el costo de un alojamiento
     * @return double costo
     */
    public double costo(){
        return this.getPrecioBase() * this.getDiasAlquiler();
    }
    
    /**
     * descripcion: permite listar todos los servicios contratados y sus caracteristicas 
     */
    
    public void listarServicios(){
        for(Servicio s1 : this.getServicios()){
            System.out.println("Descripcion: " + s1.getDescripcion() + "  - Precio: " + s1.getPrecio());            
        }
    }
    
    /**
     * descripcion: suma el total de costo de todos los servicios contratados
     */
    public double costoServicios(){
        double totServicios=0;
        for(Servicio s1 : this.getServicios()){
            totServicios+=s1.getPrecio();
        }
        return totServicios;
    }
    
    /**
     * descripcion: premite mostrar las caracteristicas basicas de un alojamiento 
     */
    
    public void liquidar(){
        System.out.println("Alojamienmto: " + this.getNombre());
        System.out.println("Alojamiento por " + this.getDiasAlquiler() + " dias: U$D" + this.costo());
        this.listarServicios();        
    }
}
