/**
 * description:permte crear cajas de ahorros extendidas de la clase abstracta CuentaBancaria
 * @author Caballer, Fernando
 * @version 1.0
 */
public class CuentaCorriente extends CuentaBancaria{
    private double limiteDescubierto;
    
    //costructores
  
    public CuentaCorriente(int p_nroDeCuenta, Persona p_titular, double p_limiteDescubierto){
        super(p_nroDeCuenta,p_titular);
        this.setLimiteDescubierto(p_limiteDescubierto);
    }
    
    public CuentaCorriente(int p_nroDeCuenta,double p_saldo,Persona p_titular, double p_limiteDescubierto){
       super(p_nroDeCuenta,p_saldo,p_titular);
       this.setLimiteDescubierto(p_limiteDescubierto);
    }
      
    //getters ys etters 
    
    private void setLimiteDescubierto(double p_limiteDescubierto){
        this.limiteDescubierto = p_limiteDescubierto;
    }
    
    public double getLimiteDescubierto(){
        return this.limiteDescubierto;
    }
    //***********************************METODOS*****************************************************
    public boolean puedeExtraer(double p_importe){
        return ((p_importe < this.getSaldo()) && (this.getSaldo() + this.getLimiteDescubierto() > 
               p_importe)); 
    }
    
    public void extraccion(double p_importe){
      this.setSaldo(this.getSaldo() - p_importe);
    }
    
    public void extraer(double p_importe){
      if(this.puedeExtraer(p_importe) && ((this.getSaldo() + this.getLimiteDescubierto()) > p_importe)){
        this.extraccion(p_importe);
      }else 
        this.xQNoPuedeExtraer();
    }
    
    public String xQNoPuedeExtraer(){
           return "El importe de extraccion sobrepasa el limite de descuento!";
    }
    
    public void mostrar(){
        System.out.println("\n**********CUENTA CORRIENTE**********");
        super.mostrar();
    }
}
