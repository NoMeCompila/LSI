/**
 * description: esta clase permite crear Triangulos
 * @author Caballero, Fernando
 * @version 1.0
 */
public class MiTriangulo extends Figura{
    //constructores
    public MiTriangulo(Punto p_origen, double p_ancho, double p_alto){
        super(p_origen,p_ancho,p_alto);
    }
    
        public MiTriangulo(double p_ancho, double p_alto){
        super(p_ancho,p_alto);
    }
    //metodos
    public String nombreFigura(){
        return "****Triangulo****";
    }
    
    public double superficie(){
        return (this.getAlto() * this.getAncho())/2;
    }
    
    
}
