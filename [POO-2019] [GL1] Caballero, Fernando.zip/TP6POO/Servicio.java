/**
 * description: permite crear objetos de la clase servicio
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Servicio{
    //atributos
    private String descripcion; 
    private double precio;    
    //cosntructor
    public Servicio(String p_descripcion, double p_precio){
        this.setDescripcion(p_descripcion);
        this.setPrecio(p_precio);
    }
    //getters y setters
    private void setDescripcion(String p_descripcion){
        this.descripcion=p_descripcion;
    }
    
    public String getDescripcion(){
        return this.descripcion;
    }
    
    private void setPrecio(double p_precio){
        this.precio=p_precio;
    }
    
    public double getPrecio(){
        return this.precio;
    }
    //metodos
    
}
