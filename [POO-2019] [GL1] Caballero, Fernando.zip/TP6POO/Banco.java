import java.util.*;
public class Banco{
    public static void main(String args[]){
        // CAJA DE AHORRO
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese el anio de nacimiento de la parsona: ");
        int p_anio=teclado.nextInt();
        System.out.print("\nIngrese el mes de nacimiento de la parsona: ");
        int p_mes=teclado.nextInt();
        System.out.print("\nIngrese el dia de nacimiento de la parsona: ");
        int p_dia=teclado.nextInt();
        Calendar fecha = new GregorianCalendar(p_anio,p_mes,p_dia);
        //muestro la fecha de nacimiento;
        System.out.print("FECHA DE NACIMIENTO: "
                        +fecha.get(Calendar.DATE)+"/"
                        +fecha.get(Calendar.MONTH)+"/"
                        +fecha.get(Calendar.YEAR));
        Persona p1 = new Persona( 35123456, "Juan" , "Perez", fecha);
        CajaDeAhorro caja = new CajaDeAhorro(1111,500,p1,3);
        
        
        caja.mostrar();
        caja.extraer(300);
        caja.mostrar();
        //FIN CAJA DE AHORRO
        
        //CUENTA CORRIENTE
                
        System.out.print("Ingrese el anio de nacimiento de la parsona: ");
        int p_anio1=teclado.nextInt();
        System.out.print("\nIngrese el mes de nacimiento de la parsona: ");
        int p_mes1=teclado.nextInt();
        System.out.print("\nIngrese el dia de nacimiento de la parsona: ");
        int p_dia1=teclado.nextInt();
        Calendar fecha1 = new GregorianCalendar(p_anio1,p_mes1,p_dia1);
        System.out.print("FECHA DE NACIMIENTO: "
                        +fecha1.get(Calendar.DATE)+"/"
                        +fecha1.get(Calendar.MONTH)+"/"
                        +fecha1.get(Calendar.YEAR));
        Persona p2 = new Persona( 40982473, "Fernando" , "Caballero", fecha1);
        CajaDeAhorro caja2 = new CajaDeAhorro(2222,1000,p2,3000);
        
        caja2.mostrar();
        caja2.extraer(100);
        caja2.mostrar();
    }
}
