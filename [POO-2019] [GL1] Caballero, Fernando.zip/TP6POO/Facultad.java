import java.util.*;
/**
 * description: clase para crear objetos de la clase Facultad  
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Facultad{
    //atributos
    private String nombre;
    private ArrayList <Profesor> profesores;
    
    //constructor
    public Facultad(String p_nombre, ArrayList p_profesores){
        this.setNombre(p_nombre);
        this.setProfesores(p_profesores);
    }
    
    //getters y setters
    public String getNombre(){
        return this.nombre;
    }
    
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    public ArrayList <Profesor> getProfesores(){
        return this.profesores;
    }
    
    private void setProfesores(ArrayList <Profesor> p_profesores){
        this.profesores = p_profesores;
    }
    
    //agregar y quitar objetos de la coleccion
    public boolean agregarProfesor(Profesor p_profesor){
        return this.getProfesores().add(p_profesor);
    }
    
    public boolean  quitarProfesor(Profesor p_profesor){
        return this.getProfesores().remove(p_profesor);
    }
    
    //metodos
    /**
     * descripcion: permite listar los datos basicos de un profesor
     */
    public void nominaProfesores(){
        System.out.println("*************** Nómina Facultad: FaCENA");
        System.out.println("---------------------------------------");
        
        for(Profesor p1 : this.getProfesores()){
            System.out.println("DNI: " + p1.getNroDni() + " Nombre y Apellido: " + p1.nomYApe()
            + " - Sueldo total: " + p1.sueldoTotal());
        }
    }
    public void listarProfesorCargos(){
        System.out.println("****Detalle de profesores y cargos de la Facultad:"+this.getNombre());
        for(Profesor p2 : this.getProfesores()){
            p2.mostrar();            
        }
    
    }
}
