import java.util.*;
/**
 * descripcion: permite crear objetos abstractos de objetos de la clase visitante
 * 
 * @author Caballero, Fernando
 * @version 1.0
 */
public abstract  class Visitante{
   //atributos para la clase abstracta Visitante
   private String nombre;
   private Calendar fechaVisita; 
   //constructores
   public Visitante(String p_nombre, Calendar p_fecha){
        this.setNombre(p_nombre);
        this.setFechaVisita(p_fecha);
   }
    //getters and setters
   private void setNombre(String p_nombre){
        this.nombre=p_nombre;
   }
    
    public String getNombre(){
        return this.nombre;
   }
    
   private void setFechaVisita(Calendar p_fechaVisita){
        this.fechaVisita=p_fechaVisita;
   }
    
   public Calendar getFechaVisita(){
        return this.fechaVisita;
   }
    
    //metodos
   /**
    * descripcion: muestra los datos de un visitante
    */
   public abstract void mostrar();
    
   public abstract double entrada();
    
   public abstract void listarPorFecha(Calendar p_fecha, String p_visitante);
    
   public abstract String tipoVisitante();
}
