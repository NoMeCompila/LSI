import java.util.*;
/**
 * description: Crea objetos de clase jardin para saber cuantos litros y latas de pintura se necesitan
 * para pintar figuras geometricas en el piso 
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Jardin{
    //atributos
    private String nombre;
    private ArrayList <Figura> figuras;
    
    //constructores
    public Jardin(String p_nombre, Figura p_figuras){//cuando recibe el 1er elemento
        this.setNombre(p_nombre);
        this.setFiguras(new ArrayList <Figura> ());
        this.agregarFigura(p_figuras);
    }
    
    public Jardin(String p_nombre, ArrayList <Figura> p_figura){
        this.setNombre(p_nombre);
        this.setFiguras(p_figura);
    }
    
    //getter y setters
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    private void setFiguras(ArrayList <Figura> p_figuras){
        this.figuras = p_figuras;
    }
    
    public ArrayList <Figura> getFiguras(){
        return this.figuras;
    }
    
    //metodos para agregar y quitar figuras de la coleccion
    
    public boolean agregarFigura(Figura p_figura){
        return this.getFiguras().add(p_figura);
    }
    
    public boolean quitarFigura(Figura p_figura){
        return this.getFiguras().remove(p_figura);
    }
    
    //metodos
    private double cuantosLitros(){
        return this.cuantasLatas() * 4;        
    }
    
    public double cuantosMetros(){
        double totMetros=0;
        for(Figura f1 : this.getFiguras()){
            totMetros += f1.superficie(); 
        }
        return totMetros;
    }
    
    public int cuantasLatas(){
        return (int) this.cuantosMetros() / 20;         
    }
    
    public void detalleFiguras(){
        for(Figura f1 : this.getFiguras()){
            f1.caracteristicas();
        }
        System.out.println("Total a cubrir: " + this.cuantosMetros() + " Metros cuadrados");
        System.out.println("Comprar: " +this.cuantasLatas() );
    }
}
