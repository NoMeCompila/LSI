import java.util.*;
/**
 * description: permite crear objetos del tipo cabaña que son una extension de la calse Alojamiento 
 * 
 * @author Caaballero, Fernando
 * @version 1.0
 */
public class Cabaña extends Alojamiento{
    //atributo
    private int nroHabitaciones;
    //constructor cuando recibe el primer elemento 
    public Cabaña(String p_nombre, double p_precioBase, int p_diasAlquiler, Servicio p_servicio,int p_nroHabitaciones){
        super(p_nombre,p_precioBase,p_diasAlquiler,p_servicio);
        this.setNroHabitaciones(p_nroHabitaciones);
    }
    //constructor para cuando ya hay elementops en la coleccion 
    public Cabaña(String p_nombre, double p_precioBase, int p_diasAlquiler, 
                  ArrayList <Servicio> p_servicios, int p_nroHabitaciones){
        super(p_nombre,p_precioBase,p_diasAlquiler,p_servicios);
        this.setNroHabitaciones(p_nroHabitaciones);
    }
    
    //getter y setter
    private void setNroHabitaciones(int p_nroHabitaciones){
        this.nroHabitaciones=p_nroHabitaciones;
    }
    
    public int getNroHabitaciones(){
        return this.nroHabitaciones;
    }
    
    //metodos
    /**
     * descripcion: calcula el costo de una cabaña
     */
    public double costo(){
        return (this.getNroHabitaciones() * 30 * this.getDiasAlquiler()) + super.costo(); 
    }
    
    /**
     * descripcion: cuenta las cabañas que hay e la coleccion
     */
    public int contar(String p_alojamiento){
        if(p_alojamiento.equals("Cabaña")){
            return 1;
        }else return 0;
    }
    
    /**
     * descripcion: permite saber los datos de una cabaña y ver sus costos
     */
    public void liquidar(){
        super.liquidar();
        System.out.println("Cabaña con: " + this.getNroHabitaciones() + " Habiotaciones");
        System.out.println("Total: --------> U$D"+this.costo());
    }
}
