/**
 * description: esta clase permite crear Rectangulos
 * @author Caballero, Fernando
 * @version 1.0
 */
public class MiCuadrado extends MiRectangulo{
    //constructores
    public MiCuadrado(Punto p_origen, double p_ancho, double p_alto){
        super(p_origen,p_ancho,p_alto);
    }
    
        public MiCuadrado(double p_ancho, double p_alto){
        super(p_ancho,p_alto);
    }
    //metodos
    public String nombreFigura(){
        return "****Cuadrado****";
    }
    
    public double superficie(){
        return this.getAlto() * this.getAncho();
    }  
}
