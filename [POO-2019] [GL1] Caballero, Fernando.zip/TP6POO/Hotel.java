import java.util.*;
/**
 * description: esta clase permite crear objetos del tipo Hotel que se extiende de la 
 * superclase Alojamiento
 * 
 * @author caballero, Fernando
 * @version 1.0
 */
public class Hotel extends Alojamiento{
    //atributo
    private String tipoHabitacion;
    //constructor cuando recibe el primer elemento en la coleccion
    public Hotel(String p_nombre, double p_precioBase, int p_diasAlquiler, Servicio p_servicio, String p_tipoHabitacion){
        super(p_nombre, p_precioBase, p_diasAlquiler, p_servicio);
        this.setTipoHabitacion(p_tipoHabitacion);
    }
    //costructor para cuando ya se tienen objetos en la coleccion
    public Hotel(String p_nombre, double p_precioBase, int p_diasAlquiler,ArrayList <Servicio> p_servicios,String p_tipoHabitacion ){
        super(p_nombre, p_precioBase, p_diasAlquiler, p_servicios);
        this.setTipoHabitacion(p_tipoHabitacion);
    }
    //getter and setter
    private void setTipoHabitacion(String p_tipoHabitacion){
        this.tipoHabitacion=p_tipoHabitacion;
    }
    
    public String getTipoHabitacion(){
        return this.tipoHabitacion;
    }
    
    //metodos
    /**
     * descripcion: permite saber el costo de 
     */
    public double costo(){
        double cos=0;
        if(this.getTipoHabitacion().equals("Single")){
            cos= (20 * this.getDiasAlquiler()) + super.costo();
        }else if(this.getTipoHabitacion().equals("Doble")){
            cos= (35 * this.getDiasAlquiler()) + super.costo();  
        }
        return cos;
    }
    
    /**
     * permite contar la cantidad de alojamientos de tipo hotel
     * @return int
     */
    public int contar(String p_alojamiento){
        if(p_alojamiento.equals("Hotel")){
            return 1;
        }else return 0;
    }
    
    /**
     * descripcion: permite visualizar las acaracteristicas del hotel
     */
    
    public void liquidar(){
        super.liquidar();
        System.out.println("Habitacion: " + this.getTipoHabitacion());
        System.out.println("Total: --------> U$D"+this.costo());
    }
}
