/**
 * description: esta clase permite crear Rectangulos
 * @author Caballero, Fernando
 * @version 1.0
 */
public class MiRectangulo extends Figura{
    //constructores
    public MiRectangulo(Punto p_origen, double p_ancho, double p_alto){
        super(p_origen,p_ancho,p_alto);
    }
    
        public MiRectangulo(double p_ancho, double p_alto){
        super(p_ancho,p_alto);
    }
    //metodos
    public String nombreFigura(){
        return "****Rectangulo****";
    }
    
    public double superficie(){
        return this.getAlto() * this.getAncho();
    }
    
    
}
