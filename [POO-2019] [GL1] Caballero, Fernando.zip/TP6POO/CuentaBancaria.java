/**
 * Descripcion: esta clase permite crear objetos de la clase cuenta corriente y 
 * adminisstrar sus atributos
 * @author (Caballero, Fernando) 
 * @version (1)
 */
public abstract class CuentaBancaria{
  //atribtutos
  
  private int nroCuenta;
  private double  saldo;
  private Persona titular;
  
  //setters    
   /**
   * Descripcion: setter para el atributo nroDeCuenta
   * @param recibe un int p_nroDeCuenta
   */    
  private void setNroDecuenta (int p_nroDeCuenta){
      this.nroCuenta=p_nroDeCuenta;
  }
  
  /**
   * Descripcion: setter para el atributo saldo
   * @param recibe un double p_saldo
   */
  protected void  setSaldo (double p_saldo){
        this.saldo = p_saldo;
  }
    
   /**
   * Descripcion: setter para el atributo titular
   * @param recibe un Persona p_titular
   */
   private void  setTitular (Persona p_titular){
        this.titular = p_titular;
  }
   
  //getters
   /**
   * Descripcion: getter para el atributo nroDecuenta
   * @return retorna un int nroDecuenta
   */
  public int getNroDeCuenta(){
        return this.nroCuenta; 
  }
    
  /**
   * Descripcion: getter para el atributo saldo
   * @return retorna un double saldo
   */
  public double getSaldo(){
      return this.saldo; 
  }
  
   /**
   * Descripcion: getter para el atributo titular
   * @return retorna un Persona Titular
   */
  public Persona getTitular(){
        return this.titular; 
  }
    
  //constructores
  /**
   * Descripcion: constructor de objetos de la clase CuentaCorriente
   * @param int p_nroDeCuenta, Persona p_titular
   */
  public CuentaBancaria(int p_nroDeCuenta, Persona p_titular){
        this.setNroDecuenta(p_nroDeCuenta);
        this.setSaldo(0);
        this.setTitular(p_titular);
  }
  
   /** Descripcion: constructor de objetos de la clase CuentaCorriente
   * @param int p_nroDeCuenta, Persona p_titular, double p_saldo
   */
    
  public CuentaBancaria(int p_nroDeCuenta,double p_saldo, Persona p_titular){
        this.setNroDecuenta(p_nroDeCuenta);
        this.setSaldo(p_saldo);  
        this.setTitular(p_titular);
  }  
  //******************************************************metodos******************************************************
   /**
   * Descripcion: este metodo permite saber si un titular puede extraer o no fondos de su cuenta
   * corriente
   * @param recibe un doble p_imoporte
   * @return retorna un boolean
   */
  
  public abstract boolean puedeExtraer(double p_importe);
   
   /**
   * Descripcion: estemetodo permite coordinar al metodo puedeExtraer() con extraccion() y realizar 
   * la extraccion o en su defecto mostrar por pantalla el motiv o por el cual no se pudo completar 
   * la operacion
   * 
   * @param recibe un double p_importe
   */
  public abstract void extraer(double p_importe);
   
  /**
   * Descripcion: retorna un string que indica el motivo por el cual no se pudo realizar la extraccion
   * @return String
   */
  public abstract String xQNoPuedeExtraer();
   
  /**
  * Descripcion: este metodo permite extraer dinero de una cuenta corriente
  * @param recibe un double p_importe
  */
  public void extraccion(double p_importe){
      this.setSaldo(this.getSaldo() - p_importe);
  } 
  
  /**
   * Descripcion: este metodo permite depositar dinero de una cuenta 
   * @param recibe un double p_importe
   */
   public void depositar(double p_importe){
        this.setSaldo(this.getSaldo() + p_importe);
  }
  
  /**
  * Descripcion: permite mostrar en pantalla los datos del titular y su cuenta 
  */
  public void mostrar(){      
      System.out.println("Nro. Cuenta: "+this.getNroDeCuenta()+" - Saldo: U$D: "+this.getSaldo());
      System.out.println("Titular: "+this.getTitular().nomYApe());      
  }
}

