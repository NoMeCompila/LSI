import java.util.*;
/**
 * description: permite instanciar objetos del tipo Individuo extendidas de la clase abstracta Visitante
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Individuo extends Visitante{
    //atributos
    private Persona persona;
    //constructor
    public Individuo(String p_nombre, Calendar p_fecha, Persona p_persona){
        super( p_nombre, p_fecha);
        this.setPersona(p_persona);
    }
    //getters and settters
    private void setPersona(Persona p_persona){
        this.persona=p_persona;
    }
    
    public Persona getPersona(){
        return this.persona;
    }
    
    //metodos
    /**
     * descripcion: retorna el valor de la entrada
     */
    public double entrada(){
        return 25;
    }
    
    /**
     * descripcion: muestra en pantalla los datos personales de un individuo
     */
    public void mostrar(){
        this.getPersona().mostrar();  
    }
    
    /**
     * descripcion: hace una lista con el individuo si visito en esa fecha
     */
    public void listarPorFecha(Calendar p_fecha, String p_visitante){
        if((this.getFechaVisita() == p_fecha) &&(this.getNombre().equals(p_visitante))){
            this.mostrar();
        }
    }
    
    /**
     * descripcion: permite saber el tipo de visitante
     */
    public String tipoVisitante(){
        return this.getNombre();
    }    
}
