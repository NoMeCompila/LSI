import java.util.*;
public class VentaDeEntradas{
    public static void main(String args[]){
       Calendar desde = new GregorianCalendar(19,1,2019);
       Calendar hasta = new GregorianCalendar(20,5,2019);
       
       Calendar c1 = new GregorianCalendar();
       
       Persona p1 = new Persona(40982473,"Fernando","Caballero",1998);
       Persona p2 = new Persona(28546321,"Juan","Lopez",1990);
       Persona p3 = new Persona(30125487,"Irina","Monzon",1995);
       ArrayList <Individuo> indi2 = new ArrayList();
       ArrayList <Individuo> indi3 = new ArrayList();
           
       
       Individuo ind1 = new Individuo("Individuo", desde, p1);//individual
       Individuo ind2 = new Individuo("Delegacion", desde, p2);//para delegacion
       Individuo ind3 = new Individuo("Delegacion", desde, p3);//para delegacion 
      
       indi2.add(ind2);
       indi2.add(ind3);
       
       Delegacion del1 = new Delegacion("PAMI", desde,indi2);
       
       
       del1.listarPorFecha(c1, "Individuo");
       
       Zoologico zoo = new Zoologico("El Caribú",del1);
       
       zoo.nuevoVisitante(ind1);
       zoo.nuevoVisitante(del1);
       
       zoo.listaVisitantesPorFecha(desde);
       System.out.println(zoo.recaudacion(desde,hasta));
    }
}
