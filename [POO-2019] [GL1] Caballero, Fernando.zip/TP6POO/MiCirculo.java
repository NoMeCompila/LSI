/**
 * description: esta clase permite crear Rectangulos
 * @author Caballero, Fernando
 * @version 1.0
 */
public class MiCirculo extends MiElipse{
    //constructores
    public MiCirculo(Punto p_origen, double p_ancho, double p_alto){
        super(p_origen,p_ancho,p_alto);
    }
    
        public MiCirculo(double p_ancho, double p_alto){
        super(p_ancho,p_alto);
    }
    //metodos
    public String nombreFigura(){
        return "****Circulo****";
    }
    
    public double superficie(){
        return Math.PI * this.getAlto() * this.getAncho();
    }       
}