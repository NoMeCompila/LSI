import java.util.*;
/**
 * Write a description of class Delegacion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Delegacion extends Visitante{
    //atributo
    private  ArrayList <Individuo> integrantes;
    //constructor que recibe un array cuando ya tiene objetos
    public Delegacion(String p_nombre, Calendar p_fecha, ArrayList <Individuo> p_integrantes){
        super(p_nombre, p_fecha);
        this.setIntegrantes(p_integrantes);
    }
    
    
    //getters y setters
    private void setIntegrantes(ArrayList <Individuo> p_integrantes){
        this.integrantes=p_integrantes;
    }
    
    public ArrayList <Individuo> getIntegrantes(){
        return this.integrantes;
    }
    
    //metodos
    /**
     * descripcion:permite saber el monto total de la suma de las entradas de todos los integrantes de una delegacion con un descuento 
     * del 10%
     */
    public double entrada(){
        double totE=0;
        for(Individuo i1 : this.getIntegrantes()){
            totE+=i1.entrada();
        }
        return totE - (totE * 0.1);
    }
    
    /**
     * descripcion: permite agregar un individuo a la delegacion
     */
    public boolean inscribirIndividuo(Individuo p_individuo){
        return this.getIntegrantes().add(p_individuo);
    }
    
    /**
     * descripcion: retorna la cantidad de integrantes que posee la delegacion
     */
    public int cantidadDeIntegrantes(){
        int cantidad=0;
        for(Individuo i1 : this.getIntegrantes()){
            if(i1.tipoVisitante().equals("Individuo")){cantidad++;}
        }
        return cantidad;
    }
    
    /**
     * descripcion:muestra una lista con todos los integrantes de una delegacion
     */    
    public void mostrar(){
        for(Individuo i1 : this.getIntegrantes()){
            i1.mostrar();
        }
    }
    
    /**
     * retorna el tipo de visistante
     * @return String visistante
     */
    public String tipoVisitante(){
        return "Delegacion";
    }
    
    /**
     * descripcion: retorna la cantidad de individuos que visitaron en una fecha determinada y muestra sus datos
     */
    
    public void listarPorFecha(Calendar p_fecha, String p_visitante){
               
        for(Individuo i1 : this.getIntegrantes()){             
            if(i1.getFechaVisita().get(Calendar.DATE)==p_fecha.get(Calendar.DATE) && 
               i1.getFechaVisita().get(Calendar.MONTH)==p_fecha.get(Calendar.MONTH)&&
               i1.getFechaVisita().get(Calendar.MONTH)==p_fecha.get(Calendar.YEAR)&&
               i1.getNombre().equals(p_visitante)){i1.getPersona().mostrar();}
        }
        
    }
}
