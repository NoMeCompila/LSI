import java.util.*;
public class AplicacionFacultad{
   public static void main(String args []){
       Cargo c1 = new Cargo("JTP-Programación OO", 800.0,2009,10);
       //c1.mostrarCargo();
       
       
       //System.out.println("\n");
       SemiExclusivo se1 = new SemiExclusivo("JTP-Paradigmas y Lenguajes",900.0,2005,10,10);     
       //se1.mostrarCargo();
       
       
       //System.out.println("\n");
       Exclusivo e1 =  new Exclusivo("JTP-AEDII",1000,2000,10,10,10);
       //e1.mostrarCargo();
       Exclusivo e2 =  new Exclusivo("JTP-AEDII",1000,2000,10,10,10);
       //e2.mostrarCargo();
       
       //creo un array con los cargos
       ArrayList <Cargo> cargos = new ArrayList <Cargo> ();
       cargos.add(c1);
       cargos.add(se1);
       cargos.add(e1);
       ArrayList <Cargo> cargos2 = new ArrayList <Cargo> ();
       cargos2.add(e2);
       //instancio un profe
       Profesor p1 = new Profesor(40982473,"Caballero","Fernando", 1998, "Licenciado", cargos);
       Profesor p2 = new Profesor(30972473,"Juan","Lopez", 1987, "Ingeniero", cargos2);
       //p1.mostrar();
       //p2.mostrar();
       
       ArrayList <Profesor>  profesores = new ArrayList <Profesor> ();
       profesores.add(p1);
       profesores.add(p2);
       //instanciar una facultad
       Facultad f1 = new Facultad("Facena",profesores);
       f1.nominaProfesores();
       f1.listarProfesorCargos();
   }
}
