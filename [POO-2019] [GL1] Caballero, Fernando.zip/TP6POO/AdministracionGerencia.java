import java.util.*;
public class AdministracionGerencia{
    public static void main(String args[]){
        Servicio auto = new Servicio("alquiler de auto", 100);
        Servicio internet = new Servicio("Internet", 150);
        Servicio lavanderia = new Servicio("lavanderia", 50);
        
        ArrayList <Servicio> servi1 = new ArrayList();
        servi1.add(lavanderia);
        servi1.add(auto);
        
        Alojamiento c1 = new Cabaña("Cabañas La Alonda", 600, 5, servi1, 3);
        //c1.liquidar();
        
        System.out.println("------------------------------------------------");
        ArrayList <Servicio> servi2 = new ArrayList();
        servi2.add(internet);
        servi2.add(lavanderia);
        
        Alojamiento h1 = new Hotel("Hotel Guarani",1000,7,servi2,"Doble");
        //h1.liquidar();
        
        ArrayList <Alojamiento> a1 = new ArrayList();
        a1.add(c1);
        a1.add(h1);
        
        Gerencia g1 =new Gerencia("Gerencia Los Arroyos",a1);
        g1.liquidar();
        g1.mostrarLiquidacion();
    }
}
