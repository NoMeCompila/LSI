/**
 * description:permte crear cajas de ahorros extendidas de la clase abstracta CuentaBancaria
 * @author Caballer, Fernando
 * @version 1.0
 */
public class CajaDeAhorro extends CuentaBancaria{
    private int extraccionesPosibles;
    
    //costructores
  
    public CajaDeAhorro(int p_nroDeCuenta, Persona p_titular, int p_extraccionesPosibles){
        super(p_nroDeCuenta,p_titular);
        this.setExtraccionesPosibles(p_extraccionesPosibles);
    }
    
    public CajaDeAhorro(int p_nroDeCuenta,double p_saldo,Persona p_titular, int p_extraccionesPosibles){
        super(p_nroDeCuenta,p_saldo,p_titular);
        this.setExtraccionesPosibles(p_extraccionesPosibles);
    }
      
    //getters ys etters 
    
    private void setExtraccionesPosibles(int p_extraccionesPosibles){
        this.extraccionesPosibles = p_extraccionesPosibles;
    }
    
    public int getExtraccionesPosibles(){
        return this.extraccionesPosibles;
    }
    //***********************************METODOS*****************************************************
    public boolean puedeExtraer(double p_importe){
        return ((p_importe < this.getSaldo()) && (this.getExtraccionesPosibles() > 0));
    }
    
    public void extraccion(double p_importe, int p_extraccionesPosibles){
      this.extraccion(this.getSaldo() - p_importe);
      this.setExtraccionesPosibles(p_extraccionesPosibles--); 
    }
    
      public void extraer(double p_importe){
      if(this.puedeExtraer(p_importe) && (this.getExtraccionesPosibles() >  0) &&
      (this.getSaldo() > p_importe)){
           this.setSaldo(this.getSaldo() - p_importe);
      }else if(this.puedeExtraer(p_importe) && (this.getExtraccionesPosibles()  == 0) &&
      (this.getSaldo() > p_importe)){
           this.xQNoPuedeExtraer();
      }else if(this.puedeExtraer(p_importe) && (this.getExtraccionesPosibles() >  0) &&
      (this.getSaldo() < p_importe)){
           System.out.println("No puede extraer mas que el saldo!");
      }
    }
    
    public String xQNoPuedeExtraer(){
           return "No tiene habilitadas mas extracciones!";
    }
    
    public void mostrar(){
        System.out.println("\n**********CAJA DE AHORRO**********");
        super.mostrar();
    }
}
