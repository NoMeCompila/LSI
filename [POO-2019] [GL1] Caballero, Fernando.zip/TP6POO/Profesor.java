import java.util.*;
/**
 * Descripcion: esta clase genera objetos en el cual se puede manipular y ver el saldo de los clientes  
 * @author Caballero, Fernando
 * @version 1 Fecha: 26/08/2019
 */
public class Profesor extends  Persona{
    private String titulo;    
    private ArrayList <Cargo> cargos; //aca declaro generico
    
    Calendar fecha = new GregorianCalendar();
    //setters
    /**
     * descripcion: constructor para los objetos de clase Persona
     */
    //constructor
    public Profesor(int p_dni, String p_nombre, String p_apellido, Calendar p_fechaNacimiento,String 
    p_titulo, ArrayList <Cargo> p_cargos){
        super(p_dni,p_nombre,p_apellido,p_fechaNacimiento);
        this.setTitulo(p_titulo);
        this.setCargos(p_cargos);
    }
    
    public Profesor(int p_dni, String p_nombre, String p_apellido, int p_anio, String p_titulo, 
                    ArrayList <Cargo> p_cargos){    
        super(p_dni,p_nombre,p_apellido,p_anio);
        this.setTitulo(p_titulo);
        this.setCargos(p_cargos);        
    }
    
    public String getTitulo(){
        return this.titulo;
    }
    
    private void setTitulo(String p_titulo){
        this.titulo=p_titulo;
    }
    
    public ArrayList <Cargo> getCagros(){
        return this.cargos;
    }
    
    private void setCargos(ArrayList <Cargo> p_cargo){
        this.cargos = p_cargo;
    }
    
    /**
     * Descripcion: este metodo muestra en pantalla los datos de una persona 
     */
    public void mostrar(){
        super.mostrar();
        System.out.println("-----------------------------------------------------");
        System.out.println("Titulo: " + this.getTitulo());
        System.out.println("-***** Cargos Asignados *****-");
        this.listarCargos();
    }  
    
    /**
     * descripcion: permite hacer una lista de los cargos
     */
    
    public void listarCargos(){
       for(Cargo c1 : this.getCagros()){
            c1.mostrarCargo();
            System.out.println("\n");
        }
    }
    
    /**
     * descripcion: calcula el sueldo total de un profesor segun todos sus cargos
     * @return double sueldoTot
     */
    public double sueldoTotal(){
        double sueldoTot=0.0;
        for(Cargo c1 : this.getCagros()){
            sueldoTot += c1.sueldoDelCargo();
        }
        return sueldoTot;
    }
    
    /**
     * descripcion: permite mostrar en una sola linea los datos basicos de un docente
     */
    public String mostrarLinea(){
        return "DNI: " + this.getNroDni() + " Nombre y Apellido: " + this.nomYApe() + " - Sueldo Total"
        + this.sueldoTotal();
    }
}