import java.lang.Math;
/**
 * Descripcion: genera objetos  de la clase Punto y desplazarlos a placer
 * @version 1.0 Fecha: 26/08/2019
 */
public class Punto{
   //atributos 
   private double x; 
   private double y;
    
   //getters
   /**
    * descripcion: getter para el atributo x
    * @return retorna un double x
    */
   public double getX(){
        return this.x; 
   }
   /**
    * descripcion: getter para el atributo Y
    * @return retorna un double y 
    */
   public double getY(){
        return this.y; 
   }
    
   //setterts
   /**
    * setter para el atributo x
    * @param recibe un double p_x
    */
   private void setX(double p_x){
        this.x = p_x;
   }
   /**
    * setter para el atributo y
    * @param recibe un double p_y
    */    
   private void setY(double p_y){
        this.y = p_y;
   }
    
   //costructores
   /**
    * descripcion: constructor para la clase punto con datos ingresados por teclado
    */
   public Punto(double p_x, double p_y){
        this.setX(p_x);
        this.setY(p_y);
   }

   /**
    * descripcion: constructor para la clase punto con coordenadas (0,0)
    */
   public Punto(){   
        this.setX(0);
        this.setY(0);
   }
    //metodos
   /**
    * Descripcion: retorna una cadena con als coordenadas del punto
    * @return devuelve un String con las coordenadas del punto
    */
   public String coordenadas(){
        return "Coordenandas :  ("+this.getX()+","+this.getY()+")";
   }
   
   /**
    * descripcion: suma a X e Y dos valores ingresados por teclado (1 a cada 1)
    */
   public void desplazar(double p_dx,double p_dy){
       this.setX((this.getX()+p_dx));
       this.setY(this.getY()+p_dy);
   }
   
   /**
    * Descripcion calcula la distancia entre el mismo punto y otro recibido como parametro
    * @return retorna un double distancia
    */
   
   public double distanciaA(Punto p_ptoDistante){
       return Math.sqrt( (Math.pow(this.getX() - p_ptoDistante.getX(),2.0)) +  (Math.pow(this.getY() - p_ptoDistante.getY(),2)));
   }
   
   /**
    * descripcion: muestra por pantalla las coordenadas de un punto
    */
   public void mostrar(){
        System.out.println("Punto. X: "+this.getX()+" Y: "+this.getY());
   }

}