/**
 * description: 
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Heladera extends ArtefactoHogar{
    //atributos
    private int pies;
    private int puertas;
    private boolean compresor;
    //constructor
    public Heladera(String p_marca, float p_precio, int p_stock, int p_pies,
                    int p_puertas,boolean p_compresor){
        super(p_marca,p_precio,p_stock);
        this.setPies(p_pies);
        this.setPuertas(p_puertas);
        this.setCompresor(p_compresor);        
    }
    //getters and setters
    private void setPies(int p_pies){
        this.pies=p_pies;
    }
    
    public int getPies(){
        return this.pies;
    }
    
    private void setPuertas(int p_puertas){
        this.puertas=p_puertas;
    }
    
    public int getPuertas(){
        return this.puertas;
    }
    
    private void setCompresor(boolean p_compresor){
        this.compresor= p_compresor;
    }
    
    public boolean getCompresor(){    
        return this.compresor;
    }
    //metodos
    public void imprimir(){
        System.out.println("****Heladera****");
        super.imprimir();
        System.out.println("Pies: " + this.getPies());
        System.out.println("Puertas: " + this.getPuertas());
        if(this.getCompresor()){
            System.out.println("Compresor: SI");
        }else 
            System.out.println("Compresor: NO");
        
    }
    
    public float creditoConAdicional(int p_cuotas, float p_interes){
        if(this.getCompresor()){
            return (this.getPrecio() / p_cuotas) + (this.getPrecio()*(p_cuotas/100)+50);
        }else return (this.getPrecio() / p_cuotas) + (this.getPrecio()*(p_cuotas/100));
    }
}
