public class Escuela{
    public static void main(String args []){
        //instanciamos un alumno
        Alumno a1 = new Alumno(40982473, "Fernando", "Caballero", 1998, 54466, 7.00, 9.00);
        a1.mostrar();
        System.out.println("-------------------------------------------");
        Persona p1 = new Persona(39008772, "Esteban", "Maldonado", 1997);
        p1.mostrar();
    }
}
