
/**
 * description: clase abstracta para instanciar electrodomesticos
 * @author Caballero, Fernando 
 * @version 1.0
 */
public abstract class ArtefactoHogar{
   //atributos
   private String marca;
   private float precio;
   private int stock;
   //constructor
   public ArtefactoHogar(String p_marca, float p_precio, int p_stock){
       this.setMarca(p_marca);
       this.setPrecio(p_precio);
       this.setStock(p_stock);
   }
   //getter y setters
   private void setMarca(String p_marca){
       this.marca = p_marca;
   }
   
   public String getMArca(){
       return this.marca;
   }
   
   private void setPrecio(float p_precio){
       this.precio=p_precio;
   }
   
   public float getPrecio(){
       return this.precio;
   }
   
   private void setStock(int p_stock){
       this.stock=p_stock;
   }
   
   public int getStock(){
       return this.stock;
   }
   
   //metodos
   /**
    * descripcion: permite mostrar en pantalla los datos basicos de un electrodomestico
    */
   public void imprimir(){
       System.out.println("Marca: " + this.getMArca() + " - Precio: " + this.getPrecio() + 
       " - stock: " + this.getStock());
   }
   
   /**
    * descripcion: permite saber cuanto hay que pagar cadacuota sumandole su correspondiente interes
    */
   public float cuotaCredito(int p_cuotas, float p_interes){
       return (this.getPrecio()/p_cuotas) + (this.getPrecio() * (p_interes/100));
   }
   
   /**
    * metodo abstracto para reutilizarlo en subclases
    */
   public abstract float creditoConAdicional(int p_cuotas, float p_interes);
}