import java.util.*;
/**
 * description: permite crear objetos del tipo  zoologico para administrar a los visistantes del mismo
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Zoologico{
    //atributos
    private String nombre;
    private ArrayList <Visitante> visitantes;
    //constructor cuando se recibe solo un visitante(el primero)
    public Zoologico(String p_nombre, Visitante p_visitante){
        this.setNombre(p_nombre);
        this.setVisitantes(new ArrayList <Visitante> ());
        this.nuevoVisitante(p_visitante);
    }
    
    //constructor pra cuando ay se poseen visitantes en la coleccion
    public Zoologico(String p_nombre, ArrayList <Visitante> p_visitantes){
        this.setNombre(p_nombre);
        this.setVisitantes(p_visitantes);
    }
    
    //getters y setters
    private void setNombre(String p_nombre){
        this.nombre=p_nombre;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    private void setVisitantes(ArrayList <Visitante> p_visitantes){
        this.visitantes=p_visitantes;
    }
    
    public ArrayList <Visitante> getVisitantes(){
        return this.visitantes;
    }
    
    /**
     * metodo para agregar visitantes y por si hace falta en un futuro paraquitar
     * @return boolean
     */
    public boolean nuevoVisitante(Visitante p_visitante){
        return this.getVisitantes().add(p_visitante);
    }
    
    public boolean eliminarVisitante(Visitante p_visitante){
        return this.getVisitantes().remove(p_visitante);
    }
    
    //metodos
    /**
     * retorna una lista con los datos de las personas que visitaron el zoologico en cierta fecha y que sean del tipo de visitante 
     * requerido
     */
    public void listaTipoVisitantePorFecha(Calendar p_fecha,String p_tipoVisitante){
        for(Visitante v1 : this.getVisitantes()){
            if(v1.getFechaVisita().get(Calendar.DATE)==p_fecha.get(Calendar.DATE) && 
               v1.getFechaVisita().get(Calendar.MONTH)==p_fecha.get(Calendar.MONTH)&&
               v1.getFechaVisita().get(Calendar.MONTH)==p_fecha.get(Calendar.YEAR)&&
               v1.getNombre().equals(p_tipoVisitante)){
                   v1.mostrar();
            }
        }
    }
    
    /**
     * Descripcion: conforma una lista con lso datos de los individuos que visitaron el zoologico en cierta fecha indicada
     */
    public void listaVisitantesPorFecha(Calendar p_fecha){
            for(Visitante v1 : this.getVisitantes()){
            if(v1.getFechaVisita().get(Calendar.DATE)==p_fecha.get(Calendar.DATE) && 
               v1.getFechaVisita().get(Calendar.MONTH)==p_fecha.get(Calendar.MONTH)&&
               v1.getFechaVisita().get(Calendar.MONTH)==p_fecha.get(Calendar.YEAR)){
                   v1.mostrar();
            }
        }
    }
    
    /**
     * descripcion: retorna el monto recaudado en un intervalo de tiempo pasados como aprametro
     * @param Calendar p_fechaDesde, Calendar p_fechaHasta
     */
    
     public double recaudacion(Calendar p_fechaDesde, Calendar p_fechaHasta){
      
        double devolver=0;
        Calendar desde= Calendar.getInstance();
        Calendar hasta= Calendar.getInstance();
        Calendar comprobar =Calendar.getInstance();
       
        desde.set(p_fechaDesde.get(Calendar.YEAR),p_fechaDesde.get(Calendar.MONTH),p_fechaDesde.get(Calendar.DATE));
        hasta.set(p_fechaHasta.get(Calendar.YEAR),p_fechaHasta.get(Calendar.MONTH),p_fechaHasta.get(Calendar.DATE));
        for(Visitante v1 : this.getVisitantes()){          
             comprobar.set(v1.getFechaVisita().get(Calendar.YEAR),v1.getFechaVisita().get(Calendar.MONTH),v1.getFechaVisita().get(Calendar.DATE));           
             if(comprobar.compareTo(desde) >=0  && comprobar.compareTo(hasta) <=0 ){
                 devolver+=v1.entrada();
             }               
        }
        return devolver;
    }
}
