/**
 * DEscripcion: permite crear objetos de tipo Cuadrado asi como tambien calcular su area y perimetro a demas de calcular la distancia entre 2 objetos rectangulo
 * 
 * @author (Caballero, Fernando) 
 * @version (1) fecha 29/08/2019
 */
public class Cuadrado extends Rectangulo{
   //atributos
   private  Punto origen;
   private  double ancho;
   private  double alto;
  
   //constructores
   
   /**
    * Descripcion: Constructor de la clase Rectangulo
    * @param Punto p_origen, double p_ancho, double p_alto
    */
   
   public Cuadrado(Punto p_origen, double p_lado, double p_lado1){
       super(p_origen, p_lado, p_lado1);
   }
   
   /**
    * Descripcion: Costructor sobrecargado de la clase Rectangulo 
    * @paramdouble p_ancho, double p_alto
    */
      
   //metodos 
   
   public String nombreFigura(){
       return "****Cuadrado****";
   }
   
   /** 
   * Descripcion: permite desplazar un rectangulo desde su origen sin modificar sus caracteristicas
   * @param recibe 2 parametros double p_dx y double p_dy
   */
   public void desplazar(double p_dx, double p_dy){
        this.getOrigen().desplazar(p_dx,p_dy);
   }
   
   
   /**
    * Descripcion: Permite saber el perimetro de un rectanglo
    * @return retorna un double que será el perimetro del rectangulo
    */  
   public double perimetro(){
       return 2 * this.getAlto() + 2 * this.getAncho();
   }
   
   /**
   * Descripcion: permite calcular la superficie de un rectangulo
   * @return retorna un double la superficie
   */
   public double superficie(){
       return this.getAlto() * this.getAncho();
   }
   
   /**
    * Descripcion: permite mostrar las caracteristicas de un rectangulo
    */
   
   public void caracteristicas(){
       System.out.println(this.nombreFigura());
       System.out.println("Origen: "+this.getOrigen().coordenadas()+" - Alto: "+this.getAlto()+" - Ancho: "+this.getAncho());
       System.out.println("superficie: "+this.superficie());
   }
   
   /**
    * Descripcion: permite saber la distancia entre dos objetos de tipo rectangulo
    * @return retorna un double la distancia entre dos rectangulos
    */
   public double distancia(Rectangulo p_rectangulo){
       return Math.sqrt( (Math.pow(this.origen.getX() - p_rectangulo.getOrigen().getX(),2)) +  (Math.pow(this.origen.getY() - 
       p_rectangulo.getOrigen().getY(),2)));
   }
   
   /**
    * Descripcion: permite saber cual es el mayor entre 2 rectangulos segun su superficie y si son iguales retornara null
    * @return retorna un tipo Rectangulo (el mayor)
    */
   public Rectangulo elMayor(Rectangulo p_rectangulo){
      if(this.superficie() > p_rectangulo.superficie() ){
           return this;
      }else if(this.superficie() < p_rectangulo.superficie()){
           return p_rectangulo;
      }else return null;
   }
 
}
