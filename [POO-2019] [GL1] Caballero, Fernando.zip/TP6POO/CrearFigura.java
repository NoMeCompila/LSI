public class CrearFigura{
    public static void main(String args []){
        //instanciar la clase punto
        Punto p1 = new Punto(1.0, 1.0);
        //instanciar la clase Rectangulo
        Rectangulo r1 = new Rectangulo(p1, 4.0, 4.0);
        
        r1.caracteristicas();
        System.out.println("Perímetro: "+r1.perimetro());
        
        System.out.println("-------------------------------------------------------");
        
        Punto p2 = new Punto(2.0, 2.0);
        //instanciar un cuadrado
        Cuadrado c1 = new Cuadrado(p2, 3.0, 3.0);
        c1.caracteristicas();
        System.out.println("Perímetro: "+c1.perimetro());
        
        System.out.println("-------------------------------------------------------");
        
        //instanciar un punto
        Punto p3 = new Punto(6.0, 7.0);
        //instanciar una elipse
        Elipse e1 = new Elipse(5.0,2.0,p3);
        //mostrar caracteristicas de la elipse cre3ada
        e1.caracteristicas();
        
        System.out.println("-------------------------------------------------------");
        //instanciar un punto
        Punto p4 = new Punto(7.0, 8.0);
        //instanciar un circulo
        Circulo cir1 = new Circulo(2.0,2.0,p4);
        //mostrar caracteristicas
        cir1.caracteristicas();
        
    }
}
