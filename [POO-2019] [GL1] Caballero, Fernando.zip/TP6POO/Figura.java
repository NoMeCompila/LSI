/**
 * Descripcion: permite crear figuras geometricas y saber sus caracteristicas
 * @author (Caballero, Fernando) 
 * @version (1) fecha 26/10/2019
 */
public abstract class Figura{
   
   //atributos
   private  Punto origen;
   private  double ancho;
   private  double alto;
   
   //setters
   /**
    * Descripcion: Metodo setter para el atributo origen
    * @param recibe un parametro de tipo Punto 
    */
   
   private void setOrigen(Punto p_origen){
       this.origen = p_origen;
   }
   
    /**
     * Descripcion: Metodo setter para el atributo ancho 
     * @param recibe un parametro de tipo double p_ancho 
     */
   
    private void setAncho(double p_ancho){
        this.ancho = p_ancho; 
   }
   
   /**
    * Descripcion: Metodo setter para el atributo alto
    * @param recibe un parametro del tipo double p_altura
    */
   
   private void setAltura(double p_alto){
       this.alto = p_alto;
   }
   
   //getters
   
   /**
    * Descripcion: Metodo getter para el atributo origen
    * @return retorna un tipo Punto
    */
   
   public Punto getOrigen(){
       return this.origen;
   }
   
   /**
    *Descripcion: Metodo getter para el atributo ancho 
    * @return retorna un double ancho
    */
   
   public double getAncho(){
       return this.ancho;
   }
   
   /**
    * Descripcion: Metodo getter para el atributo alto  
    * @return retorna un double alto
    */
   public double getAlto(){
        return this.alto;
   }
   
   //constructores
   
   /**
    * Descripcion: Constructor de la clase Rectangulo
    * @param Punto p_origen, double p_ancho, double p_alto
    */
   
   public Figura(Punto p_origen, double p_ancho, double p_alto){
       this.setOrigen(p_origen);
       this.setAncho(p_ancho);
       this.setAltura(p_alto);
   }
   
   /**
    * Descripcion: Costructor sobrecargado de la clase Rectangulo 
    * @paramdouble p_ancho, double p_alto
    */
   
   public Figura(double p_ancho, double p_alto){
       this.setOrigen(new Punto ());
       this.setAncho(p_ancho);
       this.setAltura(p_alto);
   }
   
   //metodos 
   public abstract String nombreFigura();
      
   /**
   * Descripcion: permite calcular la superficie de un rectangulo
   * @return retorna un double la superficie
   */
   public abstract double superficie();
   
   /**
    * Descripcion: permite mostrar las caracteristicas de un rectangulo
    */   
   public void caracteristicas(){
       System.out.println("\t" + this.nombreFigura());
       //System.out.println("Origen: "+this.getOrigen().coordenadas()+" - Alto: "+this.getAlto()+" - Ancho: "+this.getAncho());
       System.out.println("superficie: "+this.superficie() + " Metros cuadrados.");
       System.out.println("\n\n");
   }
}