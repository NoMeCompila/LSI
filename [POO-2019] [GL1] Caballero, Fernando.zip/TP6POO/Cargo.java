import java.util.*;
/**
 * description: clase que permite crear cargos para profesores
 * 
 * @author Caballero, Fernando
 * @version 1.0
 */
public class Cargo{
    //atributos
    private String nombre;
    private double sueldoBasico;
    private int anioIngreso;
    private int horasDeDocencia;
    
    //costructores
    public Cargo(String p_nombre, double p_sueldoBasico, int p_anioIngreso, int p_horasDeDocencia){
        setNombre(p_nombre);
        setSueldoBasico(p_sueldoBasico);
        setAnioIngreso(p_anioIngreso);
        setHorasDeDocencia(p_horasDeDocencia);
    }
    
    //setters
    private void setNombre(String p_nombre){
        this.nombre=p_nombre;
    }
    
    private void setSueldoBasico(double p_sueldoBasico){
        this.sueldoBasico=p_sueldoBasico;
    }
    
    private void setAnioIngreso(int p_anioIngreso){
        this.anioIngreso=p_anioIngreso;
    }
    
    private void setHorasDeDocencia(int p_horasDeDocencia){
        this.horasDeDocencia=p_horasDeDocencia;
    }
    
    //getters
    public String getNombre(){
        return this.nombre;
    }
    
    public double getSueldoBasico(){
        return this.sueldoBasico;
    }
    
    public int getAnioIngreso(){
        return this.anioIngreso;
    }
    
    public int getHorasDeDocencia(){
        return this.horasDeDocencia;
    }
    
    
    //metodos
    /**
     * Descripcion: calcula cuanto tiempo el profesor ejerció el cargo
     * @return f.get(Calendar.YEAR) - this.getAnioIngreso(); 
     */
    public int antgüedad(){
        Calendar f = new GregorianCalendar();
        return f.get(Calendar.YEAR) - this.getAnioIngreso();        
    }
    
    /**
     * Descripcion: calcula el sueldo adicional de un profesor en funcion a su antigüedad en un cargo
     * @return (this.getSueldoBasico() * 0.1) * this.Antgüedad(); 
     */
    private double adicionalXAntiguedad(){
        return (this.getSueldoBasico() * 0.01) * this.antgüedad(); 
    }
    
    /**
     * Descripcion: le suma al sueldo basico del profesor su adicional correspondiente
     * @return this.getSueldoBasico() + this.adicionalXAntiguedad();
     */    
    public double sueldoDelCargo(){
        return this.getSueldoBasico() + this.adicionalXAntiguedad();
    }
    
    /**
     * Descripcion: muestra los datos del cargo y saldo
     */    
    public void mostrarCargo(){
        System.out.println(this.getNombre() + " - " + "Sueldo Basico: U$D " + this.getSueldoBasico() + " - Sueldo del Cargo: U$D " + 
        this.sueldoDelCargo() + " - Antiguedad: " + this.antgüedad() + " años - Horas Docencia: " + this.getHorasDeDocencia());
    }
}
