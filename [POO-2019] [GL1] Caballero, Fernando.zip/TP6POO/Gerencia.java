import java.util.*;
/**
 * description: permite crear objetos de clase gerencia para administrar alojamientos
 * 
 * @author Caballero, Fernando
 * @version 1.0
 */
public class Gerencia{
    //atributos
    private String nombre;
    private ArrayList <Alojamiento> alojamientosAlquilados;
    //constructor para recibir al primer elemento
    public Gerencia(String p_nombre, Alojamiento p_alojamiento){
        this.setNombre(p_nombre);
        this.setAlojamientosAlquilados(new ArrayList<Alojamiento>());
        this.agregarAlojamiento(p_alojamiento);
    }
    //constructor para añadir un objeto a la coleccion
    public Gerencia(String p_nombre, ArrayList<Alojamiento>p_alojamientosAlquilados){
        this.setNombre(p_nombre);
        this.setAlojamientosAlquilados(p_alojamientosAlquilados);
    }
    //getters and setters
    private void setNombre(String p_nombre){
        this.nombre=p_nombre;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    private void setAlojamientosAlquilados(ArrayList <Alojamiento> p_alojamientosAlquilados){
        this.alojamientosAlquilados=p_alojamientosAlquilados;
    }
    
    public ArrayList <Alojamiento> getAlojamientosAlquilados(){
        return this.alojamientosAlquilados;
    }
    
    //metodos para agregar y quitar Alojamientos
    public boolean agregarAlojamiento(Alojamiento p_alojamiento){
        return this.getAlojamientosAlquilados().add(p_alojamiento);
    }
    
    public boolean quitarAlojamiento(Alojamiento p_alojamiento){
        return this.getAlojamientosAlquilados().add(p_alojamiento);        
    }
    
    //metodos
    /**
     * descripcion: permite saber el total de alojamientos
     */
    public int contarAlojamientos(String p_alojamiento){
        int cont = 0;
        for(Alojamiento a1 : this.getAlojamientosAlquilados()){
            cont += a1.contar(p_alojamiento);
        }
        return cont;
    }
    
    /**
     * decripcion: muestra una lista con todas las liquidaciones de alojamientos alquilados
     */
    public void liquidar(){
        for(Alojamiento a1 : this.getAlojamientosAlquilados()){
            a1.liquidar();
        }
    }
    
    
    public void mostrarLiquidacion(){
        
        int hotel=contarAlojamientos("Hotel");
        int cabaña=contarAlojamientos("Cabaña");
        
        System.out.println("Gerencia: "+this.getNombre());
        System.out.println("Liquidación:------------------------------------------\n");
        this.liquidar();
        System.out.println("\nAlojamiento tipo Cabaña ------>"+cabaña);
        System.out.println("Alojamiento tipo Hotel ------>"+hotel);
    }
}

