/**
 * description: permite crear objetos de la calse lavarropas que extiende a la clase ArtefactoHogar
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Lavarropas extends ArtefactoHogar{
    //atributos
    private int programas;
    private float kilos;
    private boolean automatico;
    //constructor
    public Lavarropas(String p_marca, float p_precio, int p_stock, int p_programas,float p_kilos,
                     boolean p_automatico){
        super(p_marca,p_precio,p_stock);
        this.setProgramas(p_programas);
        this.setKilos(p_kilos);
        this.setAutomatico(p_automatico);
    }
    //getters and setters
    private void setProgramas(int p_programas){
        this.programas=p_programas;
    }
    
    public int getProgramas(){
        return this.programas;
    }
    
    private void setKilos(float p_kilos){
        this.kilos = p_kilos;
    }
    
    public float getKilos(){
        return this.kilos;
    }
    
    private void setAutomatico(boolean p_automatico){
        this.automatico=p_automatico;
    }
    
    public boolean getAutomatico(){
        return this.automatico;
    }
    
    //metodos
    
    public void imprimir(){
        System.out.println("****Lavarropas****");
        super.imprimir();
        System.out.println("Programas: " + this.getProgramas());
        System.out.println("Kilos: " + this.getKilos());
        if(this.getAutomatico()){
            System.out.println("Automatico: SI");
        }else 
            System.out.println("Automatico: NO");        
    } 
    
    public float creditoConAdicional(int p_cuotas, float p_interes){
        if(!this.getAutomatico()){
            return  (this.getPrecio() / p_cuotas) - (this.getPrecio() * (float) 0.02); 
        }else
            return (this.getPrecio() / p_cuotas) + (this.getPrecio() * (p_interes / 100));
    }
}
