public class Administracion{
    public static void main(String args []){
        //instanciar la clase punto
        Punto p1 = new Punto(1.0, 1.0);
        //instanciar la clase Rectangulo
        Figura r = new MiRectangulo(p1, 4.0, 4.0);        
        //r.caracteristicas();
        
        
        //instanciar la clase punto
        Punto p2 = new Punto(2.0, 2.0);
        //instanciar la clase cuadrado
        Figura c = new MiCuadrado(p2, 5.0, 5.0);        
        //c.caracteristicas();
        
                
        //instanciar la clase punto
        Punto p3 = new Punto(3.0, 3.0);
        //instanciar la clase cuadrado
        Figura e = new MiElipse(p3, 6.0, 6.0);        
        //e.caracteristicas();
        
        //instanciamos una clase jardin
        Jardin j1 = new Jardin("Rinconcito de luz", c);
        
        //agregamos mas figuraS
        j1.agregarFigura(e);
        j1.agregarFigura(r);
        //mostramos los detalles
        j1.detalleFiguras();
    }
}
