import java.util.*;
public class Comercio{
    public static void main(String args[]){
        Scanner teclado = new Scanner(System.in);
        
        //Cocina
        System.out.println("----------------------COCINAS----------------------");
        System.out.println("Ingrese marca de la cocina: ");
        String  marca =  teclado.next();
        
        System.out.println("Ingrese precio de la cocina: ");
        float precio = teclado.nextFloat();
        
        System.out.println("Ingrese stock de la cocina: ");
        int stock = teclado.nextInt();
        
        System.out.println("Ingrese Hornallas: ");
        int hornallas = teclado.nextInt();
        
        System.out.println("Ingrese calorias: ");
        int calorias = teclado.nextInt();
        
        System.out.println("Ingrese dimensiones: ");
        String dimensiones = teclado.next();
        
        System.out.println("Ingrese cantidad de cuotas a pagar: ");
        int cuotas = teclado.nextInt();
        
        System.out.println("Ingrese interes: ");
        float interes = teclado.nextFloat();
        
        ArtefactoHogar a1 = new Cocina(marca, precio,stock,hornallas,calorias,dimensiones);
        a1.imprimir();
                
        System.out.println("Cuotas: " + cuotas + " - Interes: " + interes + "%");
        System.out.println("Valor Cuota: U$D" + a1.cuotaCredito(cuotas, interes));
        System.out.println("Valor Cuota con Adicional: U$D" + a1.creditoConAdicional(cuotas, interes));
        System.out.println("\n");
        System.out.println("--------------------------------------------------");
        System.out.println("\n");
        
        //Heladera
        System.out.println("----------------------HELADERAS----------------------");
        System.out.println("Ingrese marca de la heladera: ");
        String  marcaH =  teclado.next();
        
        System.out.println("Ingrese precio de la heladera: ");
        float precioH = teclado.nextFloat();
        
        System.out.println("Ingrese stock de la heladera: ");
        int stockH = teclado.nextInt();
        
        System.out.println("Ingrese pies: ");
        int pies = teclado.nextInt();
        
        System.out.println("Ingrese cantidad de puertas: ");
        int puertas = teclado.nextInt();
        
        System.out.println("Ingrese valor de verdad del comrpesor: ");
        boolean compresor = teclado.nextBoolean();
        
        System.out.println("Ingrese cantidad de cuotas a pagar: ");
        int cuotasH = teclado.nextInt();
        
        System.out.println("Ingrese interes: ");
        float interesH = teclado.nextFloat();
        
        ArtefactoHogar h1 = new Heladera(marcaH,precioH,stockH,pies,puertas,compresor);
        h1.imprimir();
        System.out.println("Cuotas: " + cuotasH + " - Interes: " + interesH + "%");
        System.out.println("Valor Cuota: U$D" + h1.cuotaCredito(cuotasH, interesH));
        System.out.println("Valor Cuota con Adicional: U$D" + h1.creditoConAdicional(cuotasH, interesH));
        System.out.println("\n");
        System.out.println("--------------------------------------------------");
        System.out.println("\n");
        
        //Lavarropas
        System.out.println("----------------------LAVARROPAS----------------------");
        System.out.println("Ingrese marca del lavarropas: ");
        String  marcaL =  teclado.next();
        
        System.out.println("Ingrese precio de del lavarropas: ");
        float precioL = teclado.nextFloat();
        
        System.out.println("Ingrese stock de del lavarropas: ");
        int stockL = teclado.nextInt();
        
        System.out.println("Ingrese cantidad de programas: ");
        int programas = teclado.nextInt();
        
        System.out.println("Ingrese cantidad soportada de kilos: ");
        float kilos = teclado.nextFloat();
        
        System.out.println("Ingrese valor de verdad de automatico: ");
        boolean automatico = teclado.nextBoolean();
        
        System.out.println("Ingrese cantidad de cuotas a pagar: ");
        int cuotasL = teclado.nextInt();
        
        System.out.println("Ingrese interes: ");
        float interesL = teclado.nextFloat();
        
        ArtefactoHogar l1= new Lavarropas(marcaL,precioL,stockL,programas,kilos,automatico);
        l1.imprimir();
        System.out.println("Cuotas: " + cuotasL + " - Interes: " + interesL + "%");
        System.out.println("Valor Cuota: U$D" + l1.cuotaCredito(cuotasL, interesL));
        System.out.println("Valor Cuota con Adicional: U$D" + l1.creditoConAdicional(cuotasL, interesL));
        System.out.println("\n");
        System.out.println("--------------------------------------------------");
        System.out.println("\n");
    }
}
