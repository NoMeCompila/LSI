import java.lang.Math;
public class Eje5{
    public static void main (String [] args){
        
        double a, b, c, disc, r1, r2;
        
        
        a = Float.parseFloat(args [0]);
        
        b = Float.parseFloat(args [1]);
        
        c = Float.parseFloat(args [2]);
        
        disc = Math.sqrt(Math.pow(b,2) - 4 * a * c);
        System.out.println("discriminante = " +disc);
        
        if(disc > 0){
            r1 = (- b + disc) / 2 * a;
            r2 = (- b - disc) / 2 * a;
            System.out.println("x1 = " + r1);
            System.out.println("x2 = " + r2);
        }else if(disc < 0){
            System.out.println("Raiz imaginaria...");
        }else{
            r1= - b / 2 * a;
            System.out.println("x1 = x2 = " + r1);
        }    
    }
}