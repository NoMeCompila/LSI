import java.util.Scanner;
public class Eje7{    
    public static void main(String [] args){
        
        Scanner input = new Scanner(System.in);
        
        
        double radio;
        double perimetro;
        int n;
        
        System.out.println("Ingrese radio: ");
        
        radio = input.nextDouble();
        perimetro = 2 * 3.14 * radio;
        
        System.out.println("El perimetro es: " + perimetro);
        System.out.println("Desea seguir ingresando valores? (1 = si / 0 = no) ");
        n = input.nextInt();
        
        while(n == 1){
              
            System.out.println("Ingrese radio: ");
            radio = input.nextDouble();
            
            perimetro = 2 * 3.14 * radio;
            System.out.println("El perimetro es: " + perimetro);
            
            System.out.println("Desea seguir ingresando valores? (1 = si / 0 = no)");
            n = input.nextInt();    
        }
    }
}