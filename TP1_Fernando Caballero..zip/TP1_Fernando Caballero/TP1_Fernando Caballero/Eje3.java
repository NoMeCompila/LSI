import java.lang.Math;
public class Eje3{    
    public static void main(String [] args){
        
        double radio = Integer.parseInt(args[0]);
        double perimetro;
        
        perimetro = 2 * Math.PI * radio;
        System.out.println("El perimetro es: " + perimetro);
        
    }
}