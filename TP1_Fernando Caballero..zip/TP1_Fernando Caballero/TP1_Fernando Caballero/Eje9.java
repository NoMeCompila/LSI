import java.util.Scanner;
public class Eje9{
    public static void main(String [] args){
        Scanner input = new Scanner (System.in);
        float vector[] = new float [4];
        float Min_value;
        float aux;
        
         for(int i = 0; i < 4; i++){ // para que el usuario llene el vector
            System.out.println("Digite un elemento: ");
            vector[i] = input.nextFloat();
        }
        
        System.out.println("\nlos elementos ingresados son: ");
        for(int i = 0; i < 4; i++){
            System.out.print(vector[i]+"\t");
        
        }
        
        /*for(int i = 0; i < 4; i++){
            if(vector[i] < Min_value) Min_value = vector[i];
        }
        
        System.out.println("\nEl menor elemento es " + Min_value);*/
        for(int i = 0; i < 4-1; i++){//metodo burbuja
            for(int j = 0; j < 4-1; j++){
                if(vector[j] > vector[j+1]){
                       aux = vector [j];
                       vector[j]=vector[j+1];
                       vector[j+1]=aux;
                }
            }
        }
        
        Min_value= vector[0];
        System.out.println("\n\nEl menor valor es: " + Min_value);
        
        System.out.println("\nElementos ordenados mediante el metodo burbuja: ");
        for(int i = 0; i < 4; i++){
            System.out.print(vector[i]+ "\t");
        }   
    }
}
