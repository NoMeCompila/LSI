import java.lang.Math;
public class Eje4{
    public static void main (String [] args){
        
        double a = Float.parseFloat(args [0]);
        double b = Float.parseFloat(args [1]);
        double c = Float.parseFloat(args [2]);
        double semiPer;
        double area;
        
        semiPer = (a + b + c) / 2;
        area = Math.sqrt(semiPer * (semiPer - a) * (semiPer - b) * (semiPer - c)); //La fórmula de Herón halla el área de un triángulo del cual se conocen todos sus lados. El área se calcula a partir del semiperímetro del triángulo s y de la longitud de los lados (a, b y c).
        
        System.out.println("El area vale: " + area);
        System.out.println("El semiperimetro vale: " + semiPer);
    }

}