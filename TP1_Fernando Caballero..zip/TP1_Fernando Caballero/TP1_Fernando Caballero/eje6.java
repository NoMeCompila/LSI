import java.lang.Math;
public class eje6{
    public static void main(String [] args){
        
        double h = Float.parseFloat(args [0]);
        double c1 = Float.parseFloat(args [1]);
        double c2 = Float.parseFloat(args [2]);
        

        
        if(Math.pow(h,2) == Math.pow(c1,2) + Math.pow(c2,2)){
            System.out.println("Es un triángulo rectángulo");
        }else{
            System.out.println("No es un triángulo rectángulo");
        }
        
    }
}