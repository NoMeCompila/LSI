public class Eje1{
    public static void main(String [] args){
        int a = 8;
        int b = 3;
        int res;
        
        res = a+b;
        System.out.println("Suma:"+res);
        res = a-b;
        System.out.println("resta:"+res);
        res = a*b;
        System.out.println("producto:"+res);
        res = a/b;
        System.out.println("cociente:"+res);
        res = a%b;
        System.out.println("modulo:"+res);
        
        
        
        
        
        
    }   
}