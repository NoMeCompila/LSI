import java.util.Scanner;
public class Eje8{
    public static void main(String [] args){
        float acum = 0;
        float prom;
        Scanner input = new Scanner (System.in);
        int notas[] = new int [5];// declaracion de vectores en java
        int Max_value = notas[0];
            for(int i = 0; i < 5; i++){ //guarda las notas y acumula
            System.out.println("Digite una nota: ");
            notas[i] = input.nextInt();
            acum += (float) notas [i];
            
        }
        
        System.out.println("\nlas notas son: ");
        for(int i = 0; i < 5; i++){
            System.out.print(notas[i]+"\t");
        
        }
        
        for(int i = 0; i < 5; i++){
            if(notas[i] > Max_value) Max_value = notas[i];
        }
        
        prom = acum / 5;
        System.out.println("\npromedio: " + prom);
        
        System.out.println("La nata mas alta es: " + Max_value);
    }
}
