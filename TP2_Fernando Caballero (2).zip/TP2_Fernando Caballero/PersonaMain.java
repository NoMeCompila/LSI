public class PersonaMain{
    public static void main(String [] args){
        Persona ejemploPersona = new Persona( 35123456, "Juan" , "Perez", 1997);

        System.out.println("Nombre y apellido: "+ejemploPersona.nomYApe()+ "\n");
        System.out.println("Apellido y nombre: "+ejemploPersona.apeYNom()+ "\n");
        System.out.println("Edad: "+ejemploPersona.edad()+ "\n");


        
        ejemploPersona.mostrar(); //Le mando el mensaje mostrar al objeto ejemploPersona
    }
}
