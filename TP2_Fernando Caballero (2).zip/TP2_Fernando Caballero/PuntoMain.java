import java.util.*;
public class PuntoMain{
    public static void main(String [] args){
        //instanciar puntos
        Scanner input = new Scanner(System.in);
        double x,y,dx,dy;
        
        System.out.println("Ingrese valor de abcisa: ");
        x = input.nextDouble();
        System.out.println("Ingrese valor de ordenada: ");
        y = input.nextDouble();
        
        
        Punto p1 = new Punto();
        Punto p2 = new Punto(x,y);
        p1.mostrar();
        p2.mostrar();
        
        System.out.println("Ingrese valor para desplazar abcisa: ");
        dx = input.nextDouble();
        
        System.out.println("Ingrese valor para desplazar ordenada: ");
        dy = input.nextDouble();
        p2.desplazar(dx,dy);
        //p2.mostrar();
        System.out.println(p2.coordenadas());
    }
}
