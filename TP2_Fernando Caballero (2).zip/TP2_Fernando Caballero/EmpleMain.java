//import java.io.*;
import java.util.*;
public class EmpleMain{
    public static void main(String args[]){
        //instancia de una clase
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese cuil: ");
        long cuil=teclado.nextLong();
        System.out.println("Ingrese nombre: ");
        String nombre=teclado.next();
        System.out.println("Ingrese Apellido: ");
        String apellido= teclado.next();
        System.out.println("Ingrese suledo Basico: ");
        double sueldoBasico=teclado.nextDouble();
        System.out.println("Ingrese anio de ingreso: ");
        int anioIngreso = teclado.nextInt();
        
        
        Empleado Empleado1 = new Empleado(cuil,apellido,nombre,sueldoBasico,anioIngreso);
        
        //llamada a metodo
        Empleado1.mostrar();
        Empleado1.mostrarLiena();
    }
}
