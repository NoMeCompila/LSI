/**
 * Descripcion: genera objetos  de la clase laboratorio que eprmite mostrar en pantalla el producto y el cliente que se comrpo
 * @author Caballero, Fernando
 * @version 1 Fecha: 26/08/2019
 */
public class Laboratorio{
    //atributos
    private String nom;
    private String dom;
    private String tel;
    private int compraMin;
    private int diaEntrega; 
    
    //setters 
    /**
     *descripcion: setter para nom
     *@param recibe un String p_nom (nombre)
     */
    private void setNom(String p_nom){
        this.nom = p_nom;
    }
    
    /**
     *descripcion: setter para dom
     *@param recibe un String p_dom (domicilio)
     */    
        private void setDom(String p_dom){
        this.dom = p_dom;
    }
    
    /**
     *descripcion: setter para tel
     *@param recibe un String p_tel (telefono)
     */    
        private void setTel(String p_tel){
        this.tel = p_tel;
    }
    
    /**
     *descripcion: setter para compraMin
     *@param recibe un entero p_compraMin (compra minima)
     */    
        private void setCompraMin(int p_compraMin){
        this.compraMin = p_compraMin;
    }
    
    /**
     *descripcion: setter para diaEntrega
     *@param recibe un entero p_diaEntrega (dia de entrega)
     */      
        private void setDiaEntrega(int p_diaEntrega){
        this.diaEntrega = p_diaEntrega;
    }
    
    //getters
    /**
    *descripcion: getter para nom
    *@return retorna un String nom (nombre)
    */  
    public String getNom(){
        return "\tnombre: " + this.nom;
    }
    
    /**
    *descripcion: getter para dom
    *@return retorna un String dom (domicilio)
    */     
    public String getDom(){
        return "\tdomicilio: " + this.dom;
    }
    
    /**
     * Descripcion: getter para el atributo tel
     * @return retorna un string tel (numero de telefono del cliente)
     */
    public String getTel(){
        return "\ttel: " + this.tel;
    }
     /**
     * Descripcion: getter para el atributo compraMin
     * @return retorna un entero compraMin(compra minima del cliente)
     */
    public int getCompraMin(){
        return this.compraMin;
    }
    
     /**
     * Descripcion: getter para el atributo diaEntrega
     * @return retorna un entero diaEntrega (dia de entrega del producto)
     */    
    public int getDiaEntrega(){
        return this.diaEntrega;
    }
    
    //metodo constructores (sobrecarga)
    /**
     * constructor para objetos de la clase Laboratorio 
     */
    public  Laboratorio(String p_nom, String p_dom, String p_numTel){
        this.setNom(p_nom);
        this.setDom(p_dom);
        this.setTel(p_numTel);
    }
    
    /**
     * contructor sosbrecargado para objetos de la clase laboratorio 
     */
    public Laboratorio(String p_nom, String p_dom, String p_numTel, int p_compraMin,  int p_diaEntrega){
        this.setNom(p_nom);
        this.setDom(p_dom);
        this.setTel(p_numTel);
        this.setCompraMin(p_compraMin);
        this.setDiaEntrega(p_diaEntrega);
    }
    
}

  