import java.util.*;
/**
 * Descripcion: genera objetos  de la clase Empleado y permite mostrar los datos de cada empleado a demas de saber su antigüedad y en abse a esto calcular su sueldo automáticamente
 * @version 1.0 Fecha: 26/08/2019
 */
//clase Empleado
public class Empleado{
    //Atributos
    private long cuil;
    private String ape;
    private String nom;
    private double sueldoBasico;
    private int anioIngreso;
    //getters
    /**
     * descripcion: getter para el atributo cuil
     * @return retorna un long cuil
     */
    public long getCuil(){
        return this.cuil;
    }

       /**
     * descripcion: getter para el atributo ape
     * @return retorna un String ape (apellido)
     */
    public String getApe(){
        return this.ape;
    }
       /**
     * descripcion: getter para el atributo nom
     * @return retorna un String nom (nombre)
     */
    public String getNom(){
        return this.nom;
    }
       /**
     * descripcion: getter para el atributo sueldoBasico
     * @return retorna un double sueldoBasico
     */
    public double getSueldoBasico (){
        return this.sueldoBasico;
    }
     /**
     * descripcion: getter para el atributo anioIngreso
     * @return retorna un entero anioIngreso(año en que empezó a trabajar el empleado)
     */
    public int getAnioIngreso (){
        return this.anioIngreso;
    }
    

    //setters
    
    /**
     * descripcion: setter para el atributo cuil
     * @param recibe un long p_cuil
     */
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }

     /**
     * descripcion: setter para el atributo ape
     * @param recibe un String p_ape (apellido del empleado)
     */
    private void setApe(String p_ape){
        this.ape = p_ape;
    }

      /**
     * descripcion: setter para el atributo nom
     * @param recibe un String p_nom (nombre del empleado)
     */   
    private void setNom(String p_nom){
        this.nom = p_nom;
    }

    
      /**
     * descripcion: setter para el atributo sueldoBasico
     * @param recibe un double p_sueldoBasico
     */ 
    private void setSueldoBasico(double p_sueldoBasico){
        this.sueldoBasico = p_sueldoBasico;
    }

    
     /**
     * descripcion: setter para el anioIngreso
     * @param recibe un entero p_anioIngreso (año en el que ingresó el empleado)
     */ 
    private void setAnioIngreso(int p_anioIngreso){
        this.anioIngreso = p_anioIngreso;
    }
 //constructor
 /**
  * descripcion: cosntructor para objetos de la clase Empleado
  */
    public Empleado(long p_cuil,String p_ape,String p_nom,double p_sueldoBasico,int p_anioIngreso){

        setCuil(p_cuil);
        setApe(p_ape);
        setNom(p_nom);
        setSueldoBasico(p_sueldoBasico);
        setAnioIngreso(p_anioIngreso);
    }
    //metodos
    /**
     * descripcion: muestara en pantalla una cadena con el apellido y nombre de un empleado
     * @return retorna una cadena con dos strings ape y nom (apellido y nombre de un empleado)
     */
    public String apeYnom(){
        return this.getApe()+" "+this.getNom();
    }
    /**
     * descripcion: muestara en pantalla una cadena con el nombre y apellido de un empleado
     * @return retorna una cadena con dos strings nom y ape (nombre y apellido de un empleado)
     */
    public String nomYape(){
        return this.getNom()+" "+this.getApe();
    }
    /**
     * descripcion: calcula la antigüedad de un empleado restandole al año actual el año de ingreso
     * @return retornaun entero v_antigüedad (hace cuantos años trabaja el empleado)
     */
    public int antiguedad(){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        int v_antiguedad = anioHoy - this.getAnioIngreso();
        return v_antiguedad;
    }
    
    /**
     * descripcion: descuenta al sueldo basico el seguro de vida y obra socioal
     * @return retorna un double desc (descuento)
     */
    public double descuento(){
        double desc = (this.getSueldoBasico() * 0.2) - 12;
        return desc;
    }
    
    /**
     * descripcion: suma al sueldo absico un aumneto adicional en base a la antigüedad del empleado
     * @return retorna un double adi (adicional)
     */
    public double adicional(){
        double adi = 0;
        if(this.antiguedad() < 2){
             adi =(this.sueldoBasico * 0.2);
            }else if((this.antiguedad() >= 2 )&&(this.antiguedad() < 10)){
                      adi = (this.sueldoBasico * 0.4);
                  }else if(this.antiguedad() >= 10){
                            adi = (this.sueldoBasico * 0.6);
            }  
        return adi;
    }
    
    /**
     * Descripcion: calcula el sueldo neto teniendo en cuenta el descuento y el adicional de cada empleado
     * @return retorna un double neto (sueldo neto del empleado)
     */
    public double saldoNeto(){
        double neto = this.getSueldoBasico() + this.adicional() - this.descuento();
        return neto;
        
    }
    
    /**
     * descripcion: muestra en pantalla los datos de un empleado y su sueldo neto
     */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYape());
        System.out.println("CUIL: "+this.getCuil()+" Antigüedad: "+this.antiguedad()+" años.");
        System.out.println("Saldo neto: U$D "+this.saldoNeto());
    }

     /**
     * descripcion: muestra en pantalla los datos de un empleado y su sueldo neto en una sola línea
     */
    public void mostrarLiena(){
        System.out.println(this.getCuil() + "\t" + this.apeYnom() + " ........... " + "U$D " + this.saldoNeto());
    }
}