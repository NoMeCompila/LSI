import java.util.*;
public class AlumMain{
    public static void main (String [] args){
        int lu = Integer.valueOf(args[0]);
        double not1 = Double.valueOf(args[3]);
        double not2 = Double.valueOf(args[4]);
        Alumno Alumno1 = new Alumno(lu, args[1], args[2], not1, not2);
        
        int a = Integer.valueOf(args[5]);
        double b =Double.valueOf(args[8]);
        double c =Double.valueOf(args[9]);
        
        Alumno Alumno2 = new Alumno(a, args[6], args[7], b, c);
        Alumno1.mostrar();
        Alumno2.mostrar();
    }
}
