import java.util.*;
public class ClienteMain{
   public static void main (String [] args){
       int a = Integer.parseInt(args[0]);
       double b = Double.valueOf(args[3]);
       double d = Double.valueOf(args[4]);
       double e = Double.valueOf(args[5]);
       
       Cliente Cliente1 = new Cliente(a, args[1], args[2], b);
       Cliente1.mostrar();
       System.out.println(Cliente1.apeYnom());
       System.out.println(Cliente1.nomYape());
       Cliente1.agregaSaldo(d);
       System.out.println("Nuevo saldo: U$D "+Cliente1.agregaSaldo(d));
       
       System.out.println("Saldo modificado: U$D "+Cliente1.nuevoSaldo(e));
   }
}
