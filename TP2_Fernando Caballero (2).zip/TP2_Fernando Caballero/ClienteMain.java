import java.util.*;
public class ClienteMain{
   public static void main (String [] args){
       int a = Integer.parseInt(args[0]);
       double b = Double.valueOf(args[3]);
       double d = Double.valueOf(args[4]);
       double e = Double.valueOf(args[5]);
       
       Cliente cliente1 = new Cliente(a, args[1], args[2], b);
       cliente1.mostrar();
       System.out.println(cliente1.apeYnom());
       System.out.println(cliente1.nomYape());
       cliente1.agregaSaldo(d);
       System.out.println("Nuevo saldo: U$D "+cliente1.agregaSaldo(d));
       
       System.out.println("Saldo modificado: U$D "+cliente1.nuevoSaldo(e));
   }
}
