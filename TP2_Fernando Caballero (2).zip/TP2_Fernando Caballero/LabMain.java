public class LabMain{
    public static void main (String [] args){
        Laboratorio Laboratorio1 = new Laboratorio("Fernando","Perugorria 228","3794006302");
        System.out.println(Laboratorio1.getNom());
        System.out.println(Laboratorio1.getDom());
        System.out.println(Laboratorio1.getTel());
        System.out.println("\n");
        Laboratorio Laboratorio2 = new Laboratorio("Martin", "Lavalle 222", "3795020301", 100, 10);    
        System.out.println(Laboratorio2.getNom());
        System.out.println(Laboratorio2.getDom());
        System.out.println(Laboratorio2.getTel());
        System.out.println("\tcompra minima: $"+Laboratorio2.getCompraMin());
        System.out.println("\tdia de entrega: "+Laboratorio2.getDiaEntrega());
    }
}
