/**
 * Descripcion: esta clase genera objetos en el cual se puede manipular y ver el saldo de los clientes  
 * @author Caballero, Fernando
 * @version 1 Fecha: 26/08/2019
 */
public class Cliente{
    //atributos
    private int nroDNI;
    private String ape;
    private String nom;
    private double saldo;
    
    //setters
    /**
     * este metodo asigna un valor al atributo nroDni 
     * @param recibe un entero p_nroDNI(numero de DNI)
     */
    private void setNroDNI(int p_nroDNI){
        this.nroDNI = p_nroDNI;
    }
    
    /**
     * este metodo asigna un valor al atributo apellido 
     * @param recibe un String p_ape(apellido)
     */
    private void setApe(String p_ape){
        this.ape = p_ape;    
    }
    
    /**
     * este metodo asigna un valor al atributo nombre 
     * @param recibe un String p_nom (nombre)
     */
    private void setNom(String p_nom){
        this.nom = p_nom;
    }
    
    /**
     * este metodo asigna un valor al atributo saldo
     * @param recibe un double p_saldo 
     */
    private void setSaldo(double p_saldo){
        this.saldo = p_saldo;
    }
    
    //getters
    /**
     * metodo getter
     * @return retorna un int nroDNI (numero de DNI)
     */
    public int getNroDNI(){
        return this.nroDNI;
    }
    
     /**
     * metodo getter
     * @return retorna un String ape (apellido)
     */
    public String getApe(){
        return this.ape;
    }
    
     /**
     * metodo getter
     * @return retorna un String nom(nombre) 
     */
    public String getNom(){
        return this.nom;
    }
    
     /**
     * metodo getter
     * @return retorna un double saldo 
     */
    public double getSaldo(){
        return this.saldo;
    }
    
     /**
     * descripcion: constructor de clase cliente
     */
    //constructor
    public Cliente(int p_nroDNI, String p_ape, String p_nom, double p_saldo){
        this.setNroDNI(p_nroDNI);
        this.setApe(p_ape);
        this.setNom(p_nom);
        this.setSaldo(p_saldo);
    }
    
    //metodos
     /**
     * descripcion: el metodo muestra por pantalla los datos de un cliente
     * 
     */
    public void mostrar(){
        System.out.println("\t\tClientes");
        System.out.println("Apellido y Nombre: "+this.apeYnom()+" ("+this.getNroDNI()+")");
        System.out.println("Saldo: U$D "+this.getSaldo());
    }
    
     /**
     * descripcion: el metodo retorna los atributos apellido y nombre 
     */
    public String apeYnom(){
        return this.getApe()+" "+this.getNom();
    }
    
     /**
     * descripcion: este metodo retorna nombre y apellido
     * 
     */
    public String nomYape(){
        return this.getNom()+" "+this.getApe();
    }
    
    /**
     * descripcion: suma un importe al saldo actual
     * @param recibe un double p_importe
     * @return retorna un double newSaldo
     */
    public double agregaSaldo(double p_importe){
        double newSaldo = this.getSaldo() + p_importe; 
        this.setSaldo(newSaldo);
        return newSaldo;
    }
    
    /**
     * descripcion: este metodo reemplaza el sueldo actual con un  nuevo importe
     * @param recibe un parametro de tipo double p_saldo
     * @return retorna un double saldo
     */
    
    public double nuevoSaldo(double p_saldo){
        this.setSaldo(p_saldo);
        return this.getSaldo();
    }
}












