public class LabMain{
    public static void main (String [] args){
        Laboratorio laboratorio1 = new Laboratorio("Colgate S.A.","Junin 5204","3794006302");
        laboratorio1.ajusteCompraMinima(50);
        laboratorio1.mostrar();
        
        Laboratorio laboratorio2 = new Laboratorio("oralB", "Lavalle 222", "3795020301", 100, 10);    
        laboratorio2.ajusteCompraMinima(50);
        laboratorio2.mostrar();
        
    }
}
