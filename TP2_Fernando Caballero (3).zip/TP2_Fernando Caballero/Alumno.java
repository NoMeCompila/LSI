/**
 * Descripcion: genera objetos  de la clase Alumno y permite mostrar en pantalla los datos del alumno asi como tambien si fueron aprovados ao no 
 * @author Caballero, Fernando
 * @version 1.0 Fecha: 26/08/2019
 */
public class Alumno{
   
   //atributos
   private  int     lu;
   private  String  nom;
   private  String   ape;
   private  double   not1;
   private  double   not2;
     public Alumno(int p_lu, String p_nom, String p_ape, double p_not1, double p_not2){
       this.setLu(p_lu);
       this.setNom(p_nom);
       this.setApe(p_ape);
       this.setNot1(p_not1);
       this.setNot2(p_not2);
   }
   //getters
   /**
    * getter para el atributo lu (libreta universitatia)
    * @return retorna un entero lu (Libreta Universitaria de alumno )
    */
   public int getLu(){
       return this.lu;
   }
   
   /**
    * descripcion: getter para el atributo nombre
    * @return retorna un String nom (nombre del alumno)
    */
   public String getNom(){
       return this.nom;
   }

    /**
    * descripcion: getter para el atributo ape
    * @return retorna un String ape (apelido del alumno)
    */
   
   public String getApe(){
       return this.ape;
   }
     /**
    * descripcion: getter para el atributo not1 (1er nota)
    * @return retorna un double not1 (nota 1)
    */
   public double getNot1(){
       return this.not1;
   }
   
    /**
    * descripcion: getter para el atributo not2 (2da nota)
    * @return retorna un double not2 (nota 2)
    */
    public double getNot2(){
      return this.not2;
   }
   //setters
   /**
    *  descripcion: setter para lu (libreta universitaria )
    * @param recibe como parametro un entero p_lu (libreta universitaria)
    */
   private void setLu(int p_lu){
       this.lu = p_lu;
   }
   /**
    *  descripcion: setter para nom (nombre del alumno)
    * @param recibe como parametro un string p_nom  (nombre)
    */   
   private void setNom(String p_nom){
       this.nom = p_nom;
   }

    /**
    *  descripcion: setter para ape (apellido del alumno )
    * @param recibe como parametro un string p_ape  (apellido)
    */ 
   private void setApe(String p_ape){
       this.ape = p_ape;
   }

    /**
    *  descripcion: setter para not1 (nota 1)
    * @param recibe como parametro un double p_not1
    */ 
   private void setNot1(double p_not1){
       this.not1 = p_not1;
   }
   
    /**
    * descripcion: setter para not2 (nota 2)
    * @param recibe como parametro un double p_not2
    */    
    private void setNot2(double p_not2){
       this.not2 = p_not2;
   }
   //constructor
   /**
    * constructor para la clase Alumno
    */
 
   //metodos
   /**
    * descripcion: retorna una cadena String  con apellido y nombre del alumno
    * @retorna una cadena de String con ape y nom (apellido y nombre del alumno)  
    */
   public String apeYnom(){
       return this.getApe()+" "+this.getNom();
   }
   
    /**
    * descripcion: retorna una cadena String  con apellido y nombre del alumno
    * @return: retorna una cadena de String nom y ape (nombre y apellido del alumno)
    */
   public String nomYape(){
       return this.getNom()+" "+this.getApe();
   }
   
   /**
    * descripcion:calcula el promedio de un alumno en bse a dos notas
    * @return retorna un double prom (promedio)
    */
   public double promedio(){
      double acum = this.getNot1() + this.getNot2();
      double prom = acum/2;
      return prom;
   }
   
   /**
    * descripcion: retorna verdadero o falso en funcion a las notas de un alumno para saber si aprobó o desaprobó
    * @return devuelve un  boolean 
    */
   public boolean aprueba(){
       return (((this.getNot1() >= 6.0 )&&(this.getNot2() >= 6.0)) && this.promedio() >= 7);//los metodos booleanos se pueden obviar los if ya que devuelven siempre verdordadero o falso  
   }
   
   /**
    * descripcion: muestra en poantalla si un alumno esta aprobado o no
    * @return devuelve una cadena APROBADO O DESAPROBADO en funcion de el resultado del metodo aprueba()
    */
   public String leyendaAprueba(){
       if(this.aprueba()==true){
           return "APROBADO";
       }else{
           return "DESAPROBADO";
       }
   }
   
   /**
    * descripcion: muestra en pantalla los datos de un alumno, el promedio y si estan aprobados o desaprobados
    */
   public void mostrar(){
       System.out.println("Nombre y Apellido: "+this.nomYape());
       System.out.println("LU: "+this.getLu());
       System.out.println("Notas: "+this.getNot1()+"-"+this.getNot2());
       System.out.println("Promedio: "+this.promedio());
       System.out.println(this.leyendaAprueba());
   }
}








