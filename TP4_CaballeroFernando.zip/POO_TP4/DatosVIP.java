/**
 * descripcion: genera un archivo con los empleados que tengan mas de 10 años trabajando en la empresa y lee los datos almacenados
 * @author Caballero, Fernando 
 * @version 1.0
 */
import java.io.*;
import java.util.*;
public class DatosVIP{
    public static void main(String args []){
        
        try{
            FileOutputStream archiFOS = new FileOutputStream("C:\\Users\\one\\Desktop\\archivos\\Empleados.dat",true);
            DataOutputStream archiDOS = new DataOutputStream(archiFOS);
            FileInputStream archiFIS = new FileInputStream ("C:\\Users\\one\\Desktop\\archivos\\Empleados.dat");
            DataInputStream archiDIS = new DataInputStream(archiFIS);
            while(archiDIS.available()>0){
                long p_cuil = archiDIS.readLong();
                String p_nom = archiDIS.readUTF();
                String p_ape = archiDIS.readUTF();
                double p_sueldoBasico = archiDIS.readDouble();
                double p_sueldoNeto = archiDIS.readDouble();                
                int p_dia = archiDIS.readInt();
                int p_mes = archiDIS.readInt();
                int p_anio = archiDIS.readInt();
                //instancia del objeto fecha
                 Calendar p_fecha = new GregorianCalendar(p_anio,p_mes,p_dia);
                //instancia del objeto Empleado
                Empleado empleado1 = new Empleado(p_cuil,p_ape,p_nom,p_sueldoBasico,p_fecha);
                if (empleado1.antiguedad() > 10){
                    archiDOS.writeLong(empleado1.getCuil());
                    archiDOS.writeUTF(empleado1.getNom());
                    archiDOS.writeUTF(empleado1.getApe());
                    archiDOS.writeDouble(empleado1.getSueldoBasico());
                    archiDOS.writeDouble(empleado1.saldoNeto());
                    archiDOS.writeInt(p_dia);
                    archiDOS.writeInt(p_mes);
                    archiDOS.writeInt(p_anio);
                }
                empleado1.mostrarLiena();
            }
            archiDIS.close();
            archiDOS.close();
        }
        catch(FileNotFoundException fnfe){
            System.out.println("Archivo no encontrado");
        }
        catch (IOException ioe){
            System.out.println("Error al Leer");
        }
    }
}
