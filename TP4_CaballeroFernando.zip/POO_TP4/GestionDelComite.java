import java.io.*;
import java.util.*;
public class GestionDelComite{
    public static void main(String[] args){
            String cobertura           = "";
            double valorPoliza         = 0;
            double valorAsegurado      = 0;
            String momentoCancelacion  = "";
            String agricultor          = ""; 
            String cultivo             = "";
            double porcentajeDaño     = 0;
        
        
            char opcion = 'S';
            // creando objeto teclado
            BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
            try {
                // Creando un objeto de tipo archivo secuencial
                FileOutputStream archiFOS = new FileOutputStream("C:\\Users\\one\\Desktop\\archivos\\Poliza.dat",true);
                DataOutputStream archiDOS = new DataOutputStream(archiFOS);
                while(opcion != 'n' && opcion != 'N'){
                
                
                    System.out.println("\nINGRESAR DATOS DE LA UNIDAD DE RIESGO:\n ");
                
                    System.out.printf("Apellido y Nombre del Agricultor: ");
                    agricultor = teclado.readLine();
                
                    System.out.print("\ncultivo: ");
                    cultivo = teclado.readLine();
                
                    System.out.println("\n***Ingrese fecha de Cosecha***");
                    System.out.print("\nDia: ");
                    int diaC=Integer.parseInt(teclado.readLine());
                    System.out.print("\nMes: ");
                    int mesC=Integer.parseInt(teclado.readLine());
                    System.out.print("\nAńo: ");
                    int anioC=Integer.parseInt(teclado.readLine());
                    
                    Calendar fechaCosecha = new GregorianCalendar(anioC, mesC, diaC);
                    
                    System.out.println("\nINGRESAR DATOS DEL SINIESTRO:\n ");
                    
                    System.out.println("\n***Ingrese fecha en que ocurrio el siniestro***");
                    System.out.print("\nDia: ");
                    int diaSini=Integer.parseInt(teclado.readLine());
                    System.out.print("\nMes: ");
                    int mesSini=Integer.parseInt(teclado.readLine());
                    System.out.print("\nAńo: ");
                    int anioSini=Integer.parseInt(teclado.readLine());
                    
                    Calendar fechaSiniestro = new GregorianCalendar(anioSini, mesSini, diaSini);
                    
                    
                    System.out.print("\ningrese Porcentaje de Danio:\n ");
                    porcentajeDaño = Double.parseDouble(teclado.readLine());
                    
                    System.out.println("\nINGRESAR DATOS DE POLIZA: ");
                    
                    System.out.print("\nCobertura (granizo, incendio o  resiembra): ");
                    cobertura = teclado.readLine();
                    
                    System.out.print("\nvalor de poliza: ");
                    valorPoliza = Double.parseDouble(teclado.readLine());
                    
                    System.out.print("\nIngrese valor Asegurado (monto monetario de la unidad de riesgo): ");
                    valorAsegurado = Double.parseDouble(teclado.readLine());
                    
                    System.out.print("\nIngrese momento de Cancelacion (inicial o final): ");
                    momentoCancelacion = teclado.readLine();
                    
                    Calendar fechaContrato = new GregorianCalendar();
                    
                    
                    System.out.println("\n-----------------------------------------------------------------------\n\n");
                    
                    Siniestro siniestro = new Siniestro( fechaSiniestro,porcentajeDaño);
                    
                    UnidadDeRiesgo unidad = new UnidadDeRiesgo(agricultor, cultivo, fechaCosecha);
                    
                    Poliza poliza = new Poliza(cobertura, fechaContrato, valorPoliza, valorAsegurado, momentoCancelacion, siniestro, unidad );
                    
                    
                    poliza.resumenIndemnizaciones();
                    
                    //grabando el archivo
                    archiDOS.writeUTF(poliza.getCobertura());
                    archiDOS.writeUTF(unidad.getCultivo());
                    archiDOS.writeDouble(siniestro.getPorcentajeDanio());
                    archiDOS.writeDouble(poliza.indemnizacion());
                    
                    System.out.println("Más datos ? (S/N): ");
                    opcion=teclado.readLine().charAt(0);
                }
                archiDOS.close();
            } // cierra try
            catch(FileNotFoundException fnfe) {
                System.out.println("Archivo no encontrado");
            }
            catch(IOException ioe){
                System.out.println("Error al grabar");
            }
        } // cierra main
    } // cierra clase