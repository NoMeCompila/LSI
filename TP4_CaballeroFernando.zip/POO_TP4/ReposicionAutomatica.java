/**
 * descripcion ejecutable del ejercicio 6
 * @author Caballero, Fernando
 * @version 1.0
 */
import java.util.*;
import java.io.*;
public class ReposicionAutomatica{
    public static void main(String args []){
        int codi = 0;
        String rubro = "";
        String descripcion= "";
        int existenciaMin = 0;
        double porPuntoRepo = 0;
        int stock = 0;
        double precio = 0;
        int codLab = 0;
        int codigoLaboratorio = 0;
        String nombreLaboratorio = "";
        String domicilioLaboratorio = "";
        String telefonoLaboratorio = "";
        int compraLaboratorio = 0;
        int diaLaboratorio = 0;
        long tamRegistro = 192;
        long cantRegistro = 0;
        char razonCompra = 'N';
        int cantF = 0;
        int cantP = 0;
        double totalCompra = 0;
        Calendar fechaHoy = new GregorianCalendar();
        String diaHoy = String.valueOf(fechaHoy.get(Calendar.DATE));
        String mesHoy = String.valueOf(fechaHoy.get(Calendar.MONTH) + 1);
        String anioHoy = String.valueOf(fechaHoy.get(Calendar.YEAR));

        
        try {
            FileInputStream archiFIS = new FileInputStream("C:\\Users\\one\\Desktop\\archivos\\Productos.dat");
            DataInputStream archiDIS = new DataInputStream(archiFIS);
            RandomAccessFile archi = new RandomAccessFile("C:\\Users\\one\\Desktop\\archivos\\Productos.dat", "r");
            cantRegistro = archi.length() / tamRegistro;
            FileOutputStream archiFOS = new FileOutputStream("C:\\Users\\one\\Desktop\\archivos\\" + anioHoy + mesHoy + diaHoy + ".txt", true);
            DataOutputStream archiDOS = new DataOutputStream(archiFOS);
            System.out.println("Listado de productos a comprar el " + fechaHoy);
            System.out.println("");
            while (archiDIS.available() > 0) {
                codi = archiDIS.readInt();
                rubro = archiDIS.readUTF();
                descripcion = archiDIS.readUTF();
                existenciaMin = archiDIS.readInt();
                porPuntoRepo = archiDIS.readDouble();
                stock = archiDIS.readInt();
                precio = archiDIS.readDouble();
                codLab = archiDIS.readInt();

                archi.seek(codLab * tamRegistro);
                codigoLaboratorio = archi.readInt();
                nombreLaboratorio = "";
                for (int i=0; i < 30; i++){
                    nombreLaboratorio += archi.readChar();
                }
                domicilioLaboratorio = "";
                for (int i=0; i < 30; i++){
                    domicilioLaboratorio += archi.readChar();
                }
                telefonoLaboratorio = "";
                for (int i=0; i < 30; i++){
                    telefonoLaboratorio += archi.readChar();
                }
                compraLaboratorio = archi.readInt();
                diaLaboratorio = archi.readInt();

                Laboratorio laboratorio = new Laboratorio(nombreLaboratorio, domicilioLaboratorio, telefonoLaboratorio);
                laboratorio.ajusteCompraMinima(compraLaboratorio);
                laboratorio.ajusteDiaEntrega(diaLaboratorio);
                Productos producto = new Productos(codi, rubro, descripcion, precio, laboratorio, stock, porPuntoRepo, existenciaMin);            
                if (producto.solicitar() == 'P'){
                    cantP = cantP + 1;}
                    else{
                if (producto.solicitar() == 'F'){
                    cantF = cantF + 1;}
                }

                if (producto.solicitar() != 'N') {

                    System.out.println("Producto: " + producto.getDescripcion());
                    laboratorio.mostrar();
                    System.out.println("Cantidad a comprar: " + laboratorio.getCompraMin() + " paquetes  Dia de entrega: " + laboratorio.getDiaEntrega() + " del mes");
                    System.out.print("\n\n");

                    archiDOS.writeInt(producto.getCodi());
                    archiDOS.writeInt(codigoLaboratorio);
                    archiDOS.writeInt(laboratorio.getCompraMin());
                    archiDOS.writeDouble(laboratorio.getCompraMin() * producto.getCosto());
                    archiDOS.writeChar(razonCompra);

                    totalCompra += laboratorio.getCompraMin() * producto.getCosto();
                }                
            }
            archiDOS.close();
            archiDIS.close();
            archi.close();

            System.out.println("Numero de productos a reponer:" + (cantF + cantP));
            System.out.println("Importe total de la compra planificada: $  " + totalCompra);
            System.out.println("Numero de compras por faltante de stock: " + cantF);
            System.out.println("Numero de compras por punto de reposicion: " + cantP);
            System.out.println("-----------------------------------------------------------------------------------------------------");
            System.out.println("Archivo creado: comprar_" + anioHoy + mesHoy + diaHoy + ".txt");
            System.out.println("-----------------------------------------------------------------------------------------------------");
        }
        catch(FileNotFoundException fnfe){
            System.out.println("No se pudo encontrar el archivo");
        }
        catch(IOException ioe){
            System.out.println("Error al leer");
        }

    }
}

