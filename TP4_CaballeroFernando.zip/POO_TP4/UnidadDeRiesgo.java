/**
 * Descripcion: crea objetos de la clase UnidadDeRiesgo
 * @author Caballero, Fernando
 * @version 1.0
 */
import java.util.*;
public class UnidadDeRiesgo{
    
    private String agricultor;
    private String cultivo;
    private Calendar fechaCultivo;
    
    /**
     * constructor de la clase UnidadDeRiesgo
     * @param String p_agricultor, String p_cultivo, Calendar p_fechaCultivo
     */
    
    public UnidadDeRiesgo(String p_agricultor, String p_cultivo, Calendar p_fechaCultivo){
        this.setAgricutor(p_agricultor);
        this.setCultivo(p_cultivo);
        this.setFechaCultivo(p_fechaCultivo);
    }
    
    /**
     * descripcion: getter para el atributo agricultor
     * @return agricultor
     */
    public String getAgricultor(){
        return this.agricultor;
    }
    
    /**
     * descripcion: getter para el atributo cultivo
     * @return cultivo
     */
    
    public String getCultivo(){
        return this.cultivo;
    }
    
    /**
     * Descripcion: getter para el atributo fechaCultivo
     * @return fechaCultivo
     */
    public Calendar getFechaCultivo(){
        return this.fechaCultivo;
    }
    
    /**
     * descripcion: setter para el atributo agricultor
     * @param p_agricultor
     */
    private void setAgricutor(String p_agricultor){
        this.agricultor = p_agricultor;
    }
    
    /**
     * descricpcion: setter para el atributo cultivo
     * @param p_cultivo
     */
    
    private void setCultivo(String p_cultivo){
        this.cultivo = p_cultivo;
    }
    
    /**
     * descripcion: setter del atributo fechaCultivo
     * @param p_fechaCultivo
     */
    private void setFechaCultivo(Calendar p_fechaCultivo){
        this.fechaCultivo = p_fechaCultivo;
    }
    
    /**
     * descripcion: muestra los detalles en pantalla
     */
    public void mostrarDetalle(){
        System.out.println("-Agricultor: "+this.getAgricultor());
        System.out.println("-Cultivo: "+this.getCultivo());
    }
}
