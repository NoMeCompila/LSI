/**
 * descripcion: permite ejecutar el objeto fundacion para imprimir invitaciones  
 * @author Caballero, Fernando 
 * @version 1.0
 */
import java.io.*;
import java.util.*;
public class Administración{
    public static void main(String args []){
        String nombreFundacion = " ";
        Fundacion fundacion1;
        String nombreEvento = " ";
        String lugarEvento = " ";
        int diasInscripcion = 0;
        double costoEvento = 0;
        int diaEvento = 0;
        int mesEvento = 0;
        int anioEvento = 0;
        Calendar fecha = new GregorianCalendar(2016,5,5);
        Evento evento1;
        int dni = 0;
        String apellido = " ";
        String nombre = " ";
        int diaNacimiento = 0;
        int mesNacimiento = 0;
        int anioNacimiento = 0;
        Persona invitado;
        Calendar fechaNac = new GregorianCalendar();
        Scanner teclado = new Scanner(System.in);
        teclado.useDelimiter("\n");
        
        System.out.print("Ingrese el nombre de la fundacion: ");
        nombreFundacion = teclado.next();
        fundacion1 = new Fundacion(nombreFundacion);
        System.out.print("Ingrese Nombre del evento: ");
        nombreEvento = teclado.next();
        System.out.print("Ingrese Lugar del evento: ");
        lugarEvento = teclado.next();
        System.out.print("Ingrese dias de inscripcion con antelacion: ");
        diasInscripcion = teclado.nextInt();
        System.out.print("Ingrese Costo de la entrada: ");
        costoEvento = teclado.nextDouble();
        System.out.print("Ingrese dia del evento: ");
        diaEvento = teclado.nextInt();
        System.out.print("Ingrese mes del evento: ");
        mesEvento = teclado.nextInt();
        System.out.print("Ingrese Anio del evento: ");
        anioEvento = teclado.nextInt();
        evento1 = new Evento(nombreEvento, lugarEvento, fecha, diasInscripcion, costoEvento);

        try {
            FileInputStream archiFIS = new FileInputStream("C:\\Users\\one\\Desktop\\archivos\\invitados.dat");
            DataInputStream archiDIS = new DataInputStream(archiFIS);
            FileOutputStream archiFOS = new FileOutputStream("C:\\Users\\one\\Desktop\\archivos\\invitados.dat", true);
            DataOutputStream archiDOS = new DataOutputStream(archiFOS);

            while (archiDIS.available() > 0){
                dni = archiDIS.readInt();
                apellido = archiDIS.readUTF();
                nombre = archiDIS.readUTF();
                diaNacimiento = archiDIS.readInt();
                mesNacimiento = archiDIS.readInt();
                anioNacimiento = archiDIS.readInt();
                fechaNac.set(anioNacimiento, mesNacimiento - 1, diaNacimiento);
                invitado = new Persona(dni, nombre, apellido, fechaNac);
                fundacion1.imprimirInvitacion(evento1, invitado);
                fundacion1.grabarInvitacion(evento1, invitado, archiDOS);
            }
            archiDIS.close();
            archiDOS.close();
        }
        catch (FileNotFoundException fnfe){
            System.out.println("Archivo no encontrado");
        }
        catch (IOException ioe){
            System.out.println("Error al leer");
        }
    }
    }    

