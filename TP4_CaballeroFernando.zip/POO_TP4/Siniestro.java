/**
 * descripcion: permite crear objetos de la clase Siniestro
 * 
 * @author Caballero, Fernando
 * @version 1.0
 */
import java.util.*;
public class Siniestro{
    private Calendar fecha;
    private double porcentajeDanio;
    
    /**
     * descripcion setter para el atributo fecha
     * @return fecha
     */
    public Calendar getFecha(){
        return this.fecha;
    }
    /**
     * descripcion: setter para el atributo fecha
     * @param Claendar fecha
     */
    
    private void setFecha(Calendar p_fecha){
        this.fecha = p_fecha;
    }
    /**
     * descripcion: getter para el atributo  porcentajeDanio
     * @return porcentajeDanio
     */
    public double getPorcentajeDanio(){
        return this.porcentajeDanio;
    }
    
    /**
     * Descripcion: setter para el atributo porcentajeDanio
     * @param p_porcentajeDanio
     */
    
    private void setPorcentajeDanio(double p_porcentajeDanio){
        this.porcentajeDanio = p_porcentajeDanio;
    }
    
    /**
     * descripcion: cosntructor de la clase Siniestro
     * @param Calendar p_fecha, double p_porcentajeDanio
     */
    
    public Siniestro(Calendar p_fecha, double p_porcentajeDanio){
        this.setFecha(p_fecha);
        this.setPorcentajeDanio(p_porcentajeDanio);
    }
    /**
     * Descripcion: permite saber el total del porcentaje de cobertura sobre los daños producidos por un siniestro
     * @return double (this.getPorcentajeDanio() *   p_valorAsegurado) / 100
     */
    public double totalDaño(double p_valorAsegurado){
        return (this.getPorcentajeDanio() *   p_valorAsegurado) / 100;
    }
    
    
    
}
