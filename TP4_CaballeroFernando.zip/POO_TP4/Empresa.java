/**
 * descripcion: Clase ejecutable para Empleado 
 */
import java.io.*;
import java.util.*;
public class Empresa{
    public static void main(String args []){
        BufferedReader teclado = new BufferedReader (new InputStreamReader(System.in));
        try{
            //crea objeto de tipo archivo secuencial
            FileOutputStream archiFOS = new FileOutputStream("C:\\Users\\one\\Desktop\\archivos\\Empleados.dat",true);
            DataOutputStream archiDOS = new DataOutputStream(archiFOS);
            char opc = 's';//bandera para saber cuando el usuario desea terminar de grabar
            
            while(opc != 'n' && opc != 'N'){
                //pido los datos al usuario hasta que el desee finalizar
                System.out.println("Ingrese Cuil: ");
                long p_cuil = Long.parseLong(teclado.readLine());
                System.out.println("Ingrese apellido: ");
                String p_ape = teclado.readLine();
                System.out.println("Ingrese nombre: ");
                String p_nom = teclado.readLine();
                System.out.println("Ingrese sueldo basico: ");
                double p_sueldoBasico = Double.parseDouble(teclado.readLine());
                System.out.println("Digite año de ingreso: ");
                int p_anio = Integer.parseInt(teclado.readLine());
                System.out.println("Digite mes de ingreso: ");
                int p_mes = Integer.parseInt(teclado.readLine());
                System.out.println("Digite dia de ingreso: ");
                int p_dia = Integer.parseInt(teclado.readLine());
                
                //instancia del objeto fecha
                Calendar p_fecha = new GregorianCalendar(p_anio,p_mes,p_dia);
                //instancia del objeto Empleado
                Empleado empleado1 = new Empleado(p_cuil,p_ape,p_nom,p_sueldoBasico,p_fecha);
                //mostrar datos que se grabaran
                empleado1.mostrar();
                //graba los campos al registro
                archiDOS.writeLong(empleado1.getCuil());
                archiDOS.writeUTF(empleado1.getApe());
                archiDOS.writeUTF(empleado1.getNom());
                archiDOS.writeDouble(empleado1.getSueldoBasico());
                archiDOS.writeInt(empleado1.getFechaIngreso().get(Calendar.YEAR));
                archiDOS.writeInt(empleado1.getFechaIngreso().get(Calendar.MONTH));
                archiDOS.writeInt(empleado1.getFechaIngreso().get(Calendar.DATE));
                
                System.out.println("¿Quiere seguir ingresando datos de empleados al archivo? (s/n)");
                opc = teclado.readLine().charAt(0);
            }
            
            //cerrar archivo
            archiDOS.close();
        }
        
        catch(FileNotFoundException fnfe){
                System.out.println("Archivo no encontrado");
        }
        catch (IOException ioe){
                System.out.println("Error al Grabar");
        }
    }
}