
/**
 * Descripcion: permite crear objetos de la clase Poliza
 * 
 * @author Caballero, Fernando
 * @version 1
 */
import java.text.*;
import java.util.*;
public class Poliza{
    private String cobertura;
    private Calendar fechaContrato;
    private double valorPoliza;
    private double valorAsegurado;
    private String momentoCancelacion;
    private Siniestro siniestro;
    private UnidadDeRiesgo unidad;
    
    /**
     * descripcion: Constructor para la clase Poliza
     * @param p_cobertura,p_fechaContr,p_valorPoliza,p_valorAsegu,p_momentoCance,p_siniestro,p_unidad
     */
    public Poliza(String p_cobertura,Calendar p_fechaContr,double p_valorPoliza,double p_valorAsegu,String p_momento,Siniestro 
        p_siniestro,UnidadDeRiesgo p_unidad ){
        this.setCobertura(p_cobertura);
        this.setFechaContrato(p_fechaContr);
        this.setValorPoliza(p_valorPoliza);
        this.setValorAsegurado(p_valorAsegu);
        this.setMomentoCancelacion(p_momento);
        this.setSiniestro(p_siniestro);
        this.setUnidad(p_unidad);
    }
    
    /**
     * setters
     */
    private void setCobertura(String p_cobertura){
        this.cobertura = p_cobertura;
    }
    
    private void setFechaContrato(Calendar p_fechaContr){
        this.fechaContrato = p_fechaContr;
    }
    
    private void setValorPoliza(double p_valorPoliza){
        this.valorPoliza = p_valorPoliza;
    }
    
    private void setValorAsegurado(double p_valorAsegu){
        this.valorAsegurado=p_valorAsegu;
    }
    
    private void setMomentoCancelacion(String p_momento){
        this.momentoCancelacion=p_momento;
    }
    
    private void setSiniestro(Siniestro p_siniestro){
        this.siniestro=p_siniestro;
    }
    
    private void setUnidad(UnidadDeRiesgo p_unidad){
        this.unidad=p_unidad;
    }
    
    /**
     * getters
     */
    public String getCobertura(){
        return this.cobertura;
    }
    
    public Calendar getFechaContrato(){
        return this.fechaContrato;
    }
    
    public double getValorPoliza(){
        return this.valorPoliza;
    }
    
    public double getValorAsegurado(){
        return this.valorAsegurado;
    }
    
    public String getMomentoCancelacion(){
        return this.momentoCancelacion;
    }
    
    public Siniestro getSiniestro(){
        return this.siniestro;
    }
    
    public UnidadDeRiesgo getUnidad(){
        return this.unidad;
    }
    /**
     * descripcion: calcula el monto de la indemnizacion segun la cobretura contratada
     * @return retorna el porcentaje de indemnizacion que corresponda
     */
    public double indemnizacion(){
       if(this.getCobertura() == "granizo"){
         return ((this.getSiniestro().totalDaño(this.getValorAsegurado()) * 100)/100);
        }else if(this.getCobertura().equals("incendio")){
            return ((this.getSiniestro().totalDaño(this.getValorAsegurado()) * 75)/100);
        }else return ((this.getSiniestro().totalDaño(this.getValorAsegurado()) * 30)/100);
        
    }
    
    
    /**
     * El metodo indica la fecha de indemnizacion de la cocecha
     * @return la fecha correspondiente
     */
    public Calendar fechaIndemnizacion(){
       Calendar fechaCos   = new GregorianCalendar(this.getUnidad().getFechaCultivo().get(Calendar.YEAR),
                                                   this.getUnidad().getFechaCultivo().get(Calendar.MONTH),
                                                   this.getUnidad().getFechaCultivo().get(Calendar.DATE)); 
       
       Calendar fechaSin   = new GregorianCalendar(this.getSiniestro().getFecha().get(Calendar.YEAR),
                                                   this.getSiniestro().getFecha().get(Calendar.MONTH),
                                                   this.getSiniestro().getFecha().get(Calendar.DATE));
        
       if(this.getCobertura().equals("granizo") || this.getCobertura().equals("resiembra")){
           return fechaCos;
       }else{
           if(this.getCobertura().equals("incendio")){
               fechaSin.add(Calendar.DATE, 20);
            }
        }
       return fechaCos;
    }
    
    /**
     * descripcion: muestra el precio de la poliza dependiendo del momento de la cancelacion
     * @return precio
     */
    public void detallePrecioPoliza(){
        double precio = 0;
        if(this.getMomentoCancelacion()=="inicial"){
          precio = this.getValorPoliza() - (this.getValorPoliza() * 0.25); 
          System.out.println("El abono se realiza al comienzo de la siembra. Tiene un descuento del 25%. \n"
          +" Precio Real Abonado: "+precio);
        }else
          precio = this.getValorPoliza(); 
          System.out.println("El abono se realiza al finalizar la siembra. Se abona el 100% de la póliza."+precio);
        
    }
       
    /**
     * descripcion: permite visualizar un resuen de Indemnizacion
     * 
     * 
     */
    public void resumenIndemnizaciones(){
        Calendar fechaC = new GregorianCalendar(this.getFechaContrato().get(Calendar.YEAR),
                                                this.getFechaContrato().get(Calendar.MONTH),
                                                this.getFechaContrato().get(Calendar.DATE)); 
        Date fechaContrato = fechaC.getTime();
        SimpleDateFormat formato = new SimpleDateFormat("yyyy/M/d");
        
        
        
        System.out.println("****RESUMEN DEL SEGURO CONTRATADO EL DIA "+formato.format(fechaContrato)+" ****");
        System.out.println("---------------------Detalle de la unidad de riesgo---------------------");
        System.out.println("Precio a pagar: "+this.getValorPoliza());
        this.detallePrecioPoliza();
        System.out.println("El valor cultivo asegurado: "+this.getValorAsegurado());
        System.out.println("---------------------Detalle de la unidad de riesgo---------------------");
        this.getUnidad().mostrarDetalle();
        System.out.println("*********************************************************");
    }    
}
