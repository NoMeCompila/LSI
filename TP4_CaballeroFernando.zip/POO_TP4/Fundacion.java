/**
 * Descripcion: permite crear objetos de la clase Fundacion e imprimir invitaciones a los invitados
 * @author  Caballero, Fernando
 * @version 1.0
 */
import java.util.*;
import java.io.*;
public class Fundacion{
    //atributos
    private String nombre;
    
    //constructor
    /**
     * descripcion: permite instanciar objetos de la clase Fundacion
     * @param String p_nombre
     */
    
    public Fundacion(String p_nombre){
        this.setNombre(p_nombre);
    }
    
    //getter y setter
    /**
     * Descripcion: getter para el atributo nombre
     * @return nombre
     */
    
    public String getNombre(){
        return this.nombre;
    }
    /**
     * Descripcion:  setter para el atributo nombre
     * @param String p_nombre
     */
    private void setNombre (String p_nombre){
        this.nombre = p_nombre;
    }
    
    //metodos 
    
    /**
     * Descripcion: permite imprimir una invitacion 
     * @param  Evento p_evento, Persona p_persona 
     */
    
    public void imprimirInvitacion(Evento p_evento, Persona p_persona){
        System.out.println("Estimado/a: "+p_persona.nomYApe());
        System.out.println("La fundación "+this.getNombre());
        System.out.println("Invita a Ud. al próximo evento: "+p_evento.getNombre());
        System.out.println("Las inscipciones se realizarán con "+p_evento.getDiasInscripcion()+" días de antiicipación");
        System.out.println("Las mismas se llevaran a cabo el día: "+p_evento.fechaInscripcion());
        System.out.println("El evento tendrá lugar en: "+p_evento.getLugar()+ ", el día "+p_evento.getFecha());
        System.out.println("Costo: "+p_evento.costoFinal(p_persona.edad()));
    }
    /**
     * descripcion: graba la invitacion en un archivo
     * @param Evento p_evento, Persona p_persona, DataOutputStream unArchivo
     */
    public void grabarInvitacion(Evento p_evento, Persona p_persona, DataOutputStream unArchivo){
        try{
            unArchivo.writeInt(p_persona.getNroDni());
            unArchivo.writeChars(p_persona.apeYNom());
            unArchivo.writeChars(p_evento.getNombre());
            unArchivo.writeChars(p_evento.getLugar());
            unArchivo.writeDouble(p_evento.getCosto());
            unArchivo.writeInt(p_evento.getFecha().YEAR);
            unArchivo.writeInt(p_evento.getFecha().MONTH);
            unArchivo.writeInt(p_evento.getFecha().DATE);
        }
        catch (IOException ioe){
            System.out.println("Error al escribir en el archivo");
        }
    }
    
    
}
