/**
 * descripcion: crea objetos de la clase Evento y muestra cuantos dias antes del evento se realiza la inscripcion a demas de saber si el
 * invitado es veneficiario de un descento
 * 
 * @author Caballero, Fernando
 * @version 1.0
 */
import java.util.*;
public class Evento{
   //atributos
   private String nombre;
   private String lugar;
   private Calendar fecha;
   private int diasInscripcion;
   private double costo;
    
    //costructores
   /**
    * Descripcion: constructor de la clase Evento
    * @param String p_nombre, String p_lugar,Calendar p_fecha,int p_diasInscripcion,double p_costo
    */
   public Evento(String p_nombre, String p_lugar,Calendar p_fecha,int p_diasInscripcion,double p_costo){
        this.setNombre(p_nombre);
        this.setLugar(p_lugar);
        this.setFecha(p_fecha);
        this.setDiasInscripcion(p_diasInscripcion);
        this.setCosto(p_costo);
   }
   
   //geters y setters
   /**
    * descripcion: getter para el atributo nombre
    * return nombre
    */
   public String getNombre(){
       return this.nombre;
   }
   /**
    * Descripcion setter para el atributo nombre
    * @param String p_nombre
    */
   private void setNombre(String p_nombre){
       this.nombre = p_nombre;
   }
   /**
    * descripcion: getter para el atributo lugar
    * return lugar
    */
   public String getLugar(){
       return this.lugar;
   }
    /**
    * Descripcion setter para el atributo lugar
    * @param String p_lugar
    */
   private void setLugar(String p_lugar){
       this.lugar = p_lugar;
   }
    /**
    * descripcion: getter para el atributo fecha
    * return fecha
    */
   public Calendar getFecha(){
       return this.fecha;
   }
    /**
    * Descripcion setter para el atributo fecha
    * @param Calendar p_fecha
    */
   private void setFecha(Calendar p_fecha){
       this.fecha = p_fecha;
   }
    /**
    * descripcion: getter para el atributo diasInscipcion
    * return diasInscripcion
    */
   public int getDiasInscripcion(){
       return this.diasInscripcion;
   }
    /**
    * Descripcion setter para el atributo diasInscipcion
    * @param int p_diasInscripcion)
    */
   private void setDiasInscripcion(int p_diasInscripcion){
       this.diasInscripcion = p_diasInscripcion;
   }
    /**
    * descripcion: getter para el atributo costo
    * return costo
    */
   public double getCosto(){
       return this.costo;
   }
   /**
    * Descripcion setter para el atributo costo
    * @param double p_costo
    */
   private void setCosto(double p_costo){
       this.costo = p_costo;
   }
   
   //METODOS
   /**
    * Descripcion: avisa en pantalla si el invitado es o no veneficiario de un descuento y muestra el monto
    * @param int p_edadInvitado
    * @return getCosto
    */
   public String costoFinal(int p_edadInvitado){
       if (p_edadInvitado >= 60) {
           return  "incluye descuento de $" + (this.getCosto() * 0.9) ;
       }
       else {
           return "$" + this.getCosto();
       }
   }
   /**
    * descripcion: retorna la fecha correspondiente
    * @return fecha
    */
   public Calendar fechaInscripcion(){
       Calendar feca = new GregorianCalendar(this.getFecha().get(Calendar.YEAR),
                                             this.getFecha().get(Calendar.MONTH),
                                             this.getFecha().get(Calendar.DATE));
       fecha.add(Calendar.DATE, (this.getDiasInscripcion() * -1));
       return fecha;
   }
}
