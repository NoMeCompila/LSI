import java.io.*;
import java.util.*;
public class LaboratorioEjecutable{
    public static void main(String args[]){
        int codigo = 0;
        char opc = 'S';
        BufferedReader teclado = new BufferedReader(new InputStreamReader (System.in));
        try{
            RandomAccessFile laboratorio = new RandomAccessFile ("C:\\Users\\one\\Desktop\\archivos\\Laboratorio.dat","rw");
            while(opc != 'n' && opc != 'N'){
                if(laboratorio.length() != 0){
                    codigo = (int)laboratorio.length() / 192;
                    laboratorio.seek(laboratorio.length()) ;               
                }
                System.out.println("El codigo del laboratorio es: " + codigo);
                System.out.println("Ingrese el nombre de laboratorio: ");
                String nombre = teclado.readLine();
                if (nombre.length() < 30){
                    for (int i = nombre.length(); i < 30; i++){
                        nombre = nombre + " ";
                    }
                }else{
                     nombre = nombre.substring(0, 30);
                }
                System.out.println("Ingrese el domicilio del laboratorio: ");
                String domicilio = teclado.readLine();
                if (domicilio.length() < 30){
                    for (int i = domicilio.length(); i < 30; i++){
                        domicilio = domicilio + " ";
                    }
                }
                else{
                    domicilio = domicilio.substring(0, 30);  
                }
                System.out.println("Ingrese el numero de telefono: ");
                String telefono = teclado.readLine();
                if (telefono.length() < 30){
                    for (int i= telefono.length(); i<30; i++){
                        telefono = telefono +" ";
                    }
                }
                else{
                    telefono = telefono.substring(0, 30);
                }
                Laboratorio laboratorio1 = new Laboratorio(nombre, domicilio, telefono);
                
                
                System.out.print("\nIngrese la compra minima: ");
                laboratorio1.ajusteCompraMinima(Integer.parseInt(teclado.readLine()));
                
                
                System.out.print("\nIngrese el dia de entrega: ");
                laboratorio1.ajusteDiaEntrega(Integer.parseInt(teclado.readLine()));
                
                laboratorio.writeInt(codigo);
                laboratorio.writeChars(laboratorio1.getNom());
                laboratorio.writeChars(laboratorio1.getDom());
                laboratorio.writeChars(laboratorio1.getTel());
                laboratorio.writeInt(laboratorio1.getCompraMin());
                laboratorio.writeInt(laboratorio1.getDiaEntrega());
                
                System.out.print("\nDesea seguir ingresando laboratorios? s/n?: ");
                opc = teclado.readLine().charAt(0);
            }
            laboratorio.close();
        }
        catch(FileNotFoundException fnfe){
            System.out.println("Archivo no encontrado");
        }
        catch (IOException ioe){
            System.out.println("Error al Grabar");
        }
    }
}
