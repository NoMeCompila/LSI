import java.util.*;
public class ArrayDePuntos{
    public static void main(String args []){
        Scanner teclado = new Scanner(System.in);
        Punto [] puntos = new Punto [6];
        
        for(int i=0;i<puntos.length;i++){
            System.out.println("Ingrese coordenada X: ");
            double x = teclado.nextDouble();
            System.out.println("Ingrese coordenada Y: ");
            double y = teclado.nextDouble();
            puntos [i] = new Punto(x,y);
        }
        
        for(int i=0;i<puntos.length;i++){
            puntos[i].mostrar();
        }
        
        for(int i=0;i<puntos.length-1;i++){
            System.out.println(puntos[i].distanciaA(puntos[i+1]));
        }
    }
}
