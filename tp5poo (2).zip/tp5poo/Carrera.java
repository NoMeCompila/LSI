import java.util.*;
/**
 * descripcion: clase que permite instanciar objetos de la clase Curso
 * 
 * @author Caballero, Fernando
 * @version 1.0
 */
public class Carrera{
    public static void main (String [] args){
   
    //instancia de la clase alumno          
    Alumno alum1 = new Alumno(123,"Fernando","Caballero",10,10);
    Alumno alum2 = new Alumno(456,"Fernanda","Rodriguez",10,10);
    Alumno alum3 = new Alumno(789,"Nicolas","Acevedo",10,10);   

    //creamos coleccion de tipo HashMap
    
    HashMap<Integer,Alumno> curso = new HashMap<Integer,Alumno>();
    
    //agregamos a la coleccion los siguientes alumnos
    
    curso.put(alum1.getLu(),alum1);
    curso.put(alum2.getLu(),alum2);
    
    
    //creamos un objeto de tipo Curso
    
    Curso curso1 = new Curso("Curso nro 1",curso);
    
    //inscribir alumno
    
    curso1.inscribirAlumno(alum3);
    
    //mostrar datos del curso
    
    System.out.println("Cantidad de Inscriptos: "+curso1.cantidadDeAlumnos()+"\n");
    
    curso1.mostrarInscriptos();
    

    
            
}
}