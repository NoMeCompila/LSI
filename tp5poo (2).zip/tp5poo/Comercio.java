import java.util.*;
/**
 * descripcion: permite crear objetos de la clase Comercio
 * 
 * @author Caballero, Fernando 
 * @version 1.0
 */
public class Comercio{
    
    private String nombre;
    private HashMap<Long,Empleado> empleados;
  
    /**
     * Constructor de objetos de la clase Comercio - no conoce a ningun Empleado
     * @param String p_nombre
     */
    public Comercio(String p_nombre){
        
        this.setNombre(p_nombre);
       
    }

    /**
     * Constructor de objetos de la clase Comercio - conoce a uno o mas Empleados
     * @param String p_nombre
     * @param HashMap<Long,Empleado> p_empleados
     */
      public Comercio(String p_nombre, HashMap<Long,Empleado> p_empleados){
        
        this.setNombre(p_nombre);
        this.setEmpleados(p_empleados);
    }
    
   
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    private void setEmpleados(HashMap<Long,Empleado> p_empleados){
        this.empleados=p_empleados;
    }
    
    /**metodo que devuelve un String nombre
     * @return String nombre
     */
    
    public String getNombre(){
        return this.nombre;
    }
    
    /**metodo que devuelve una coleccion de tipo HashMap de Empleados
     * @return HashMap<Long,Empleado> empleados
     */
    
    public HashMap<Long,Empleado> getEmpleados(){
        return this.empleados;
    }
    
    /**metodo que permite dar de alta a un Empleado (agregar a coleccion HashMap)
     * @param Empleado p_empleado
     */
    
    public void altaEmpleado(Empleado p_empleado){
        this.getEmpleados().put(p_empleado.getCuil(),p_empleado);
    }
    
    /**metodo que permite dar de baja a un Empleado (quitar de la coleccion HashMap)
     * @param long p_cuil
     */
    
    public Empleado bajaEmpleado(long p_cuil){
        return this.getEmpleados().remove(p_cuil);
    }
    
    /**metodo que devuelve la cantidad de empleados (int)
     * @return int empleados
     */
    
    public int cantidadDeEmpleados(){
        return this.getEmpleados().size();
    }
    
    /**metodo que permite saber si existe un empleado o no
     * @return boolen
     * @param long p_cuil
     */
    
    public boolean esEmpleado(long p_cuil){
        return this.getEmpleados().containsKey(p_cuil);
    }
    
    /**metodo que devuelve el Empleado solicitado/buscado
     * @return Empleado
     * @param long p_cuil
     */
    
    public Empleado buscarEmpleado(long p_cuil){
        return this.getEmpleados().get(p_cuil);
    }
    
    /**metodo que imprime el sueldoNeto del empleado solicitado por medio del cuil
     * @param long p_cuil
     */
    
    public void sueldoNeto(long p_cuil){
       System.out.print( this.getEmpleados().get(p_cuil).saldoNeto());
    }
    
    /**metodo que imprime la nomina de empleados para presentar al AFIP
     * 
     */
    
     public void nomina(){
        
          System.out.println("**** Nomina de empleados de "+this.getNombre()+ "****\n");
         
       for(Map.Entry<Long,Empleado> emp:empleados.entrySet()){
           
           System.out.print(emp.getValue().getCuil()+"\t"+emp.getValue().apeYnom()+"------------");
           this.sueldoNeto(emp.getValue().getCuil());
           System.out.println("\n");
        }
    }
}