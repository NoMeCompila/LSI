import java.util.*;
public class TomaPedido{
    public static void main(){
        //instancia clase Laboratorio
        Laboratorio lab = new Laboratorio("Colgate S.A.", "Yrigoyen 2082", "379-4914905");
        
        //instancia de objetos de la clase Producto
        Producto p1 = new Producto(1234, "Perfumeria", "Jabon lux", 226.25, lab);
        Producto p2 = new Producto(1234, "Higiene", "Dentifrico", 400.25, lab);
        Producto p3 = new Producto(1234, "Limpieza", "Ayudin", 500.25, lab);
        
        //instancia de un cliente
        Cliente c1 = new Cliente (40982473, "Caballero", "Fernando", 123);
        
        //instancia de una fecha
        Calendar fecha = new GregorianCalendar();
        
        //instancia del contenedor
        ArrayList productos = new ArrayList();
        
        //instancia de los pedidos
        Pedido pedido1 = new Pedido(fecha, c1, p1);
        Pedido pedido2 = new Pedido(fecha, c1, p2);
        Pedido pedido3 = new Pedido(fecha, c1, productos);
        
        
        
        pedido3.agregarProducto(p1);
        pedido3.mostrarPedido();
        pedido3.agregarProducto(p2);
        pedido3.mostrarPedido();
        
        
    }
}
