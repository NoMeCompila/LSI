/**
 * descripcion: crea objetos de la clase pedido 
 * @author Caballero, Fernando
 * @version 1
 */
import java.util.*;
public class Pedido{
    private Calendar fecha;
    private Producto producto;
    private ArrayList productos;
    private Cliente cliente;
    
    /**
     * descripcion: constructor para la clase Pedido
     * @param Calendar p_fecha, Cliente p_cliente, ArrayList p_productos
     */
    public Pedido(Calendar p_fecha, Cliente p_cliente, ArrayList p_productos){
        this.setFecha(p_fecha);
        this.setCliente(p_cliente);
        this.setProductos(p_productos);
        
    }
    
    /**
     * descripcion: constructor para la clase Pedido
     * @param Calendar p_fecha, Cliente p_cliente, Producto p_productos
     */
    public Pedido(Calendar p_fecha, Cliente p_cliente, Producto p_producto){
        this.setFecha(p_fecha);
        this.setCliente(p_cliente);
        this.setProducto(p_producto);
        
    }
    /**
     * setter para el atributo fecha
     * @param p_fecha
     */
    private void setFecha(Calendar p_fecha){
        this.fecha=p_fecha;
    }
    
    /**
     * setter para el atributo producto
     * @param p_producto
     */
    private void setProducto(Producto p_producto){
        this.producto=p_producto;
    }
    
    /**
     * setter para el atributo productos
     * @param p_productos
     */
    private void setProductos(ArrayList p_productos){
        this.productos=p_productos;
    }
    
    /**
     * setter para el attributo ciente
     * @param p_cliente
     */
    private void setCliente(Cliente p_cliente){
        this.cliente=p_cliente;
    }  
    
    /**
     * getter para el atributo fecha
     * @return fecha
     */
    public Calendar getFecha(){
        return this.fecha;
    }
    /**
     * getter para el atributo producto
     * @return producto
     */
    public Producto getProducto(){
        return this.producto;
    }
    
    /**
     * getter paraa el etributo productos
     * @return productos
     */
    public ArrayList getProductos(){
        return this.productos;
    }
    
    /**
     * getter para el atributo cliente
     * @return cliente
     */
    public Cliente getCliente(){
        return this.cliente;
    }
    
    /**
     * Descripcion: metodo para agregar un producto al contenedor
     * @param Producto p_productos
     * @return this.getProductos().add(p_productos);
     */
    public boolean agregarProducto(Producto p_producto){
        return this.getProductos().add(p_producto);
    }
    
    /**
     * Descripcion: metodo para quitar un producto de el contenedor
     * @param Producto p_productos
     * @return this.getProductos().remove(p_productos);
     */
    public boolean quitarProducto(Producto p_producto){
        return this.getProductos().remove(p_producto);
    }
    
   /**
    * descripcion: suma el precio al contado de cada uno de los productos y retorna el resultado
    * @return totalContado
    */
   public double totalAlContado(){
       double totalContado = 0;
       for(int i=0; i<this.getProductos().size(); i++){
           totalContado += (((Producto) this.getProductos().get(i)).precioContado());
       }
       return totalContado;
   }
   
   /**
    * descripcion: suma cada uno de los precios financiado de los productos y retorna el resultado
    * @return totalFin
    */
   public double totalFinanciado(){
       double totalFin = 0;
       for(int i=0; i<this.getProductos().size(); i++){
           totalFin += (((Producto) this.getProductos().get(i)).precioLista());
       }
       return totalFin;
   }
   
   /**
    * descripcion: muestra en pantalla el detalle del pedido junto con los datos de los productos
    */
   public void mostrarPedido(){
        System.out.println("\n\t\t***** Detalle del pedido ****** Fecha:" 
                            + this.getFecha().get(Calendar.DATE) + "/"
                            + (this.getFecha().get(Calendar.MONTH)+1) + "/"
                            + this.getFecha().get(Calendar.YEAR));
       System.out.println("Producto\t\tPrecio Lista\t\tPrecio Contado\n\n");
       System.out.println("---------------------------------------------------------------------------------------------\n");
       for (int i =0; i < this.getProductos().size(); i++){
           System.out.println("\n"+((Producto) this.getProductos().get(i)).getRubro() +"\t\t"+
           ((Producto) this.getProductos().get(i)).precioLista()+"\t\t\t"+((Producto) 
           this.getProductos().get(i)).precioContado());
       }
       System.out.println("---------------------------------------------------------------------------------------------\n");
       System.out.println("\nTotal:\t\t\t"+this.totalFinanciado()+"\t\t\t"+this.totalAlContado());
    }
}
