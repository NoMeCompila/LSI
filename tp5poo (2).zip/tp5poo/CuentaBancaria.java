
/**
 * Descripcion: esta clase eprmite manejar una cuenta bancaria de un titular ya sea depositando o extrayendo dinero a demas de mostrar 
 * los datos 
 * @author (Caballero, Fernando) 
 * @version (1) fehca(30/08/2019)
 */

public class CuentaBancaria{
   //atributos
   private  int nroCuenta;
   private  double saldo;
   private  Persona titular;
   
   //setters
  /**
  * Descripcion: setter para el atributo nroCuenta (numero de cuenta)
  * @param recibe un parametro del tipo int nroCuenta
  */
 private void setNroCuenta(int p_nroCuenta){
      this.nroCuenta = p_nroCuenta;
  }
 
 
  /**
  * Descripcion: setter para el atributo saldo
  * @param recibe un parametro del tipo double p_saldo
  */
   
 private void setSaldo(double p_saldo){
      this.saldo = p_saldo;
  } 
   
  /**
  * Descripcion: setter para el atributo
  * @param recibe un parametro del tipo
  */
 private void setTitular(Persona p_titular){
      this.titular = p_titular;
  } 
  
  //setters
  /**
  * Descripcion: getter para el atributo
  * @return retorna un entero nroCuenta
  */
 public int getNroCuenta(){
    return this.nroCuenta;  
  }
  
  
  /**
  * Descripcion: getter para el atributo
  * @return retorna un 
  */
 public double getSaldo(){
      return this.saldo;
  }
  
  
  /**
  * Descripcion: getter para el atributo
  * @return retorna un 
  */
 public Persona getTitular(){
      return this.titular;
  }
  
  
  //costructores
  
  /**
   * Costructor sobrecargado para la clase CuentaBancaria
   * @param int p_nroCuenta, Persona p_titular
   */
 public CuentaBancaria(int p_nroCuenta, Persona p_titular){
      this.setNroCuenta(p_nroCuenta);
      this.setSaldo(0);
      this.setTitular(p_titular);
  }
  
  /**
  * Costructor sobrecargado para la clase CuentaBancaria
  * @param
  */
  
  
 public CuentaBancaria(int p_nroCuenta, double p_saldo, Persona p_titular){
      this.setNroCuenta(p_nroCuenta);
      this.setSaldo(p_saldo);
      this.setTitular(p_titular);
    }
 
 //metodos
  
  /**
  * Descripcion: este metodo permite depositar dinero de una caja de ahorro
  * @param recibe un double p_importe
  */
  public void depositar(double p_importe){
       this.setSaldo(this.getSaldo() + p_importe);
  }
 /*public double depositar(double p_importe){
      return this.setSaldo(this.getSaldo() + p_importe);
  }*/
  /**
  * Descripcion: este metodo permite extraer dinero de una caja de ahorro
  * @param recibe un double p_importe
  */
 
   public void extraer(double p_importe){
       this.setSaldo(this.getSaldo() - p_importe);
  }
  
  /**
   * Descripcion: este metodo permite mostrar en pantalla los datos de un titular y su cuenta bancaria
   */
  public void mostrar(){
    System.out.println("\t\t\t-Cuenta Bancaria-");
    System.out.println("Titular: "+this.titular.nomYApe()+" ("+this.titular.edad()+" años).");
    System.out.println("Saldo: U$D "+this.getSaldo());
  }
  /**
   * Descripcion: Muetra en una linea en pantalla los datos deun titular
   */
  public String toString(){
      return +this.getNroCuenta()+"\t"+this.getTitular().nomYApe()+"\t"+this.getSaldo();
  }
  
}
