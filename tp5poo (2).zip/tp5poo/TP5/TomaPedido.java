import java.util.*;
/**
 * Clase que permite crear productos a solicitar
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class TomaPedido
{
   
   public static void main (String [] args){
       
       //creamos cliente
       
       Cliente cli = new Cliente(33063932,"Marcelo","Rajoy",3500);
      
       //creamos laboratorio
       
       Laboratorio lab = new Laboratorio("Colgate S.A.","Belgrano 1445","0379154271930");
       
       //creamos los productos
       
       Producto pro = new Producto(33,"Perfumes","AXE Desodorantes",15,lab); //se envia solo
       
       //se envian como ArrayList
       
       Producto pro1 = new Producto(33,"Perfumes","Rexona Desodorantes",20,lab);
       Producto pro2 = new Producto(33,"Perfumes","Kenzo Perfumes",25,lab);
       Producto pro3 = new Producto(33,"Perfumes","Calvin Klein Perfumes",35,lab);
       
       //creamos arraylist
       
       ArrayList enviar = new ArrayList();
       
       enviar.add(pro1);
       enviar.add(pro2);
       enviar.add(pro3);
       
       //creamos Pedido con un producto
       
       Pedido ped = new Pedido((new Fecha()),cli,pro);

       //agregamos un arraylist a la lista ya creada
       
       ped.agregarArrayDeProductos(enviar);
      
       //mostramos total contado y financiado
       
       System.out.println("Total al Contado=>"+ped.totalAlContado());
       System.out.println("Total Financiado=>"+ped.totalFinanciado());       
       
       //removemos un producto (Kenzo Perfumes)
       
       ped.quitarProducto(pro2);
       
       //mostramos total contado y financiado despues del cambio
       
       System.out.println("\nTotal al Contado=>"+ped.totalAlContado());
       System.out.println("Total Financiado=>"+ped.totalFinanciado()+"\n");       
       
       //imprimimos el detalle de todos los productos
       
       ped.mostrarPedido();
    }
}