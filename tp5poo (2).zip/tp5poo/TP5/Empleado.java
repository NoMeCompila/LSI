import java.util.*;

/**
 * Una clase para representar a Empleado
 * para crear los objetos recibe como parametro Cuil, Apellido, Nombre, Sueldo Basico y Año de Ingreso.
 * devuelve el Sueldo Neto del empleado dependiendo de la antiguedad y de los datos ingresados
 * @author (Marcelo F. Rajoy) 
 * @version (1.1)
 */

/*Clase modificada, en esta nueva version, permite calcular el aniversario por fecha completa, mantiene los constructores y metodos utilizados por otras
 * clases que solo requiere del año para calcular la antiguedad.
 * la nueva funcion/metodo de calcular el aniversario es utilizado por la clase IberaServicios para descontar una hora de trabajo por año de antiguedad cumplido
 */

public class Empleado {

    // Variables de Instancias
    
    private long cuil;
    private String apellido;
    private String nombre;
    private double sueldoBasico;
    private Calendar fechaIngreso;
    
    /**
     * Constructor para objetos de la clase Empleado (Sobrecargado)
     * @param p_cuil de tipo long
     * @param p_apellido de tipo String
     * @param p_nombre de tipo String
     * @param p_importe de tipo double
     * @param p_anio de tipo entero
     */
    public Empleado(long p_cuil, String p_apellido, String p_nombre, double p_importe, int p_anio){
        
        // inicializamos las V.I.
        
        this.setCuil(p_cuil);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSueldoBasico(p_importe);
        this.setAnioIngreso(p_anio);
        
    }
    
     /**
     * Constructor para objetos de la clase Empleado (Sobrecargado)
     * @param p_cuil de tipo long
     * @param p_apellido de tipo String
     * @param p_nombre de tipo String
     * @param p_importe de tipo double
     * @param Calendar p_fecha
     */
    public Empleado(long p_cuil, String p_apellido, String p_nombre, double p_importe, Calendar p_fecha){
        
        // inicializamos las V.I.
        
        this.setCuil(p_cuil);
        this.setApellido(p_apellido);
        this.setNombre(p_nombre);
        this.setSueldoBasico(p_importe);
        this.setFechaIngreso(p_fecha);
        
    }

/*se establecen los metodos seters, en todos los casos la operacion es la misma, cada seter asigna el valor recibido como parametro a una V.I.*/    
    
   private void setCuil(long p_cuil){
       this.cuil = p_cuil;
    }
   private void setApellido(String p_apellido){
       this.apellido = p_apellido;
    }
   private void setNombre(String p_nombre){
       this.nombre = p_nombre;
    }
   private void setSueldoBasico( double p_importe){
       this.sueldoBasico = p_importe;
    }
   private  void setAnioIngreso(int p_anio){
       Calendar cal = Calendar.getInstance();
       cal.set(p_anio,0,1);
       this.setFechaIngreso(cal);
    }
    
   private void setFechaIngreso(Calendar p_fecha){ //metodo Nuevo
       this.fechaIngreso = p_fecha;
    }
    
   public Calendar getFechaIngreso(){ //metodo Nuevo
       return this.fechaIngreso;
    }
    
    
/**El metodo getCuil() retorna el valor de la V.I. cuil que es de tipo long
 * @return retorna un valor de tipo long (cuil)
 */
    
    public long getCuil(){
       return this.cuil;
    }
   
   public String getApellido(){
       return this.apellido;
    }
   public String getNombre(){
       return this.nombre;
    }
   public double getSueldoBasico(){
       return this.sueldoBasico;
    }
   public int getAnioIngreso(){
       return this.getFechaIngreso().get(Calendar.YEAR);
    }

/*este metodo antiguedad() que retorna un entero,utiliza la clase Calendar para obtener el año actual
 * y asi hacer el calculo en conjunto con el metodo getAnioIngreso para establecer la antiguedad del Empleado
 */    
    
    public int antiguedad (){

        Calendar fechahoy = new GregorianCalendar();
        int anioHoy = fechahoy.get(Calendar.YEAR);
        return anioHoy - this.getAnioIngreso();
    }
    
/* este metodo descuento() de tipo privado retorna un double, permite calcular el descuento aplicado al Empleado e interactua con el metodo
 * getSueldoBasico() para obtener el resultado
 */    
    
    private double descuento(){
        return ((this.getSueldoBasico()) / 100 * 2)+12;
    }
    
/* este metodo sueldoNeto() de tipo privado que retorna un double permite calcualr el sueldo neto que se basa en el sueldo basico mas el adicional menos el descuento
 * este metodo interactua con otros dos metodos, getSueldoBasico(), adicional() y descuento() para retornar el resultado deseado
 */    
    
    public double sueldoNeto(){
        return  (this.getSueldoBasico() + adicional()-descuento()) ;
    }
    
/* el metodo adicional() de tipo privado que rotorna un double permite calcular el valor agregado segun la antiguedad del Empleado
 * este metodo interactua con el metodo getSueldoBasico() para obtener la base por la cual calcular el resultado final
 */    
    
    private double adicional(){
        double adi = 0;
        if (antiguedad() < 2) {adi = ((this.getSueldoBasico() + ((this.getSueldoBasico()/100) * 2))- this.getSueldoBasico());}
        if (antiguedad() >= 2 && antiguedad() < 10){adi = ((this.getSueldoBasico() + ((this.getSueldoBasico()/100) * 4))- this.getSueldoBasico());}
        if (antiguedad() >= 10){adi = ((this.getSueldoBasico() + ((this.getSueldoBasico()/100) * 6))- this.getSueldoBasico());}
        return adi;
    }
    
    /** El metodo nomYApe() de tipo publico con devolucion de valores concatena los valores devueltos por los metodos getNombre y getApellido
  * @return devuelve un string conteniendo el nombre y el apellido de la persona separado por un espacio
 */

    public String nomYApe () {

        return this.getNombre()+ " " + this.getApellido();

    }

/** El metodo apyYNom() de tipo publico con devolucion de valores concatena los valores devueltos por los metodos getApellido y getNombre
  * @return devuelve un string conteniendo el apellido y el nombre de la persona separado por un espacio
 */

    
    public String apeYNom () {

        return this.getApellido()+ " " +  this.getNombre();

    }
  
/** el metodo mostrar() de tipo publico sin devolucion de valores (void - no requiere de return) imprime por pantalla/consola 
 * los siguientes datos: Nombre, Apellido, Cuil, Antiguedad en años y SueldoNeto.
 */
         
    
    public void mostrar (){
        System.out.println("--------------------Empleado-----------------------"+"\n");
        System.out.println("Nombre y Apellido: " + this.nomYApe() );
        System.out.println("CUIL: "+this.getCuil()+"\t"+"Antiguedad: " + this.antiguedad() +" años de servicio");
        System.out.println("Sueldo Neto: "+ this.sueldoNeto()+"\n");
   
        System.out.println(mostrarLinea());
        
    }
    
/** este metodo es llamado para interactuar con el metodo mostrar()
 * @return retorna un String para, atraves de mostrar(), imprimir una linea detallada del Empleado
 */    
    
    public String mostrarLinea(){
        String mos = (String.valueOf(this.getCuil())+"\t"+ String.valueOf(this.apeYNom())+"\t" + ".............."+String.valueOf(this.sueldoNeto()));
        return mos;
     
        
    }
    public boolean esAniversario(){
        Calendar hoy = Calendar.getInstance();
        if (hoy.get(Calendar.MONTH) == this.getFechaIngreso().get(Calendar.MONTH) && hoy.get(Calendar.DATE) == this.getFechaIngreso().get(Calendar.DATE)){
            return true;} else{return false;}
        }
}
