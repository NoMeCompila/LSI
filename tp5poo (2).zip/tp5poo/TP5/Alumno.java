import java.util.*;

/** una clase que represetna a Alumno
 * recibe como parametros LU, Nombre, Apellido, Nota1 y Nota2
 * devuelve un listado con el promedio del alumno y su estado para promocionar (Aprobado, Desaprobado)
 * @author (Marcelo F. Rajoy)
 * @version (1.0)
 */

public class Alumno{

    // variables de instancias

    private int lu;
    private String nombre;
    private String apellido;
    private double nota1 = 0;
    private double nota2 = 0;
    
    /**
     * Constructor para objetos de la Clase
     */
    
    public Alumno(int p_lu, String p_nombre, String p_apellido){
      
        // Inicializamos las variables de instancias
      
        this.setLu(p_lu);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
     
    }

/*definimos los metodos seters, en todos los casos las funciones son las mismas, asignar valores a las variables de instancia
 * que reciben como parametros
 */
    
    
    private void setLu(int p_lu){
        this.lu = p_lu;
    }
    
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    private void setApellido(String p_apellido){
        this.apellido = p_apellido;
    }
    
/** el metodo setNota1() asigna a la V.I. nota1 el valor recibido como parametro
 */   
    
    public void setNota1 (double p_nota){
        this.nota1 = p_nota;
    }
    
 /** el metodo setNota2() asigna a la V.I. nota1 el valor recibido como parametro
 */   
       
    public void setNota2 (double p_nota){
        this.nota2 = p_nota;
    }
/** el metodo getLu() devuelve el valor de la variable de instancia lu
 * @return devuelve el valor de la V.I. lu
 */
    
    public int getLu(){
        return this.lu;
    }
    
/** el metodo getNombre() devuelve el valor de la variable de instancia nombre
 * @return devuelve el valor de la V.I. nombre
 */
    
    public String getNombre(){
        return this.nombre;
    }

/** el metodo getApellido() devuelve el valor de la variable de instancia apellido
 * @return devuelve el valor de la V.I. apellido
 */    
    
    public String getApellido(){
        return this.apellido;
    }
    
/** el metodo promedio() devuelve el promedio de las dos notas ingresadas
 * @return devuelve un double (promedio de notas)
 */
    
    public double promedio(){
        
        return ((this.nota1 + this.nota2) / 2);
    }
  
// el metodo aprueba() (metodo privado con devolucion de resultado) devuelve verdadero o falso segun el resultado que le devuelve el metodo promedio()    
    
    private boolean aprueba(){
        if (promedio() <= 8){return false;}
        else{return true;}
    }
    
// el metodo leyendaAprueba() (metodo privado con devolucion de resultado) devuelve Aprobado o Desaprobado segun el metodo aprueba()        
    
    private String leyendaAprueba(){
        if (aprueba() == true){
            return "APROBADO";}
        else{return  "DESAPROBADO";}
    }
    
 /** El metodo nomYApe() de tipo publico con devolucion de valores concatena los valores devueltos por los metodos getNombre y getApellido
  * @return devuelve un string conteniendo el nombre y el apellido de la persona separado por un espacio
 */

    public String nomYApe () {

        return this.getNombre()+ " " + this.getApellido();

    }

/** El metodo apyYNom() de tipo publico con devolucion de valores concatena los valores devueltos por los metodos getApellido y getNombre
  * @return devuelve un string conteniendo el apellido y el nombre de la persona separado por un espacio
 */

    
    public String apeYNom () {

        return this.getApellido()+ " " +  this.getNombre();

    }

/** el metodo mostrar() de tipo publico sin devolucion de valores (void - no requiere de return) imprime por pantalla/consola los cuatro atributos
 * definidos en la clase Cliente, Nombre, Apellido, DNI y Saldo.
 */
        
    
    public void mostrar() {
        System.out.println("-----------------------Alumno-------------------------");
        System.out.println("Nombre y Apellido: "+this.nomYApe());
        System.out.println("LU: "+ this.getLu() +"\t"+ "Notas: "+this.nota1+"\t"+this.nota2);
        System.out.println("Promedio: " + promedio() + "\t" + leyendaAprueba());
    }
    
    
}