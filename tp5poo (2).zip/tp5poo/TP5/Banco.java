import java.util.*;
/**
 * clase que permite la liquidacion de sueldo/s de uno o varios empleados
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.1)
 */
public class Banco
{
    // declaracion de V.I.
   private String nombre;
   private int nroSucursal;
   private Localidad localidad;
   private ArrayList<Empleado> empleados;
   private ArrayList<CuentaBancaria> cuentas;
    
   /**
     * Constructor de objetos de la clase Banco - recibe un empleado
     * @param String p_nombre
     * @param Localidad p_localidad
     * @param int p_nroSucursal
     * @param Empleado p_empleado
     */
   
    public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, Empleado p_empleado)
    {
        // inicializacion de V.I.
        this.setNombre(p_nombre);   
        this.setLocalidad(p_localidad);
        this.setNroSucursal(p_nroSucursal);
        this.setEmpleados(new ArrayList<Empleado>());
        this.agregarEmpleado(p_empleado);
    }

    
    /**
     * Constructor de objetos de la clase Banco - recibe ArrayList de empleados
     * @param String p_nombre
     * @param Localidad p_localidad
     * @param int p_nroSucursal
     * @param ArrayList p_empleados
     */
    public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, ArrayList<Empleado> p_empleados)
    {
        // inicializacion de V.I.
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setNroSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
    }
    
    //constructor para version 1.1 de Banco
    
     /**
     * Constructor de objetos de la clase Banco - recibe CuentaBancaria generics
     * @param String p_nombre
     * @param Localidad p_localidad
     * @param int p_nroSucursal
     * @param Empleado p_empleado
     * @param ArrayList<CuentaBancaria> p_cuentas
     */
    
     public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, ArrayList<Empleado> p_empleados, ArrayList<CuentaBancaria> p_cuentas)
    {
        // inicializacion de V.I.
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setNroSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
        this.setCuentas(p_cuentas);
    }
    
    //metodos seters
    
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    private void setLocalidad(Localidad p_localidad){
        this.localidad = p_localidad;
    }
    
    private void setNroSucursal(int p_nroSucursal){
        this.nroSucursal=p_nroSucursal;
    }
    
    private void setEmpleados(ArrayList<Empleado> p_empleados){
        this.empleados = p_empleados;
    }
    
    /**metodo que devuelve un String Nombre
     * @return String nombre
     */
    
    public String getNombre(){
        return this.nombre;
    }
    
    /**metodo que devuelve un objeto de tipo Localidad
     * return Localidad localidad
     */
    
    public Localidad getLocalidad(){
        return this.localidad;
    }
    
    /**metodo que devuelve un int de nroSucursal
     * return int nroSucursal
     */
    
    public int getNroSucursal(){
        return this.nroSucursal;
    }
    
    /** metodo que devuelve un ArrayList de Empleados
     * @param ArrayList p_empleados
     */
    
    public ArrayList <Empleado> getEmpleados(){
        return this.empleados;
    }
    
    /**metodo que permite agregar un Empleado a la lista
     * @param Empleado p_empleado
     * @return boolean
     */
    
    public boolean agregarEmpleado(Empleado p_empleado){
       return this.getEmpleados().add(p_empleado);
    }
     
    
    /**metodo que permite eliminar un Empleado a la lista
     * @param Empleado p_empleado
     * @return boolean
     */
    
    public boolean quitarEmpleado(Empleado p_empleado){
        return this.getEmpleados().remove(p_empleado);
    }
    
    /**metodo que permite agregar un array al ya existente
     * @param ArrayList p_array
     */
    
    public void agregarArrayDeEmpleados(ArrayList<Empleado> p_array){
        this.getEmpleados().addAll(p_array);
    }
    
    /**metodo que imprime en pantalla los empleados con sus respectivos sueldos
     * 
     */
    
    public void listarSueldos(){
    
        int longitud = this.getEmpleados().size();
         
        for (int i=0; i < longitud; i++){
            
            System.out.println(this.getEmpleados().get(i).mostrarLinea());
        }
    }
    
    /**metodo que devuelve el monto total de sueldos a pagar
     * @return double sueldosAPagar
     */
    
    public double sueldosAPagar(){
           
        int longitud = this.getEmpleados().size();
        
        double devolver=0;
        
        for (int i=0; i < longitud;i++){
            
            devolver=devolver+this.getEmpleados().get(i).sueldoNeto();
        }
        
        return devolver;
    }
    
    /**metodo que imprime en pantalla nombre de banco, N°Sucursal, localidad y provincia
     * 
     */
    
    public void mostrar(){
        
        System.out.println("Banco: "+this.getNombre()+"\t Sucursal: "+this.getNroSucursal());
        System.out.println("Localidad: "+this.getLocalidad().getNombre()+"\t Provincia: "+this.getLocalidad().getProvincia()+"\n");
            }
            
    //Metodos Agregados para Version 1.1        
    
    //metodo seters
    
    private void setCuentas(ArrayList<CuentaBancaria> p_cuentas){
        
        this.cuentas = p_cuentas;
        
    }
    
    /**metodo que devuelve un ArrayList Generics de CuentaBancaria
     * @return ArrayList<CuentaBancaria> cuentas
     */
    
    public ArrayList<CuentaBancaria> getCuentas(){
        
        return this.cuentas;
        
    }
    
    /**metodo que permite agregar una CuentaBancaria
     * @param CuentaBancaria p_cuenta
     * @return boolean
     */
    
    public boolean agregarCuentaBancaria(CuentaBancaria p_cuenta){
        
        return this.getCuentas().add(p_cuenta);
        
    }
    
     /**metodo que permite quitar una CuentaBancaria
     * @param CuentaBancaria p_cuenta
     * @return boolean
     */
    
     public boolean quitarCuentaBancaria(CuentaBancaria p_cuenta){
        
        return this.getCuentas().remove(p_cuenta);
        
    }
    
    /**metodo que imprime en pantalla los titulares con cuentas en saldo cero
     * 
     */
    
    public void mostrarSaldoCero(){
       
        System.out.println("Titulares con Cuentas en Saldo Cero");
        System.out.println("------------------------------------------------------------------------");
        
        long nroCuentas = this.getCuentas().size();
        
        for(int i=0; i < nroCuentas;i++){
            
            if (this.getCuentas().get(i).getSaldo() == 0){
               
                System.out.println(this.getCuentas().get(i).getTitular().getNroDni()+
                "\t"+this.getCuentas().get(i).getTitular().apeYNom());
                
            }
        }
        
        System.out.println("------------------------------------------------------------------------");
        
    }
    
    /**metodo que devuelve la cantidad de cuentas con saldo activo o mayor a cero
     * @return int cantidadCuentasActivas
     */
    
    public int cuentasSaldoActivo(){
        
        int devolver=0;
        
        long nroCuentas = this.getCuentas().size();
        
          for(int i=0; i < nroCuentas;i++){
              
              if (this.getCuentas().get(i).getSaldo() > 0){
                  devolver++;
                }
          }
        
       return devolver;
    }
    
    /** metodo que permite mostrar en pantalla un resumen de las cuentas bancarias
     * 
     */
    public void mostrarResumen(){
        
        this.mostrar();
        
        System.out.println("*************************************************************************");
        System.out.println("RESUMEN DE CUENTAS BANCARIAS");
        System.out.println("*************************************************************************\n");
        System.out.println("Número total de Cuentas Bancarias: "+this.getCuentas().size());
        System.out.println("Cuentas Activas: "+this.cuentasSaldoActivo());
        System.out.println("Cuentas Saldo Cero: "+(this.getCuentas().size()-this.cuentasSaldoActivo())+"\n");
        this.mostrarSaldoCero();
    }
        
}