import java.util.*;
/**
 * Clase que permite Gestionar un Comercio en cuanto a Empleados se refiera
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */

public class GestionComercio
{
    
    public static void main (String [] args){
        
        //creamos objetos de tipo Empleado
        
        Empleado emp1 = new Empleado(30100623,"Gonzalez","Juan",3400,1991);
        Empleado emp2 = new Empleado(37045987,"Martinez","Mercedes",2400,1998);
        Empleado emp3 = new Empleado(32550096,"Gomez","Virginia",2000,2000);
        Empleado emp4 = new Empleado(33224455,"Perez","Dario",1500,1980);
        
        //creamos una coleccion de tipo HashMap de Empleados
        
        HashMap<Long,Empleado> lista = new HashMap<Long,Empleado>();
        
        //agregamos a la coleccion los siguientes empleados
        
        lista.put(emp1.getCuil(), emp1);
        lista.put(emp2.getCuil(), emp2);
        lista.put(emp3.getCuil(), emp3);
        
        //creamos un objeto de tipo Comercio
        
        Comercio com = new Comercio("Impulso",lista);
        
        //mostramos la nomina 
        
        com.nomina();
        
        System.out.println("**** Se da de Alta a Perez,Dario ****");
        
        com.altaEmpleado(emp4);
        
        System.out.println("**** Se da de Baja a Gomez, Virginia ****\n");
        
        com.bajaEmpleado(32550096);
        
         com.nomina();
         
        System.out.println("**** Se busca al Empleado con cuil 30100623 ****\n");
        
        com.buscarEmpleado(30100623).mostrar();
    }
}
