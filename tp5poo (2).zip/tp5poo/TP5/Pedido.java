import java.util.*;
/**
 * Clase que permite mantener una lista de Productos Solicitados y ofrecer una interfaz grafica acorde
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class Pedido
{
    // Variables de Instancias
    private Fecha objFecha;
    private Cliente objCliente;
    private ArrayList productosSolicitados;

    /**
     * Constructor de objetos de la clase Pedido - recibe una lista de productos
     * @param Fecha p_fecha
     * @param Cliente p_cliente
     * @param ArrayList p_productos
     */
    public Pedido(Fecha p_fecha, Cliente p_cliente, ArrayList p_productos)
    {
        // inicializacion de V.I.
        this.setObjFecha(p_fecha);
        this.setObjCliente(p_cliente); 
        this.setProductosSolicitados(p_productos);
            
    }
    
        /**
     * Constructor de objetos de la clase Pedido - recibe un producto
     * @param Fecha p_fecha
     * @param Cliente p_cliente
     * @param Producto p_producto
     */
    
        public Pedido(Fecha p_fecha, Cliente p_cliente, Producto p_producto)
    {
         // inicializacion de V.I.
        this.setObjFecha(p_fecha);
        this.setObjCliente(p_cliente); 
        this.setProductosSolicitados(new ArrayList());
        this.agregarProducto(p_producto);
    }
    
    //metodos seters
    
    private void setObjFecha(Fecha p_fecha){
        this.objFecha = p_fecha;
    }
    
    private void setObjCliente(Cliente p_cliente){
        this.objCliente = p_cliente;
    }
    
    private void setProductosSolicitados(ArrayList p_productos){
        this.productosSolicitados = p_productos;
    }
    
    /**metodo que devuelve el valor (objeto) de la V.I. objFecha de tipo Fecha
     * @return Fecha objFecha
     */
    
    public Fecha getObjFecha(){
        return this.objFecha;
    }
    
    /**metodo que devuelve el valor (objeto) de la V.I. objCliente de tipo Cliente
     * @return Cliente objCliente
     */
    
    public Cliente getObjCliente(){
        return this.objCliente;
    }
    
    /**metodo que devuelve el valor (ArrayList) de la V.I. productosSolicitados de tipo ArrayList
     * @return ArrayList productosSolicitados
     */
    
    public ArrayList getProductos(){
        return this.productosSolicitados;
    }
    
    /**metodo que permite agregar un producto a la lista de productosSolicitados
     * @return boolean
     * @param Producto p_producto
     */
    
     public boolean agregarProducto(Producto p_producto) {
       return this.getProductos().add(p_producto);
    }
    
        /**metodo que permite eliminar un producto a la lista de productosSolicitados
     * @return boolean
     * @param Producto p_producto
     */

    public boolean quitarProducto(Producto p_producto) {
       return this.getProductos().remove(p_producto);
    }
    
    /** metodo que devuelve la suma total de los precios al contado de todos los productos de la lista
     * @return doble preciocontado
     */
    
    /**metodo que permite agregar un ArrayList al que ya poseemos
     * @param ArrayList p_array
     */
    
    public void agregarArrayDeProductos(ArrayList p_array){
        this.getProductos().addAll(p_array);
    }
    
    public double totalAlContado(){
        
        int longitud = getProductos().size();
        
        double devolver=0;
        
        for (int i=0; i < longitud;i++){
            
            devolver = devolver +((Producto) this.getProductos().get(i)).precioContado();//casteo y solicitod precio al objeto Producto ya casteado
                            
        }
    
       return devolver;
    }
    
    /** metodo que devuelve la suma total de los precios de lista de todos los productos de la lista
     * @return doble preciolista
     */
    
    
    public double totalFinanciado(){
        
        int longitud = getProductos().size();
        
        double devolver=0;
        
        for (int i=0; i < longitud;i++){
            
            devolver = devolver +((Producto) this.getProductos().get(i)).precioLista();//casteo y solicitod precio al objeto Producto ya casteado
                            
        }
    
       return devolver;
    }
    
    /**metodo que muestra en pantalla precio lista precio contado por cada producto de la lista y el total en general de cada precio
     */
    
    public void mostrarPedido(){
        
        System.out.println("********Detalle del Pedido*********** Fecha: "+this.getObjFecha().verLetra()+"\n");
        System.out.println("Producto\t\t Precio Lista\t Precio Contado");
        System.out.println("-------------------------------------------------------------------------------");
        
        int longitud = this.getProductos().size();
        
        for (int i=0; i < longitud;i++){
            
             System.out.println(((Producto)this.getProductos().get(i)).getDescripcion()+"\t"+((Producto)this.getProductos().get(i)).precioLista()+"\t"+
             ((Producto)this.getProductos().get(i)).precioContado());
       
         }
           System.out.println("-------------------------------------------------------------------------------"); 
        System.out.println("**** Total-----------"+this.totalFinanciado()+"\t"+this.totalAlContado());
       }
}