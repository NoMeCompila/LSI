
/**
 *Clase que define las caracteristicas basicas de una Localidad, nombre y provincia
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class Localidad
{
    // declaracion de V.I.
    private String nombre;
    private String provincia;

    /**
     *Constructor de objetos de la clase Localidad
     *@param String p_nombre
     *@param String p_provincia
     */
    public Localidad(String p_nombre, String p_provincia)
    {
        // inicializacion de V.I.
       this.setNombre(p_nombre);
       this.setProvincia(p_provincia);
    }

    //metodos seters
    
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    private void setProvincia(String p_provincia){
        this.provincia = p_provincia;
    }
    
    /** metodo que devuelve el valor de la V.I. nombre
     * @return String nombre
     */
    
    public String getNombre(){
        return this.nombre;
        
    }
    
    /** metodo que devuelve el valor de la V.I. provincia
     * @return String provincia
     */
       
    public String getProvincia(){
        return this.provincia;
    }
    
    /**metodo que imprime por pantalla la concatenacion de localidad y provincia*/
    public void mostrar(){
        System.out.println("Localidad: "+this.getNombre()+"\t"+"Provincia: "+this.getProvincia());
    }
}
