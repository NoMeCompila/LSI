 /**
 * Una Clase para representar a un Laboratorio
 * para crear los objetos recibe como parametro Nombre, Domicilio y Telefono
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */

/* Se importan las utilidades necesarias para desarrollar las actividades definidas en la clase*/

import java.util.*;


/* se inicializa la clase Laboratorio en modo publico */

public class Laboratorio {

    private String nombre;
    private String domicilio;
    private String telefono;

/**Constructor de objetos de la Clase (constructor completo)*/ 
    
    public Laboratorio (String p_nombre, String p_domicilio, String p_telefono) {

 /*Inicializacion de las Variables de Instancia*/
 
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono(p_telefono);

    }

/**Constructor de objetos de la Clase (constructor sin un parametro de entrada)*/     
    
    public Laboratorio (String p_nombre, String p_domicilio) {

        
 /*Inicializacion de las Variables de Instancia*/
        
        this.setNombre(p_nombre);
        this.setDomicilio(p_domicilio);
        this.setTelefono("vacio"); //al faltar un parametro se inicializa la variable de modo manual

    }

/**Constructor de objetos de la Clase (constructor sin dos parametro de entrada)*/    
    
    public Laboratorio (String p_nombre) {

 /*Inicializacion de las Variables de Instancia*/        
        
        this.setNombre(p_nombre);
        this.setDomicilio("vacio"); //al faltar un parametro se inicializa la variable de modo manual
        this.setTelefono("vacio"); //al faltar un parametro se inicializa la variable de modo manual

    }
    
/**Constructor de objetos de la Clase (constructor sin parametro de entrada)*/    
    
    public Laboratorio () {

/*Inicializacion de las Variables de Instancia*/        
        
        this.setNombre("vacio");  //al faltar un parametro se inicializa la variable de modo manual
        this.setDomicilio("vacio"); //al faltar un parametro se inicializa la variable de modo manual
        this.setTelefono("vacio"); //al faltar un parametro se inicializa la variable de modo manual

    }

 /* setNombre (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_nombre de tipo String 
  * y asigna el valor a la V.I. nombre 
  */
    
    private void setNombre (String p_nombre){
        this.nombre = p_nombre;
       }

  /* setDomicilio (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_domicilio de tipo String 
  * y asigna el valor a la V.I. domicilio 
  */      
       
    private void setDomicilio (String p_domicilio){
        this.domicilio = p_domicilio;
    }
  
 /* setTelefono (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_telefono de tipo String 
  * y asigna el valor a la V.I. telefono 
  */    
    
    private void setTelefono (String p_telefono){
        this.telefono = p_telefono;
    }

 /** getNombre (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia nombre 
  * @return devuelve un String (nombre)
 */    
    
    public String getNombre (){
        return this.nombre; 
    }

 /** getDomicilio (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia domicilio 
  * @return devuelve un String (domicilio)
 */    
    
    public String getDomicilio (){
        return this.domicilio;
    }

 /** getTelefono (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia telefono 
  * @return devuelve un String (telefono)
 */    
    
    public String getTelefono (){
        return this.telefono;
    }

/** el metodo mostrar() de tipo publico sin devolucion de valores (void - no requiere de return) imprime por pantalla/consola los tres atributos
 * definidos en la clase Laboratorio; Nombre, Domicilio y Telefono.
 */

    public void mostrar (){
        System.out.println ("Laboratorio:" + this.getNombre());
        System.out.println ("Domicilio:" + this.getDomicilio());
        System.out.println ("Teléfono:" + this.getTelefono());
    }
}