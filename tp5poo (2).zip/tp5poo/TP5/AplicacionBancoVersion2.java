import java.util.*;
/**
 * clase que permite implementar un sistema automatizado para mostrar el resumen de cuentas bancarias y hacer operacion con ellas
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (2)
 */
public class AplicacionBancoVersion2
{
    
 public static void main (String [] args){
     
     //creamos la localidad
     
     Localidad loc = new Localidad("Capital","Corrientes");
   
     //creamos los empleados que seran enviados en un ArrayList
     
     Empleado emp1 = new Empleado(272675042,"Lorena","Perez",2500, 2012);
     Empleado emp2 = new Empleado(272785942,"Jose","Perez",3500, 2012);
     Empleado emp3 = new Empleado(372975042,"Miguel","Perez",3000, 2012);
     Empleado emp4 = new Empleado(272644042,"Pedro","Perez",1550, 2012);
     Empleado emp5 = new Empleado(274675042,"Juan","Perez",1000, 2012);
   
     ArrayList<Empleado> empleados = new ArrayList<Empleado>();
     
     empleados.add(emp1);
     empleados.add(emp2);
     empleados.add(emp3);
     empleados.add(emp4);
     empleados.add(emp5);
     
     //creamos ArrayList de CuentaBancaria
     
     ArrayList<CuentaBancaria> cuentas = new ArrayList<CuentaBancaria>();
     
     //cuentas que no son con saldo cero
     
     for (int i=0; i < 2000;i++){
         
         Persona per = new Persona(((int)(Math.random() * 10000000)),("Jose"+String.valueOf(i)),("Perez"+String.valueOf(i)),i);
         
         CuentaBancaria cuen = new CuentaBancaria(((int)(Math.random() * 100000)),per,((double)(Math.random() * 10000)));
         
         cuentas.add(cuen);
         
       }
     
       //cuentas que son con saldo cero
       
     for (int i=0; i < 10;i++){
         
         Persona per = new Persona(((int)(Math.random() * 10000000)),("Jose"+String.valueOf(i)),("Perez"+String.valueOf(i)),i);
         
         CuentaBancaria cuen = new CuentaBancaria(((int)(Math.random() * 100000)),per);
         
         cuentas.add(cuen);
         
       }  
       
     //creamos el sistema Banco
     
    Banco ban = new Banco("Rio",loc,3,empleados,cuentas);
    
    //mostramos resumen de cuentas bancarias
    
    ban.mostrarResumen();
    
        
    }
}