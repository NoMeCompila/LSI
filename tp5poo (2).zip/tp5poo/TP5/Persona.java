 /**
 * Una Clase para representar a Personas
 * para crear los objetos recibe como parametro N° DNI, Nombre, Apellido y Año de Nacimiento
 * @author (Marcelo F. Rajoy) 
 * @version (1.1)
 */

/* esta clase fue modificada para dar lugar a nuevas especificaciones necesarias para el correcto funcionamiento del envio de tarjetas de felicita
 * ciones de cumpleaños otorgado por la clase Banco, para las clases que utilizan solo el año de nacimiento, el constructor y los metodos mantienen el resultado y
 * las operaciones necesarias para satisfacer las solicitudes, se incorpora un nuevo constructor que permite recibir la fecha de nacimiento completa y asi satisfacer
 * las nuevas solicitudes.
 */

/* Se importan las utilidades necesarias para desarrollar las actividades definidas en la clase*/

import java.util.*;

/* se inicializa la clase Persona en modo publico */

public class Persona{

/* Variables de Instancia */

    private int nroDni;
    private String nombre;
    private String apellido;
    private Calendar fechaNacimiento; //Modificacion Nueva lo utilizan los metodos set/get AnioNacimiento y FechaNacimiento

/**Constructor de objetos de la Clase (Sobrecargado)
 * @param int p_dni
 * @param String p_nombre
 * @param String p_apellido
 * @param int p_anio
 */ 

    public Persona (int p_dni, String p_nombre, String p_apellido, int p_anio){
    
    /*Inicializacion de las Variables de Instancia*/
    
        this.setNroDni(p_dni);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setAnioNacimiento(p_anio);
        
    }
    
   /**Constructor de objetos de la Clase (Sobrecargado)
 * @param int p_dni
 * @param String p_nombre
 * @param String p_apellido
 * @param Calendar p_fecha 
 */ 

    public Persona (int p_dni, String p_nombre, String p_apellido, Calendar p_fecha){
    
    /*Inicializacion de las Variables de Instancia*/
    
        this.setNroDni(p_dni);
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setFechaNacimiento(p_fecha);
        
    }

 /* setNroDni (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_dni de tipo int 
  * y asigna el valor a la V.I. nroDni 
  */
  
 
    private void setNroDni(int p_dni){
        this.nroDni = p_dni;
    }

 /** getNroDni (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia NroDni 
  * @return devuelve un entero (N° de DNI)
 */
    public int getNroDni () {
        return this.nroDni;
    }

 /* setNombre (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_nombre de tipo String 
 * y asigna el valor a la V.I. nombre
 */
 
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }

/** getNombre (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia nombre 
 * @return devuelve un String (Nombre)
*/
    
    public String getNombre(){
        return this.nombre;
    }

/* setApellido (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_apellido de tipo String 
 * y asigna el valor a la V.I. apellido*/

    private void setApellido (String p_apellido){
        this.apellido = p_apellido;
    }

/** getApellido (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia apellido 
  * @return devuelve un String (Apellido) */
 
    public String getApellido (){
        return this.apellido;
    }

/** setAnioNacimiento (metodo de tipo privado sin devolucion de valores) recibe como parametro una variable llamada p_anio de tipo int
 * y asigna el valor a la V.I. anioNacimiento
 */

    private void setAnioNacimiento(int p_anio){ //MODIFICACION NUEVA
       Calendar cal =  Calendar.getInstance(); //V.T. de tipo Calendar con la instancia actual
       cal.set(p_anio,0,1); //seteamos la V.T. con el año actual y mes enero dia 1
       this.setFechaNacimiento(cal); //mensajeamos al metodo setFechaNacimiento para que almacene en la V.I. correspondiente la fecha seteada
    }

/** getApellido (metodo de tipo publico con devolucion de valores) devuelve el valor de la variable de instancia anioNacimiento
 @return devuelve año de nacimiento  */    
    
    public int getAnioNacimiento(){
        return this.getFechaNacimiento().get(Calendar.YEAR); //Enviamos solamente el Año almacenado en la V.I. de tipo Calendar, para mantener compatibilidad
    }


/** El metodo edad() de tipo publico con devolucion de valores, establece el año actual y calcula la edad con el valor recibido por el metodo getAnioNacimiento
 * @return edad de la persona  
   */

    public int edad(){

        Calendar fechahoy = new GregorianCalendar();
        int anioHoy = fechahoy.get(Calendar.YEAR);
        return anioHoy - this.getAnioNacimiento();
    }

/** El metodo nomYApe() de tipo publico con devolucion de valores concatena los valores devueltos por los metodos getNombre y getApellido
  * @return un string conteniendo el nombre y el apellido de la persona separado por un espacio
 */

    public String nomYApe () {

        return this.getNombre()+ " " + this.getApellido();

    }

/** El metodo apyYNom() de tipo publico con devolucion de valores concatena los valores devueltos por los metodos getApellido y getNombre
  * @return un string conteniendo el apellido y el nombre de la persona separado por un espacio
 */

    
    public String apeYNom () {

        return this.getApellido() + " " + this.getNombre();

    }

    /* metodo NUEVO que permite almacenar una fecha completa que se recibe como parametro en la V.I. fechaNacimiento
     * @param Calendar p_fecha
     */
    
    private void setFechaNacimiento(Calendar p_fecha){
        this.fechaNacimiento = p_fecha;
    }
    
    /** metodo NUEVO que devuelve fecha completa de nacimiento
     * @return Calendar fechaNacimiento
     */
    
    public Calendar getFechaNacimiento(){
        return this.fechaNacimiento;
    }
    
    
    
/** el metodo mostrar() de tipo publico sin devolucion de valores (void - no requiere de return) imprime por pantalla/consola los cuatro atributos
 * definidos en la clase persona, Nombre, Apellido, DNI y Edad.
 */
 

    public void mostrar() {
        System.out.println ("Nombre y Apellido:"+ nomYApe());
        System.out.println ("DNI:"+ this.getNroDni());
        System.out.println ("Edad:"+this.edad());

    }   

    /**metodo que devuelde un valor booleano, TRUE si la fecha actual coincide con la fecha de nacimiento en cuanto a mes y año, FALSE en caso contrario
     * @return boolean TRUE FALSE
     */
    
    public boolean esCumpleaños(){
        Calendar hoy = Calendar.getInstance();
       if(hoy.get(Calendar.MONTH) == this.getFechaNacimiento().get(Calendar.MONTH) && hoy.get(Calendar.DATE) == this.getFechaNacimiento().get(Calendar.DATE)){
           return true;}else{return false;}
    }
}




