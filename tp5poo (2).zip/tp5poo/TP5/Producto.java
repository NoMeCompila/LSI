
/**
 * Clase para comercializar Productos de una drogueria (Abstraccion de Producto)
 * Reutilización de la clase Laboratorio (Conocimiento - V.I. y Parametro)
 * @author (Rajoy, Marcelo Fabian) 
 * @version (1.0)
 */
public class Producto{

    //Variables de Instancias
    private int codigo;
    private String rubro;
    private String descripcion;
    private double costo;
    private int stock = 0;
    private Laboratorio lab;

    /**
     * Constructor de Objetos de la Clase
     * @param int p_codigo
     * @param String p_rubro
     * @param String p_descripcion
     * @param double p_costo
     * @param Laboratorio p_lab
     */
    public Producto(int p_codigo, String p_rubro, String p_descripcion, double p_costo, Laboratorio p_lab) {
        
        // Inicializacion de las Variables de Instancias
   
        this.setCodigo(p_codigo);
        this.setRubro(p_rubro);
        this.setDescripcion(p_descripcion);
        this.setCosto(p_costo);
        this.setLab(p_lab);
        
        
    }

    //declaracion de metodos Seters
    
    private void setStock(int p_stock){
        this.stock = p_stock;
    }
    
    private void setLab(Laboratorio p_lab){
        this.lab = p_lab;
    }
    
    private void setCodigo(int p_codigo){
        this.codigo = p_codigo;
    }
    
    private void setRubro(String p_rubro){
        this.rubro = p_rubro;
    }
    
    private void setDescripcion(String p_descripcion){
        this.descripcion = p_descripcion;
    }
    
    private void setCosto(double p_costo){
        this.costo = p_costo;
    }
    
     /** getLab (metodo de tipo publico con devolucion de valores) devuelve un objeto de tipo Laboratorio 
       * @return devuelve un objeto (Laboratorio)
       */    
      
    public Laboratorio getLab(){
        return this.lab;
    }
    
    /** getCodigo (metodo de tipo publico con devolucion de valores) devuelve un entero
       * @return devuelve entero (Codigo)
       */  
    
    public int getCodigo(){
        return this.codigo;
    }
    
    /** getRubro (metodo de tipo publico con devolucion de valores) devuelve un String
       * @return devuelve String (Rubro)
       */
    
    public String getRubro(){
        return this.rubro;
    }
    
    /** getDescripcion (metodo de tipo publico con devolucion de valores) devuelve un String
       * @return devuelve String (Descripcion)
       */
    
    public String getDescripcion(){
        return this.descripcion;
    }
    
    /** getCosto (metodo de tipo publico con devolucion de valores) devuelve un double
       * @return devuelve double (Costo)
       */
    
    public double getCosto(){
        return this.costo;
    }
    
     /** getStock (metodo de tipo publico con devolucion de valores) devuelve un entero
       * @return devuelve entero (Stock)
       */  
    
    public int getStock(){
        return this.stock;
    }
    
    /** metodo ajuste(int p_cantidad), permite modificar el stock aumentando o disminuyendo su valor*/
    
    public void ajuste(int p_cantidad){
        this.setStock(this.getStock() + p_cantidad);//modifica stock sumando o restando segun el valor ingresado
    }
    
    /** metodo stockValorizado() (metodo de tipo publico con devolucion de valores) retorna el stock con un valor agregado de 12% (double)
     * @return devuelve un doble (Stock Valorizado a 12%)
     */
    
    public double stockValorizado(){
        double temp1 = this.getStock() * this.getCosto(); //multiplica stock por costo
        temp1 = temp1 +(temp1/100)*12; //suma el 12% al calculo anterior
        return temp1;//retorna el stock con un valor agregado de 12%
    }
    
    /** metodo precioLista() retorna el valor de la lista que es agregando un 12% al costo
     * @return devuelve un doble (precioLista)
     */
    
    public double precioLista(){
        return( this.getCosto() + ((this.getCosto()/100)*12)); //retorna el valor de lista agregando un 12% al costo
    }
   
    /** metodo precioContado() retorna el precio de lista con un 5% de descuento
     * @return devuelve un doble (precioContado)
     */
    
    public double precioContado(){
        return (this.precioLista()-((this.precioLista()/100)*5)); //retorna el precio de lista con un 5% de descuento
    }
    
     /** metodo mostrarLinea() devuelve un String concatenando Descripcion, precioLista y precioContado
     * @return devuelve String (mostrarLinea)
     */
       
    public String mostrarLinea(){
        return this.getDescripcion()+"\t"+this.precioLista()+"\t"+this.precioContado(); //Concatenacion de Descripcion, precio lista y precio contado
    }
    
    
    /** el metodo mostrar() de tipo publico sin devolucion de valores (void - no requiere de return) imprime por pantalla/consola la descripcion del producto
      * y el Laboratorio asociado
    */
    
    public void mostrar(){
        System.out.println("-Producto-");
        this.getLab().mostrar();
        System.out.println("\n"+"Rubro: "+this.getRubro());
        System.out.println("Descripcion: "+this.getDescripcion());
        System.out.println("Precio Costo: "+this.getCosto());
        System.out.println("Stock: "+this.getStock()+"\t"+"-"+"\t"+"Stock Valorizado: "+this.stockValorizado());
    }
    
    
}