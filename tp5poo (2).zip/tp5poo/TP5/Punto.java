/**Una clase que establece el concepto de "Punto" que colabora para trabajar con figuras geometricas, se abstraen las caracteristicas basicas de un punto.
 * @author (Marcelo F. Rajoy)
 * @version (1.0)
 */
public class Punto {

//Variables de Instancias
    private double x;
    private double y;

/**Constructor de objetos de la clase (Sobrecargado-Sin Parametros)*/
    
    public Punto (){
       this.setX(0);
       this.setY(0);
    }
    
/**Constructor de objetos de la clase (Sobrecargado-Con Parametros)*
 * @param p_x de tipo double
 * @param p_y de tipo double
 */    
    
    public Punto(double p_x, double p_y){
        this.setX(p_x);
        this.setY(p_y);
    }
    
//Se declaran los Seters, en todos los casos realizan la misma operacion, asignar un valor que reciben como parametro a una V.I.    

    private void setX(double p_x){
        this.x = p_x;
    }
    
    private void setY(double p_y){
        this.y = p_y;
    }
    
/**Metodo getX devuelve el valor de la Variable de Instancia X
 * return un double
 */
    
    public double getX(){
        return this.x;
    }
    

/**Metodo getY devuelve el valor de la Variable de Instancia Y
 * return un double
 */    
    
    public double getY(){
        return this.y;
    }
 
/**Metodo distanciaA obtiene el calculo de distancia entre el mismo objeto y otro objeto de Tipo Punto
 * @param p_ptoDistante de tipo Objeto Punto
 * @return un double
 */        
        
    public double distanciaA (Punto p_ptoDistante){
    
        double X1 = p_ptoDistante.getX();
        double Y1 = p_ptoDistante.getY();
        
        double X2 = this.getX();
        double Y2 = this.getY();
        double retornar = Math.hypot(X2-X1, Y2-Y1);
        return retornar;
       
    
    }
    
/**Metodo desplazar recibe como parametros dos valores double para establecer la nueva ubicacion del Punto
 * @param p_dx de tipo double
 * @param p_dy de tipo double
 */    
    
    public void desplazar (double p_dx, double p_dy){
        this.setX(this.getX() + p_dx);
        this.setY(this.getY() + p_dy);
    }
    
/**Metodo mostrar() imprime en pantalla la ubicacion de las coordenadas X Y
 * 
 */    
    
    public void mostrar(){
        System.out.println("Punto. X:"+ this.getX() + " Y:"+  this.getY());
    }

/**Metodo coordenadas() devuelve un String con los valores de X e Y encerrados entre parentesis
 * @return un String
 */    
    
    public String coordenadas(){
       
                return "("+ this.getX() + " " +this.getY() +")";
        
    }

}
