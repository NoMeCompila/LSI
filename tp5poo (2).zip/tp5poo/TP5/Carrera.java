import java.util.*;
/**
 * clase que permite instanciar un Curso con sus respectivos alumnos y operar con ellos
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class Carrera
{
    public static void main (String [] args){
   
    //creamos los objetos de tipo Alumno    
        
    Alumno alum1 = new Alumno(32555, "Pedro","Gomez");
    Alumno alum2 = new Alumno(23564, "Maria","Vasquez");
    Alumno alum3 = new Alumno(30123, "Juan","Perez");    
    Alumno alum4 = new Alumno(32655, "Marcela","Martinez");
    alum1.setNota1(7);
    alum1.setNota2(8);
     alum2.setNota1(9);
    alum2.setNota2(4);
     alum2.setNota1(6);
    alum2.setNota2(7);
     alum3.setNota1(10);
    alum3.setNota2(8);
     alum4.setNota1(5);
    alum4.setNota2(9);
    //creamos coleccion de tipo HashMap
    
    HashMap<Integer,Alumno> cole = new HashMap<Integer,Alumno>();
    
    //agregamos a la coleccion los siguientes alumnos
    
    cole.put(alum1.getLu(),alum1);
    cole.put(alum2.getLu(),alum2);
    cole.put(alum3.getLu(),alum3);
    
    //creamos un objeto de tipo Curso
    
    Curso cur = new Curso("Curso-1",cole);
    
    //incorporamos a el ultimo alumno por medio del metodo inscribirAlumno
    
    cur.inscribirAlumno(alum4);
    
    //imprimimos en pantalla los datos solicitados
    
    System.out.println("Cantidad de Inscriptos: "+cur.cantidadDeAlumnos()+"\n");
    
    cur.mostrarInscriptos();
    
    System.out.println("\n****-- Se da de baja a Pedro porque abandona el curso -- ****");
    
    cur.quitarAlumno(32555);
    
    System.out.println("\n¿Está Pedro Gomez Inscripto?(int) =>"+cur.estaInscripto(32555));
    System.out.println("\n¿Está Pedro Gomez Inscripto?(obj) =>"+cur.estaInscripto(alum1));
    
    System.out.println("\n****-- Busca y muestra el alumno con Número de Libreta 30123--****\n");
    
    cur.buscarAlumno(30123).mostrar();
    
    System.out.println("\n****-- Mostrar Promedio del Alumno 23564--****\n");
    System.out.println("Promedio: "+cur.buscarAlumno(23564).promedio());
    
            
}
}