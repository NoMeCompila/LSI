import java.util.*;
/**
 * clase que permite implementar un sistema automatizado de pago de sueldos
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class AplicacionBanco
{
    
 public static void main (String [] args){
     
     //creamos la localidad
     
     Localidad loc = new Localidad("Capital","Corrientes");
   
     //creamos los empleados que seran enviados en un ArrayList
     
     Empleado emp1 = new Empleado(272675042,"Lorena","Perez",2500, 2012);
     Empleado emp2 = new Empleado(272785942,"Jose","Perez",3500, 2012);
     Empleado emp3 = new Empleado(372975042,"Miguel","Perez",3000, 2012);
     Empleado emp4 = new Empleado(272644042,"Pedro","Perez",1550, 2012);
     Empleado emp5 = new Empleado(274675042,"Juan","Perez",1000, 2012);
   
     ArrayList<Empleado> empleados = new ArrayList<Empleado>();
     
     empleados.add(emp1);
     empleados.add(emp2);
     empleados.add(emp3);
     empleados.add(emp4);
     empleados.add(emp5);
     
     //creamos el sistema Banco
     
    Banco ban = new Banco("Rio",loc,3,empleados);
    
    //mostrarmos banco, sucursal, provincia y localidad
    
    ban.mostrar();
    
    //imprimimos listado de sueldos
    ban.listarSueldos();
    
     //imprimimos total a pagar
    System.out.println("Total a Pagar-------------------------------"+ban.sueldosAPagar());
     
    }
}