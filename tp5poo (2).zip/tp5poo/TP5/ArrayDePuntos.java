import java.util.*;
/**
 * Clase que permite crear un array de Puntos a partir de los datos ingresado por el usuario
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class ArrayDePuntos
{
  
    public static void main (String [] args){
        
        //V.I.
        
        Punto [] puntos = new Punto[6];
        Scanner teclado =new Scanner(System.in);  
        double x;
        double y;
        
        System.out.println("--------------Array de Puntos--------------");
        
        System.out.println("\nLongitud del Array: "+puntos.length+"\n");
      
        for(int i=0; i < 6; i++){
            System.out.println("Ingrese Coordenadas para Punto=> "+(i+1)+"\n");
            System.out.print("Ingrese Coordenada X: ");
            x = Double.valueOf(teclado.next());
            System.out.print("Ingrese Coordenada Y: ");
            y = Double.valueOf(teclado.next());
            
            puntos[i]=new Punto(x,y);
            
        }
        
        System.out.println("\n"+"Coordenadas de los Puntos del Array\n");
        
        for (int i=0; i <6; i++){
            System.out.print("Coordenadas de Punto=> "+(i+1)+" => "); puntos[i].mostrar();
        }
    
        System.out.println("\n"+"Distancia entre Puntos\n");
        
        for (int i=0; i < (puntos.length-1);i++){
        
        System.out.println("Distancia de Punto "+(i+1)+" a Punto "+(i+2)+" => "+ puntos[i].distanciaA(puntos[i+1]));
            
        }
    }
    
}
    
