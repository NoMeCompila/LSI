import java.util.*;
/**
 * Clase para manipulacion de Fechas
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class Fecha
{
    // declaracion de V.I.
    private int dia;
    private int mes;
    private int anio;

    /**
     * Constructor de Objetos de la clase Fecha(Sobrecargado), Sin parametro, Instancia la Fecha Actual
     */
    public Fecha()
    {
        // initialise instance variables
        Calendar hoy = Calendar.getInstance();
        this.setDia(hoy.get(Calendar.DATE));
        this.setMes(hoy.get(Calendar.MONTH));
        this.setAnio(hoy.get(Calendar.YEAR));
    }

    /** 
     *  Constructor de Objetos de la clase Fecha(Sobrecargado), Con parametros, Instancia la Fecha segun parametros recibidos
     *  @param int p_dia
     *  @param int p_mes
     *  @param int p_anio
     */
    
    public Fecha(int p_dia, int p_mes, int p_anio){
        this.setDia(p_dia);
        this.setMes(p_mes);
        this.setAnio(p_anio);
    }
    
     /** 
     *  Constructor de Objetos de la clase Fecha(Sobrecargado), Con parametros, Instancia la Fecha segun objeto de tipo Calendar
     *  @param Calendar p_fecha
     */
    
    public Fecha(Calendar p_fecha){
        
        this.setDia(p_fecha.get(Calendar.DATE));
        this.setMes(p_fecha.get(Calendar.MONTH));
        this.setAnio(p_fecha.get(Calendar.YEAR));
    }
    
    /** 
     *  Constructor de Objetos de la clase Fecha(Sobrecargado), Con parametros, Instancia la Fecha segun objeto de tipo Fecha
     *  @param Fecha p_fecha
     */
    
    public Fecha(Fecha p_fecha){
        
        this.setDia(p_fecha.getDia());
        this.setMes(p_fecha.getMes());
        this.setAnio(p_fecha.getAnio());
    }
    
    /* Metodos SETERS*/
    
    private void setDia(int p_dia){
        this.dia =p_dia;
    }
    
    private void setMes(int p_mes){
        this.mes = p_mes;
    }
    
    private void setAnio(int p_anio){
        this.anio = p_anio;
    }
    
    /** metodo que devuelve el valor de la V.I. dia
     * @return int dia
     */
    
    public int getDia(){
        return this.dia;
    }
    
    /** metodo que devuelve el valor de la V.I. mes
     * @return int mes
     */
    
    public int getMes(){
        return this.mes;
    }
    
    /** metodo que devuelve el valor de la V.I. anio
     * @return int anio
     */
    
    public int getAnio(){
        return this.anio;
    }
    
    /**metodo que recibe un parametro de tipo int e incrementa la fecha actual del objeto segun este parametro recibido, retorna objeto tipo Fecha modifico, pero no cambia
     * la fecha actual del objeto
     * @param int dias
     * @return Fecha incrementarSinCambios
     */
    
    public Fecha incrementarSinCambios(int dias){
        
        Fecha enviar = new Fecha(this.getDia(),this.getMes(),this.getAnio());
        Calendar fecha = Calendar.getInstance();
        fecha.set(enviar.getAnio(), enviar.getMes(), enviar.getDia());
        fecha.add(Calendar.DATE,dias);
        enviar.setDia(fecha.get(Calendar.DATE));
        enviar.setMes(fecha.get(Calendar.MONTH));
        enviar.setAnio(fecha.get(Calendar.YEAR));
              
        return enviar;
    }
    
     /**metodo que cambia el valor de la fecha actual del objeto y retorna objeto tipo Fecha modificado
     * @param int p_incremento
     * @return Fecha incrementarFecha
     */
    
     public Fecha incrementarFecha(int p_incremento){
        
        Calendar fecha = Calendar.getInstance();
        fecha.set(this.getAnio(), this.getMes(), this.getDia());
        fecha.add(Calendar.DATE,p_incremento);
        this.setDia(fecha.get(Calendar.DATE));
        this.setMes(fecha.get(Calendar.MONTH));
        this.setAnio(fecha.get(Calendar.YEAR));
              
        return this;
     }
     
     /**metodo que devuelve un String concatenado de numeros Dia, Mes y Año, separados por una /
      * @return String verNumero
      */
     
     public String verNumero(){
         return this.getDia()+"/"+(this.getMes()+1)+"/"+this.getAnio();
        }
        
     /** metodo que devuelve un String concatenado de N° dia mas nombre del mes mas N° del año
      * @return String verLetra
      */   
     public String verLetra(){
         
         return this.getDia()+" de "+this.nombreMes()+" de "+this.getAnio();
     }
     
     /** metodo que devuelve el nombre del mes segun el numero de mes almacenado en la V.I. mes
      * @return String nombreMes
      */
     
     public String nombreMes(){
         switch (this.getMes()){
             case 0: return "Enero";
             case 1: return "Febrero";             
             case 2: return "Marzo";
             case 3: return "Abril";
             case 4: return "Mayo";
             case 5: return "Junio";
             case 6: return "Julio";
             case 7: return "Agosto";
             case 8: return "Septiembre";
             case 9: return "Octubre";
             case 10: return "Noviembre";
             case 11: return "Diciembre";
             default: return "";
            }
        }
        
        /**metodo que recibe un parametro de tipo Fecha, obtiene de el, el tiempo en milisegundos y calcula los dias transcurridos con la Fecha almacenada en el objeto que
         * lo recibe, devolviendo la cantidad de dias transcurridos entre fechas, (puede ser negativo)
         * @param Fecha p_fecha
         * @return int diasCorridos
         */
        
        public int diasCorridos(Fecha p_fecha){
           Calendar objetoactual = Calendar.getInstance();
           objetoactual.set(this.getAnio(),this.getMes(),this.getDia());
           Calendar objetoingreso = Calendar.getInstance();
           objetoingreso.set(p_fecha.getAnio(),p_fecha.getMes(),p_fecha.getDia());
           
           long objact = objetoactual.getTimeInMillis();
           long objing = objetoingreso.getTimeInMillis();
        
           double retornar = (objing-objact)/1000/60/60/24;
           int devolver =(int)retornar;
        return devolver;
        }
        
          
       
}
