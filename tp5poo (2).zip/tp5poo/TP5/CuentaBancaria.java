
/**
 * Clase para crear Cuentas Bancarias abstrayendose desde el concepto general
 * Conocimiento con la clase Persona (V.I. y Parametro)
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */
public class CuentaBancaria
{
    //Declaracion de V.I.
  private int nroCuenta;
  private double saldo;
  private Persona titular;

    /**
     * Constructor de objetos de la clase CuentaBancaria (Constructor Sobrecargado)
     * @param int p_nroCuenta
     * @param Persona p_titular
     */
    public CuentaBancaria(int p_nroCuenta, Persona p_titular){
        // Inicializacion de V.I.
        this.setNroCuenta(p_nroCuenta);
        this.setTitular(p_titular);
        this.setSaldo(0);
    }
    
     /**
     * Constructor de objetos de la clase CuentaBancaria (Constructor Sobrecargado)
     * @param int p_nroCuenta
     * @param Persona p_titular
     * @param double p_saldo
     */
    
    public CuentaBancaria(int p_nroCuenta, Persona p_titular, double p_saldo){
        // Inicializacion de V.I.
        this.setNroCuenta(p_nroCuenta);
        this.setTitular(p_titular);
        this.setSaldo(p_saldo);
    }
    
    //metodos Seters
    
    private void setNroCuenta(int p_nroCuenta){
        this.nroCuenta = p_nroCuenta;
    }
    
    private void setSaldo(double p_saldo){
        this.saldo = p_saldo;
    }
    
    private void setTitular(Persona p_titular){
        this.titular = p_titular;
    }
    
    /**metodo que devuelve el valor de la V.I. nroCuenta
     * @return int nroCuenta
     */
    
    public int getNroCuenta(){
        return this.nroCuenta;
    }
    
    /**metodo que devuelve el valor de la V.I. saldo
     * @return double saldo
     */
    
    public double getSaldo(){
        return this.saldo;
    }
    
    /**metodo que devuelve el valor de la V.I. titular
     * @return Persona titular
     */
    
    public Persona getTitular(){
        return this.titular;
    }
    
    /**metodo que aumenta el valor de la V.I. saldo con el valor recibido por parametro y devuelve un double
     * @return double saldo
     */
    
    public double depositar(double p_importe){
        
        this.setSaldo(this.getSaldo()+p_importe);
        return this.getSaldo();
    }
    
    /**metodo que disminuye el valor de la V.I. saldo con el valor recibido por parametro y devuelve un double
     * @return double saldo
     */
    
    
    public double extraer(double p_importe){
        
        this.setSaldo(this.getSaldo()-p_importe);
        return this.getSaldo();
    }
    
    /**metodo que imprime por pantalla el datelle de la Cuenta Bancaria con los siguientes datos: Titular,
     * Saldo
     */
    
    public void mostrar(){
        System.out.println ("\n"+"-Cuenta Bancaria-"+"\n");
        System.out.println ("Titular: "+this.getTitular().nomYApe()+"("+this.getTitular().edad()+" años)");
        System.out.println ("Saldo: "+this.getSaldo());
    }
     
    /**metodo que devuelve una concatenacion de N° de cuenta + Nombre y Apellido del titular + el Saldo
     * @return String toStrinf
     */
    
    public String toStrinf(){
        return this.getNroCuenta()+"\t"+this.getTitular().nomYApe()+"\t"+this.getSaldo();
    }
    
}