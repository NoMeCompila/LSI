import java.util.*;
public class AplicacionBanco{
    public static void main(String args []){
        
        //instancia de la clase Localidad
        Localidad localidad = new Localidad("Corrientes Capital","Corrientes");
        
        //instancias de la clase empleado
        Empleado emp1 = new Empleado(12345,"Juan","Perez",2000, 2010);
        Empleado emp2 = new Empleado(67891,"Rodrigo","Roman",5000, 2010);
        Empleado emp3 = new Empleado(34567,"Pablo","Gómez",5000, 2008);
        
        //instancia del contenedor de la clase Empleado
        ArrayList <Empleado> empleados = new ArrayList<Empleado>();
       
        
        //instancia de la clase Banco
        Banco banco = new Banco("Rio",localidad,1,empleados);
        
        
        //agreagamos empleados a la coleccion
        banco.agregarEmpleado(emp1);
        banco.agregarEmpleado(emp2);
        banco.agregarEmpleado(emp3);
        
        //mostrar los datos del banco
        banco.mostrar();
        
        //listamos los datos de los empleados
        banco.listarSueldos();
        
        //despedimos un empleado y volvemos a mostrar los datos
        banco.quitarEmpleado(emp3);
        banco.mostrar();
        banco.listarSueldos();
    }
}
