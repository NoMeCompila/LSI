/**
 * descripcion: permite crear objetos de la clase Banco
 * @author Caballero, Fernando
 * @version 1.0
 */
import java.util.*;
public class Banco{
    //atributos
    private String nombre;
    private int noSucursal;
    private Localidad localidad;
    private ArrayList <Empleado> empleados;
    private ArrayList <CuentaBancaria> cuentas;
    
    
    /**
     * descripcion: constructor sobrecargado de la clase banco
     * @param String p_nombre, Localidad p_localidad, int p_noSucursal, Empleado p_empleado
     */
    public Banco(String p_nombre, Localidad p_localidad, int p_noSucursal, Empleado p_empleado){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setNoSucursal(p_noSucursal);
        this.setEmpleados(new ArrayList<Empleado>());
        this.agregarEmpleado(p_empleado);
    }
    
    
     /**
     * descripcion: constructor sobrecargado de la clase banco
     * @param String p_nombre, Localidad p_localidad, int p_noSucursal, ArrayList p_empleados
     */
    public Banco(String p_nombre, Localidad p_localidad, int p_noSucursal, ArrayList <Empleado >p_empleados){
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setNoSucursal(p_noSucursal);
        this.setEmpleados(p_empleados);
    }
    
    public Banco(String p_nombre, Localidad p_localidad, int p_nroSucursal, 
                 ArrayList<Empleado> p_empleados, ArrayList<CuentaBancaria> p_cuentas){
        
        this.setNombre(p_nombre);
        this.setLocalidad(p_localidad);
        this.setNoSucursal(p_nroSucursal);
        this.setEmpleados(p_empleados);
        this.setCuentas(p_cuentas);
    }
    /**
     * descripcion: metodos setters y getters
     */
    private void setNombre(String p_nombre){
        this.nombre= p_nombre;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    
    private void setLocalidad(Localidad p_localidad){
        this.localidad = p_localidad;
    }
    
    public Localidad getLocalidad(){
        return this.localidad;
    }
    
    private void setNoSucursal(int p_noSucursal){
        this.noSucursal = p_noSucursal;
    }
    
    public int getNoSucursal(){
        return this.noSucursal;
   }
    
    private void setEmpleados(ArrayList <Empleado> p_empleados){
        this.empleados = p_empleados;
   }
    
    public ArrayList <Empleado> getEmpleados(){
        return this.empleados;
   }
    
   private void setCuentas(ArrayList<CuentaBancaria> p_cuentas){        
        this.cuentas = p_cuentas;  
    }
    
   public ArrayList<CuentaBancaria> getCuentas(){       
        return this.cuentas;     
   }
    /**
     * descripcion: permite agregar un empleado a la coleccion
     * @return this.getEmpleados().add(empleado)
     */
    public boolean agregarEmpleado(Empleado p_empleado){
        return this.getEmpleados().add(p_empleado);
   }
    
    /**
     * descripcion: permite quitar empleados de la coleccion
     * @return this.getEmpleados().remove(empleado)
     */
    public boolean quitarEmpleado(Empleado p_empleado){
        return this.getEmpleados().remove(p_empleado);
   }
   
   
     /**
     * descripcion: metodo que permite agregar una CuentaBancaria
     * @param CuentaBancaria p_cuenta
     * @return boolean
     */
    
    public boolean agregarCuentaBancaria(CuentaBancaria p_cuenta){
        return this.getCuentas().add(p_cuenta);  
    }
    
     /**
     * descripcion: metodo que permite quitar una CuentaBancaria
     * @param CuentaBancaria p_cuenta
     * @return boolean
     */
    
     public boolean quitarCuentaBancaria(CuentaBancaria p_cuenta){       
        return this.getCuentas().remove(p_cuenta);        
    }
   /**
    * descripcion: metodo que lista los datos de los empleados
    */
   public void listarSueldos(){
        int longitud = this.getEmpleados().size();
        for (int i=0; i < longitud; i++){
            System.out.println(this.getEmpleados().get(i).mostrarLinea());
        }
   }
   
   /**
    * descripcion: retorna el sueldo neto de cada uno de los empleados
    * @return sueldoNet
    */
   public double sueldosAPagar(){   
       int longitud = this.getEmpleados().size();
       double sueldoNet = 0;
       for (int i=0; i < longitud;i++){
           sueldoNet += this.getEmpleados().get(i).saldoNeto();
       }
       return sueldoNet;
   }
   
   /**
    * descripcion: muestra en pantalla los datos de los empleados
    */
   
   public void mostrar(){ 
       System.out.println("Banco: "+this.getNombre()+"\t Sucursal: "+this.getNoSucursal());
       System.out.println("Localidad: "+this.getLocalidad().getNombre()+"\t Provincia: "
       +this.getLocalidad().getProvincia()+"\n");
   }
   
   public void mostrarSaldoCero(){
       
       System.out.println("Titulares con Cuentas en Saldo Cero");
       System.out.println("------------------------------------------------------------------------");       
       long nroCuentas = this.getCuentas().size();        
       for(int i=0; i < nroCuentas;i++){           
            if (this.getCuentas().get(i).getSaldo() == 0){               
                System.out.println(this.getCuentas().get(i).getTitular().getNroDni()+
                "\t"+this.getCuentas().get(i).getTitular().apeYNom());                
            }
       }        
       System.out.println("------------------------------------------------------------------------");        
    }
    
     
    /**
     * descripcion: metodo que devuelve la cantidad de cuentas con saldo activo o mayor a cero
     * @return cantidadCuentasActivas
     */
    
    public int cuentasSaldoActivo(){        
       int cuentas=0;        
       long nroCuentas = this.getCuentas().size();        
       for(int i=0; i < nroCuentas;i++){              
              if (this.getCuentas().get(i).getSaldo() > 0){
                  cuentas++;
              }
       }        
       return cuentas;
    }
    
    /** 
     * descripcion: metodo que permite mostrar en pantalla un resumen de las cuentas bancarias
     */
    public void mostrarResumen(){
        
        this.mostrar();
        
        System.out.println("*************************************************************************");
        System.out.println("RESUMEN DE CUENTAS BANCARIAS");
        System.out.println("*************************************************************************\n");
        System.out.println("Número total de Cuentas Bancarias: "+this.getCuentas().size());
        System.out.println("Cuentas Activas: "+this.cuentasSaldoActivo());
        System.out.println("Cuentas Saldo Cero: "+(this.getCuentas().size()-this.cuentasSaldoActivo())+"\n");
        this.mostrarSaldoCero();
    }
}
