import java.util.*;
/**
 * descripcion: permite crear objetos contenedores de la clase Curso. 
 * @author  Caballero, Fernando
 * @version 1.0
 */
public class Curso{
    //atributos
    private String nombre;
    private HashMap <Integer,Alumno> alumnos;
    
    /**
     * descripcion: Constructor de objetos de la Clase Curso-no conoce a ningun alumno
     * @param String p_nombre
     */
    public Curso(String p_nombre){

        this.setNombre(p_nombre);
        
    }
    
     /**
     * Constructor de objetos de la Clase Curso-conoce a uno o mas alumnos
     * @param String p_nombre, HashMap<Integer, Alumno> p_alumnos 
     */
    
    public Curso(String p_nombre, HashMap<Integer, Alumno> p_alumnos){
        
        this.setNombre(p_nombre);
        this.setAlumnos(p_alumnos);
    
    }
    
        
    private void setNombre(String p_nombre){
        this.nombre = p_nombre;
    }
    
    private void setAlumnos(HashMap<Integer, Alumno> p_alumnos){
        this.alumnos = p_alumnos;
    }
    
    /**metodo que devuelve un String correspondiente a nombre
     * @return String nombre
     */
    
    public String getNombre(){
        return this.nombre;
    }
    
    /**metodo que devuelve una coleccion de tipo HashMap
     * @return HashMap<Integer,Alumno> alumnos
     */
    
    public HashMap<Integer, Alumno> getAlumnos(){
        return this.alumnos;
    }
    
   /**
     * descripcion: metodo que permite inscribir un alumno agregandolo a la coleccion
     * @param p_alumno
     */
    public void inscribirAlumno(Alumno p_alumno){        
        this.getAlumnos().put(p_alumno.getLu(),p_alumno);       
   }
   
   /**metodo que permite quitar a un alumno de la coleccion
     * @return Alumno
     * @param int p_lu
     */
    
   public Alumno quitarAlumno(int p_lu){
        return this.getAlumnos().remove(p_lu);
   }
   
   /**
    * descripcion:  devuelve la cantidad de alumnos que estan en la coleccion
   * @return alumnos
   */
    
   public int cantidadDeAlumnos(){
        return this.getAlumnos().size();
   }
   
       /**metodo que permite saber si el alumno se encuentra en la coleccion
     * @return boolean
     * @param int p_lu
     */
    
 /**metodo que permite saber si el alumno se encuentra en la coleccion
     * @return boolean
     * @param Alumno p_alumno
     */
    
    public boolean estaInscripto(Alumno p_alumno){
        return this.getAlumnos().containsValue(p_alumno);
    }
    
    /**metodo que permite buscar un alumno en la coleccion a partir de LU
     * @param int p_lu
     * @return Alumno
     */
    
    public Alumno buscarAlumno(int p_lu){
        return this.getAlumnos().get(p_lu);
    }
    
    /**metodo que permite imprimir en pantalla el promedio del alumno
     * @param int p_lu
     */
    
    public void imprimirPromedioDelAlumno(int p_lu){
        System.out.println("Promedio: "+this.getAlumnos().get(p_lu).promedio());
    }
    
    /**metodo que imprime en pantalla los inscriptos (LU y NyA)
     * 
     */
    
    public void mostrarInscriptos(){
        
       for(Map.Entry<Integer,Alumno> alum:alumnos.entrySet()){
           
           System.out.println(alum.getValue().getLu()+"\t"+alum.getValue().nomYape());
        }
    }
}
