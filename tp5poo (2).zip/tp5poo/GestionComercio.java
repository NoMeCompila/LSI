import java.util.*;
/**
 * Clase que permite Gestionar un Comercio en cuanto a Empleados se refiera
 * 
 * @author (Marcelo F. Rajoy) 
 * @version (1.0)
 */

public class GestionComercio
{
    
    public static void main (String [] args){
        
        //instancia de objetos de tipo Empleado
        
        Empleado emp1 = new Empleado(3456465,"Perez","Juan",3400,1991);
        Empleado emp2 = new Empleado(3456456,"Rodriguez","Natalia",2400,1998);
        Empleado emp3 = new Empleado(40252525,"Aguilar","Roberto",2000,2000);
        Empleado emp4 = new Empleado(65454545,"Caballero","Fernando",1500,1980);
        
        //creamos una coleccion de tipo HashMap de Empleados
        
        HashMap<Long,Empleado> lista = new HashMap<Long,Empleado>();
        
        //agregamos a la coleccion los siguientes empleados
        
        lista.put(emp1.getCuil(), emp1);
        lista.put(emp2.getCuil(), emp2);
        lista.put(emp3.getCuil(), emp3);
        
        //creamos un objeto de tipo Comercio
        
        Comercio com = new Comercio("Impulso",lista);
        
        
        com.nomina();
        
        System.out.println("**** Se da de Alta a Perez,Dario ****");
        
        com.altaEmpleado(emp4);
        
        System.out.println("**** Se da de Baja a Aguilar Roberto ****\n");
        
        com.bajaEmpleado(40252525);
        
        com.nomina();
         
        System.out.println("**** Se busca al Empleado con cuil 30100623 ****\n");
        
        com.buscarEmpleado(30100623).mostrar();
    }
}
