public class Alumno{
   
   //atributos
   private  int     lu;
   private  String  nom;
   private  String   ape;
   private  double   not1;
   private  double   not2;
   
   //getters
   public int getLu(){
       return this.lu;
   }
   
   public String getNom(){
       return this.nom;
   }
   
   public String getApe(){
       return this.ape;
   }
   
   public double getNot1(){
       return this.not1;
   }
    public double getNot2(){
      return this.not2;
   }
   //setters
   private void setLu(int p_lu){
       this.lu = p_lu;
   }
   
   private void setNom(String p_nom){
       this.nom = p_nom;
   }
   
   private void setApe(String p_ape){
       this.ape = p_ape;
   }
   
   private void setNot1(double p_not1){
       this.not1 = p_not1;
   }
   
    private void setNot2(double p_not2){
       this.not2 = p_not2;
   }
   //constructor
   public Alumno(int p_lu, String p_nom, String p_ape, double p_not1, double p_not2){
       this.setLu(p_lu);
       this.setNom(p_nom);
       this.setApe(p_ape);
       this.setNot1(p_not1);
       this.setNot2(p_not2);
   }
   //metodos
   public String apeYnom(){
       return this.getApe()+" "+this.getNom();
   }
   
   public String nomYape(){
       return this.getNom()+" "+this.getApe();
   }
   
   public double promedio(){
      double acum = this.getNot1() + this.getNot2();
      double prom = acum/2;
      return prom;
   }
   
   public boolean aprueba(){
       if( this.promedio() > 6.0){
           return true;
       }else{
           return false;
       }
   }
   
   public String leyendaAprueba(){
       if(this.aprueba()==true){
           return "APROBADO";
       }else{
           return "DESAPROBADO";
       }
   }
   
   public void mostrar(){
       System.out.println("Nombre y Apellido: "+this.nomYape());
       System.out.println("LU: "+this.getLu());
       System.out.println("Notas: "+this.getNot1()+"-"+this.getNot2());
       System.out.println("Promedio: "+this.promedio());
       System.out.println(this.leyendaAprueba());
   }
}
