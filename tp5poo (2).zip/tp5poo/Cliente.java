import java.util.*;
/**
 * Esta clase representa una abstraccion del cliente y sus datos.
 * 
 * @author Caballero, Fernando 
 * @version 
 */
public class Cliente
{
    private int dni;
    private String apellido;
    private String nombre;
    private double saldo;
    
    public Cliente (int p_dni, String p_apellido, String p_nombre, double p_saldo ){
     this.setDni(p_dni);
     this.setApellido(p_apellido);
     this.setNombre(p_nombre);
     this.setSaldo(p_saldo);
    } 
    /**
     * Accerores (mutadores) asignan valores a los atributos
     * 
     * @param int p_NroDni, String p_Nombre, String p_Apellido, double saldo
     * 
     */
    private void setDni(int dni ){
     this.dni=dni;
    }
    private void setApellido(String apellido){
     this.apellido=apellido;
    }
    private void setNombre(String nombre){
     this.nombre=nombre;
    }
    private void setSaldo(double saldo){
     this.saldo=saldo;
    }
    /**
     * Accesores (observadores) muestran los atributos
     * 
     *  @param int p_NroDni, String p_Nombre, String p_Apellido, double saldo
     */
    public int getDni(){
     return this.dni;
    }
    public String getApellido(){
     return this.apellido;
    }
    public String getNombre(){
     return this.nombre;
    }
    public double getSaldo(){
     return this.saldo;
    }
    public void mostrar(){
        System.out.println("DNI: " +this.getDni());
        System.out.println("Apellido: " +this.getApellido());
        System.out.println("Nombre: " +this.getNombre());
        System.out.println("Saldo: " +this.getSaldo());
    }
    public double nuevoSaldo(double p_saldo){
     double nuevoSaldo=p_saldo;
     return nuevoSaldo;
    }
    public double agregaSaldo(double p_saldo){
     double agregaSaldo = (getSaldo()) + nuevoSaldo(p_saldo);
     return agregaSaldo;
    }
    public double apeYnom(String p_nombre, String p_apellido){
     String apeYnom = apeYnom(p_nombre,p_apellido) + p_apellido;
     apeYnom = apeYnom(p_nombre,p_apellido) + p_nombre;
     return apeYnom(p_nombre, p_apellido);
    }
    public double nomYape(String p_nombre, String p_apellido){
     String nomYape = nomYape(p_nombre,p_apellido) + p_nombre;
     nomYape = nomYape(p_nombre,p_apellido) + p_apellido;
     return nomYape(p_nombre, p_apellido);
    }
}
