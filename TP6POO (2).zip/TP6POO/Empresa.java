public class Empresa{
    public static void main(String args []){
        
        //instanciar un emplreado y mostrar
        Empleado e1 = new Empleado(40982473, "Caballero", "Fernando", 1998, 409824731, 5000, 2010);
        e1.mostrar();
        System.out.println("-------------------------------------------------");
        
        //instanciar una persona y mostrar
        Persona p1 = new Persona(42554560,"Barrios", "Maximiliano",2000);
        p1.mostrar();
        
    }
}
