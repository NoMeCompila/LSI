import java.util.*;
/**
 * description: clase para crear objetos de cargo semi-exclusivo
 * @author Caballero, Fernando
 * @version 1.0
 */
public class SemiExclusivo extends Cargo{
    //atributos
    private int horasDeInvestigacion;
    
    //costructores
    public SemiExclusivo(String p_nombre, double p_sueldoBasico, int p_anioIngreso, int p_horasDeDocencia, int p_horasDeInvestigacion){
        super(p_nombre,p_sueldoBasico,p_anioIngreso,p_horasDeDocencia);
        this.setHorasDeInvestigacion(p_horasDeInvestigacion);
    }
    
    //setters
    private void setHorasDeInvestigacion(int p_horasDeInvestigacion){
        this.horasDeInvestigacion=p_horasDeInvestigacion;
    }
    
    //getters
    public int getHorasDeInvestigacion(){
        return this.horasDeInvestigacion;
    }
    
    //metodos
    /**
     * Descripcion: calcula cuanto tiempo el profesor ejerció el cargo
     * @return f.get(Calendar.YEAR) - this.getAnioIngreso(); 
     */
    public int antgüedad(){
        Calendar f = new GregorianCalendar();
        return f.get(Calendar.YEAR) - this.getAnioIngreso();        
    }
    
    /**
     * Descripcion: calcula el sueldo adicional de un profesor en funcion a su antigüedad en un cargo
     * @return (this.getSueldoBasico() * 0.1) * this.Antgüedad(); 
     */
    private double adicionalXAntiguedad(){
        return (this.getSueldoBasico() * 0.01) * this.antgüedad(); 
    }
    
    /**
     * Descripcion: le suma al sueldo basico del profesor su adicional correspondiente
     * @return this.getSueldoBasico() + this.adicionalXAntiguedad();
     */    
    public double sueldoDelCargo(){
        return this.getSueldoBasico() + this.adicionalXAntiguedad();
    }
    
    /**
     * Descripcion: muestra los datos del cargo y saldo
     */    
    public void mostrarCargo(){
        super.mostrarCargo();
        System.out.println("----Cargo de caracter SemiExclusivo----");
        System.out.println("Horas investigación: "+this.getHorasDeInvestigacion());
    }
}
