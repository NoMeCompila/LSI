public class Alumno extends Persona{
   
   //atributos
   private  int     lu;   
   private  double   not1;
   private  double   not2;
   
   //getters
   public int getLu(){
       return this.lu;
   }
   

   
   public double getNot1(){
       return this.not1;
   }
    public double getNot2(){
      return this.not2;
   }
   //setters
   private void setLu(int p_lu){
       this.lu = p_lu;
   }
   

   

   
   private void setNot1(double p_not1){
       this.not1 = p_not1;
   }
   
    private void setNot2(double p_not2){
       this.not2 = p_not2;
   }
   //constructor
   public Alumno(int p_dni, String p_nom, String p_ape,int p_anio, int p_lu, double p_not1, double p_not2){
       super(p_dni,p_nom,p_ape,p_anio);
       this.setLu(p_lu);
       this.setNot1(p_not1);
       this.setNot2(p_not2);
   }
   //metodos

   
   public double promedio(){
      double acum = this.getNot1() + this.getNot2();
      double prom = acum/2;
      return prom;
   }
   
   public boolean aprueba(){
       if( this.promedio() > 6.0){
           return true;
       }else{
           return false;
       }
   }
   
   public String leyendaAprueba(){
       if(this.aprueba()==true){
           return "APROBADO";
       }else{
           return "DESAPROBADO";
       }
   }
   public String nomYape(){
       return super.getNombre()+" "+super.getApellido();
    }
    
   public void mostrar(){
       super.mostrar();
       System.out.println("LU: "+this.getLu());
       System.out.println("Notas: "+this.getNot1()+"-"+this.getNot2());
       System.out.println("Promedio: "+this.promedio());
       System.out.println(this.leyendaAprueba());
   }
}
