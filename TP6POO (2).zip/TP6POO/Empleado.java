import java.util.*;
//clase Empleado
public class Empleado extends Persona{
    //Atributos
    private long cuil;
    private double sueldoBasico;
    private int anioIngreso;
    //getters
    public long getCuil(){
        return this.cuil;
    }

    public double getSueldoBasico (){
        return this.sueldoBasico;
    }

    public int getAnioIngreso (){
        return this.anioIngreso;
    }
    //setters
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }

    private void setSueldoBasico(double p_sueldoBasico){
        this.sueldoBasico = p_sueldoBasico;
    }

    private void setAnioIngreso(int p_anioIngreso){
        this.anioIngreso = p_anioIngreso;
    }
 //constructor
    public Empleado(int p_dni,String p_nombre, String p_apellido, int p_anioNac, long p_cuil,double p_sueldoBasico,int p_anioIngreso){
        super(p_dni,p_nombre,p_apellido,p_anioNac);
        setCuil(p_cuil);
        setSueldoBasico(p_sueldoBasico);
        setAnioIngreso(p_anioIngreso);
    }
    //metodos
    public String apeYnom(){
        return super.getApellido()+" "+super.getNombre();
    }

    public String nomYape(){
        return this.getNombre()+" "+this.getApellido();
    }
    
    public int antiguedad(){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);
        int antiguedad = anioHoy - this.anioIngreso;
        return antiguedad;
    }
    
    public double descuento(){
        double desc = (this.getSueldoBasico() * 0.2) - 12;
        return desc;
    }
    
    public double adicional(){
        double adi = 0;
        if(this.antiguedad() < 2){
             adi =(this.sueldoBasico * 0.2);
            }else if((this.antiguedad() >= 2 )&&(this.antiguedad() < 10)){
                      adi = (this.sueldoBasico * 0.4);
                  }else if(this.antiguedad() >= 10){
                            adi = (this.sueldoBasico * 0.6);
            }  
        return adi;
    }
    
    public double saldoNeto(){
        double neto = this.getSueldoBasico() + this.adicional() - this.descuento();
        return neto;
        
    }
    
    
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYape());
        System.out.println("CUIL: "+this.getCuil()+" Antigüedad: "+this.antiguedad()+" años.");
        System.out.println("Saldo neto: U$D "+this.saldoNeto());
    }
    public String mostrarLinea(){
        super.mostrar();
        return this.getCuil() + "\t" + "Antigüedad: " +this.antiguedad() + "U$D " + this.saldoNeto();
    }
}
