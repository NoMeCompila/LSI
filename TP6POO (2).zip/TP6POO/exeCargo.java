public class exeCargo{
   public static void main(String args []){
       Cargo c1 = new Cargo("JTP-Programación OO", 800.0,2009,10);
       c1.mostrarCargo();
       
       
       System.out.println("\n");
       SemiExclusivo se1 = new SemiExclusivo("JTP-Paradigmas y Lenguajes",900.0,2005,10,10);     
       se1.mostrarCargo();
       
       
       System.out.println("\n");
       Exclusivo e1 =  new Exclusivo("JTP-AEDII",1000,2000,10,10,10);
       e1.mostrarCargo();
   }
}
