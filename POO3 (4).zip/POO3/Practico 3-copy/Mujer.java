/**
 * Descripcion: esta clase genera objetos de la clase  Mujer y ademas se puede visualizar en pantalla
 * sus datos 
 * @author (Cabellero, Fernando) 
 * @version (1) Fecha: 31/08/2019
 */
public class Mujer{
    //atributos
    private String nombre;
    private String apellido;
    private int edad;
    private String estadoCivil;
    private Hombre esposo;
   
   //setters
   /**
    * Descripcion: setter para el atributo  nombre
    * @param String p_nombre
    */
   private void setNombre(String p_nombre){
       this.nombre=p_nombre;
   }
    
   /**
    * Descripcion: setter para el atributo apellido 
    * @param String p_apellido
    */
   private void setApellido(String p_apellido){
       this.apellido=p_apellido;
   }
   /**
    * Descripcion: setter para el atributo  edad
    * @param int p_edad
    */
    private void setEdad(int p_edad){
       this.edad=p_edad;
   }
   /**
    * Descripcion: setter para el atributo estado civil 
    * @param String p_estadoCivil
    */
   private void setEstadoCivil(String p_estadoCivil){
       this.estadoCivil=p_estadoCivil;
   }
   
   /**
    * Descripcion: este metodo permite establecer un vinculo conyugal con una pareja
    * @param Hombre p_esposo
    */
   private void setEsposo(Hombre p_esposo){
       this.esposo=p_esposo;
   }
   
   //setters
   /**
    * Descripcion: getter para el atributo nombre
    * @return String nombre
    */
   public String getNombre(){
       return this.nombre;
   }
    
    /**
    * Descripcion: getter para el atributo apellido
    * @return String apellido
    */
   public String getApellido(){
       return this.apellido;
   }
    
    /**
    * Descripcion: getter para el atributo edad
    * @return int edad
    */
   public int getEdad(){
       return this.edad;
   }
    
    /**
    * Descripcion: getter para el atributo estado civil
    * @return String estado civil
    */
   public String getEstadoCivil(){
       return this.estadoCivil;
   }
   
   /**
    * Descripcion:  getter para el atributo esposa
    * @return Hombre esposo;
    */
   private Hombre getEsposo(){
       return this.esposo;
   }
    
    //constructores
    /**
     * Descripcion: constructor de objetos de la clase Mujer
     * @param String p_nombre, String p_apellido, int edad
     */
   public Mujer(String p_nombre, String p_apellido, int p_edad){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEstadoCivil("Soltera");
   }
    
   /**
     * Descripcion: constructor de objetos de la clase Mujer
     * @param String p_nombre, String p_apellido, int edad
     */
   public Mujer(String p_nombre, String p_apellido, int p_edad, Hombre p_esposo){
        this.setNombre(p_nombre);
        this.setApellido(p_apellido);
        this.setEdad(p_edad);
        this.setEstadoCivil("Soltera");
        this.setEsposo(p_esposo);
   }
    
   //metodos
   
   /**
    * Descripcion: este metodo permite crear una relacion conyugal con su pareja
    */
   public void casarseCon(Hombre p_esposo){
       if((this.getEsposo()==null)&&(p_esposo.getEstadoCivil()!= "casado")){
           this.setEsposo(p_esposo);
           p_esposo.casarseCon(this);
           this.setEstadoCivil("casada");
       }
   } 
    
    
   public void divorcio(Hombre p_esposo){
        if ((this.getEsposo() == p_esposo)&&( p_esposo.getEstadoCivil() == "casado")){
        this.setEstadoCivil("Divorciada");
        p_esposo.divorcio(this);
        this.setEsposo(null);
        }
    }
    
    
   /**
    * Descripcion: este metodo permite mostrar en pantalla los datos de un objeto clase mujer 
    */
   
   public void datos(){
       System.out.println(this.getNombre()+" "+this.getApellido()+" de "+this.getEdad()+" años");
   }    
   
   /**
    * Descripcion: permite obtener el estado civil del objeto
    */
   
   public void mostrarEstadoCivil(){
       System.out.println(this.getEstadoCivil());
   }
   
   /**
    * Descripcion: permite mostrar en pantalla con quien esta casado el objeto de ser asi el caso
    */
   public void casadoCon(){
       if(this.getEstadoCivil()=="casada"){
           System.out.println(this.getNombre()+" "+this.getApellido()+" de"+this.getEdad()+
           " años esta casada con "+this.getEsposo().getNombre()+" "
           +this.getEsposo().getApellido()+" de "+this.getEsposo().getEdad()+" años");
       }else 
           System.out.println(" No esta casada");
   } 
}

