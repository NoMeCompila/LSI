/**
 * Descripcion: esta clase permite crear objetos de la clase Empleado, mostrar en pantalla sus datos
 * y a demas saber si es o no su aniversario
 * @version (1) fecha: 01/09/2019
 */
import java.util.*;
//clase Empleado
public class Empleado{
    //Atributos
    private long cuil;
    private String ape;
    private String nom;
    private double sueldoBasico;
    private Calendar fechaIngreso;
    //getters
    /**
     * Descripcion: getter para el atributo cuil
     * @return long cuil
     */
    public long getCuil(){
        return this.cuil;
    }
    /**
     * Descripcion: getter para el atributo ape (apellido)
     * @return String ape 
     */
    public String getApe(){
        return this.ape;
    }
    /**
     * Descripcion: getter para el atributo nom (nombre)
     * @return String  nom
     */
    public String getNom(){
        return this.nom;
    }
    /**
     * Descripcion: getter para el atributo sueldoBasico
     * @return double sueldoBasico
     */
    public double getSueldoBasico (){
        return this.sueldoBasico;
    }
    /**
     * Descripcion: getter para el atributo anioIngreso (anio de ingreso del empleado)
     * @return int fechaIngreso.get(Calendar.YEAR)
     */
    public int getAnioIngreso(){
        return this.fechaIngreso.get(Calendar.YEAR);
    }
    /**
     * Descripcion: getter para el atributo fechaIngreso
     * @return Calendar fechaIngreso
     */
    public Calendar getFechaIngreso(){
        return this.fechaIngreso;
    }
    
    //setters
    /**
     * Descripcion: setter para el atributo cuil
     * @param long p_cuil
     */
    private void setCuil(long p_cuil){
        this.cuil = p_cuil;
    }
    /**
     * Descripcion: setter para el atributo ape
     * @param String p_ape
     */
    private void setApe(String p_ape){
        this.ape = p_ape;
    }
    /**
     * Descripcion: setter para el atributo nom
     * @param String p_nom
     */
    private void setNom(String p_nom){
        this.nom = p_nom;
    }
    /**
     * Descripcion: setter para el atributo sueldoBasico
     * @param double p_sueldoBasico
     */
    private void setSueldoBasico(double p_sueldoBasico){
        this.sueldoBasico = p_sueldoBasico;
    }
    /**
     * Descripcion: setter para el atributo fechaIngreso
     * @param int p_anio
     */
    private void setFechaIngreso (int p_anio){
     Calendar fecha = new GregorianCalendar();
     fecha.set(p_anio, 1, 2);       //una fecha cualquiera
     this.fechaIngreso = fecha;
    }
    //constructor
    /**
     * Descripcion: metodo constructor para instanciar objetos de la clase Empleado
     * @param long p_cuil,String p_ape,String p_nom,double p_sueldoBasico,int p_anioIngreso
     */
    public Empleado(long p_cuil,String p_ape,String p_nom,double p_sueldoBasico,int p_anioIngreso){
        this.setCuil(p_cuil);
        this.setApe(p_ape);
        this.setNom(p_nom);
        this.setSueldoBasico(p_sueldoBasico);
        this.setFechaIngreso(p_anioIngreso);
    }
    /**
     * Descripcion: metodo constructor sobrecargado para instanciar objetos de la clase Empleado
     * @param long p_cuil, String p_apellido, String p_nombre, double p_importe, Calendar p_fecha
     */
    public Empleado(long p_cuil, String p_apellido, String p_nombre, double p_importe, Calendar p_fecha){
        this.setCuil (p_cuil);
        this.setApe(p_apellido);
        this.setNom(p_nombre);
        this.setSueldoBasico (p_importe);
        this.setFechaIngreso(p_fecha.YEAR);
    }
    //metodos
    /**
     * Descripcion: este metodo permite devolver en formato de cadena el apellido y nombre de un
     * empleado
     * @return retorna un String con el nombre y apellido de un empleado
     */
    public String apeYnom(){
        return this.getApe()+" "+this.getNom();
    }
    /**
     * Descripcion: este metodo permite devolver en formato de cadena el nombre y apellido de un
     * empleado
     * @return retorna un String con el apellido y nombre de un empleado
     */
    public String nomYape(){
        return this.getNom()+" "+this.getApe();
    }
    /**
     * Descripcion: permite saber el teimpo que estuvo trabajando un empleado en la empresa
     * @return devuelve un entero antigüedad
     */
    public int antiguedad(){
        Calendar fechaHoy = new GregorianCalendar();
        int anioHoy = fechaHoy.get(Calendar.YEAR);      
        return (anioHoy - this.getAnioIngreso());
    }
    /**
     * Descripcion:  permite saber el descuento de sueldo de cada empleado
     * @return double desc
     */
    public double descuento(){
        double desc = (this.getSueldoBasico() * 0.2) - 12;
        return desc;
    }
    /**
     * Descripcion: permite determinar el aumento de sueldo de cada empleado segun su antigüedad
     * @ return  double adi
     */
    public double adicional(){
        double adi = 0;
        if(this.antiguedad() < 2){
             adi =(this.sueldoBasico * 0.2);
            }else if((this.antiguedad() >= 2 )&&(this.antiguedad() < 10)){
                      adi = (this.sueldoBasico * 0.4);
                  }else if(this.antiguedad() >= 10){
                            adi = (this.sueldoBasico * 0.6);
            }  
        return adi;
    }
    /**
     * Descripcion:  permite saber el sueldo neto de cada empleado
     * @return double neto
     */
    public double saldoNeto(){
        double neto = this.getSueldoBasico() + this.adicional() - this.descuento();
        return neto;
        
    }
    
    /**
     * Descripcion: permite visualizar en pantalla los datos de un empleado 
     */
    public void mostrar(){
        System.out.println("Nombre y Apellido: "+this.nomYape());
        System.out.println("CUIL: "+this.getCuil()+" Antigüedad: "+this.antiguedad()+" años.");
        System.out.println("Saldo neto: U$D "+this.saldoNeto());
    }
    /**
     * Descripcion: permite visualizar en pantalla los datos de un empleado pero en una sola linea
     */    
    public void mostrarLiena(){
        System.out.println(this.getCuil() + "\t" + this.apeYnom() + " ........... " + "U$D " 
        + this.saldoNeto());
    }
    
    /**
     * Descripcion: permite saber si es o no el aniversario de un empleado
     * @return boolean
     */
    public boolean  esAniversario(){
        Calendar fechaHoy = new GregorianCalendar();
        return ((fechaHoy.get(Calendar.DATE) == this.getFechaIngreso().get(Calendar.DATE)) && 
        (fechaHoy.get(Calendar.MONTH)+1 == this.getFechaIngreso().get(Calendar.MONTH)));
    }
    /**
     * Descripcion: muestra en pantalla si es o no el aniversario de un empleado
     */
    
    public void aniversario(){
        if(esAniversario()){
            System.out.println("Es el aniversario de "+this.nomYape()+"!!! FELICIDADES");
        }else 
            System.out.println("No es el aniversario de "+this.nomYape());
    }
}
