/**
 * Descripcion: esta clase permite generar objetos de la clase caja de ahoora asi como tambien 
 * administrar la cuenta de una persona titular
 * 
 * @author (Caballero, Fernando) 
 * @version (1) Fecha: 30/08/2019
 */
public class CajaDeAhorro{
    //atributos
    private int     nroCuenta;
    private double  saldo;
    private int     extraccionesPosibles;
    private Persona titular;
    
    //setters 
        /**
     * Descripcion: setter para el atributo nroDeCuenta
     * @param recibe un int p_nroDeCuenta
     */    
    private void setNroDecuenta (int p_nroDeCuenta){
        this.nroCuenta=p_nroDeCuenta;
    }
    
    /**
     * Descripcion: setter para el atributo saldo
     * @param recibe un double p_saldo
     */
    private void  setSaldo (double p_saldo){
        this.saldo = p_saldo;
    }
    
     /**
     * Descripcion: setter para el atributo extarccionesPosibles
     * @param recibe un int p_extarccionesPosibles 
     */
    private void  setExtarccionesPosibles (int p_extraccionesPosibles){
        this.extraccionesPosibles = p_extraccionesPosibles;
    }
    
     /**
     * Descripcion: setter para el atributo titular
     * @param recibe un Persona p_titular
     */
    private void  setTitular (Persona p_titular){
        this.titular = p_titular;
    }
    //getters
     /**
     * Descripcion: getter para el atributo nroDecuenta
     * @return retorna un int nroDecuenta
     */
    public int getNroDeCuenta(){
        return this.nroCuenta; 
    }
     
    /**
     * Descripcion: getter para el atributo saldo
     * @return retorna un double saldo
     */
    public double getSaldo(){
        return this.saldo; 
    }
    
     /**
     * Descripcion: getter para el atributo extraccionesPosibles
     * @return retorna un int extraccionesPosibles
     */
    public int getExtraccionesPosibles(){
        return this.extraccionesPosibles; 
    }  
     /**
     * Descripcion: getter para el atributo titular
     * @return retorna un Persona Titular
     */
    public Persona getTitular(){
        return this.titular; 
    }
    
    //constructores
    /**
     * Descripcion: constructor de objetos de la clase CajaDeAhorro
     * @param int p_nroDeCuenta, Persona p_titular
     */
    public CajaDeAhorro(int p_nroDeCuenta, Persona p_titular){
        this.setNroDecuenta(p_nroDeCuenta);
        this.setTitular(p_titular);
        this.setSaldo(0);
        this.setExtarccionesPosibles(10);
    }
     
    /** Descripcion: constructor de objetos de la clase CajaDeAhorro
     * @param int p_nroDeCuenta,
     */
    
    public CajaDeAhorro(int p_nroDeCuenta, Persona p_titular, double p_saldo){
        this.setNroDecuenta(p_nroDeCuenta);
        this.setTitular(p_titular);
        this.setSaldo(p_saldo);
        this.setExtarccionesPosibles(10);
    }
    
    //metodos
    
  /**
  * Descripcion: este metodo permite depositar dinero de una caja de ahorro
  * @param recibe un double p_importe
  */
  public void depositar(double p_importe){
       this.setSaldo(this.getSaldo() + p_importe);
  }
  
  /**
   * Descripcion: este metodo permite saber si un titular puede extraer o no fondos de su caja de 
   * ahorro
   * @param recibe un doble p_imoporte
   * @return retorna un boolean
   */
  
  public boolean puedeExtraer(double p_importe){
      return ((p_importe < this.getSaldo()) && (this.getExtraccionesPosibles() > 0));
  }
  
  /**
  * Descripcion: este metodo permite extraer dinero de una caja de ahorro y descontar 
  * en 1 la cantidad de extracciones posibles
  * @param recibe un double p_importe
  */
 
   public void extraccion(double p_importe, int p_extraccionesPosibles){
      this.setSaldo(this.getSaldo() - p_importe);
      this.setExtarccionesPosibles(p_extraccionesPosibles--); 
  }
  
  
  /**
   * Descripcion: estemetodo permite coordinar al metodo puedeExtraer() con extraccion() y realizar 
   * la extraccion o en su defecto mostrar por pantalla el motiv o por el cual no se pudo completar 
   * la operacion
   * 
   * @param recibe un double p_importe
   */
  public void extraer(double p_importe){
      if(this.puedeExtraer(p_importe) && (this.getExtraccionesPosibles() >  0) &&
      (this.getSaldo() > p_importe)){
           this.setSaldo(this.getSaldo() - p_importe);
      }else if(this.puedeExtraer(p_importe) && (this.getExtraccionesPosibles()  == 0) &&
      (this.getSaldo() > p_importe)){
           System.out.println("No tiene habilitadas mas extracciones!");
      }else if(this.puedeExtraer(p_importe) && (this.getExtraccionesPosibles() >  0) &&
      (this.getSaldo() < p_importe)){
           System.out.println("No puede extraer mas que el saldo!");
      }
  }
  
  /**
   * Descripcion: permite mostrar en pantalla los datos de un titular de cada de ahorro
   */
  public void mostrar(){
      System.out.println("      CAJA DE AHORRO");
      System.out.println("Nro. Cuenta: "+this.getNroDeCuenta()+" - Saldo: U$D: "+this.getSaldo());
      System.out.println("Titular: "+this.getTitular().nomYApe());
      System.out.println("Extracciones: "+this.getExtraccionesPosibles());
  }
}