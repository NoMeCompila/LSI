import java.util.*;
public class Banco{
    public static void main(String args[]){
        
        Scanner teclado = new Scanner(System.in);
        System.out.print("\nIngrese el anio de nacimiento de la parsona: ");
        int p_anio=teclado.nextInt();
        System.out.print("\nIngrese el mes de nacimiento de la parsona: ");
        int p_mes=teclado.nextInt();
        System.out.print("\nIngrese el dia de nacimiento de la parsona: ");
        int p_dia=teclado.nextInt();
        Calendar fecha = new GregorianCalendar(p_anio,p_mes,p_dia);
        //muestro la fecha de nacimiento;
        System.out.print("\n\n\t FECHA DE NACIMIENTO: "
                        +fecha.get(Calendar.DATE)+"/"
                        +fecha.get(Calendar.MONTH)+"/"
                        +fecha.get(Calendar.YEAR));
        Persona p1 = new Persona( 35123456, "Juan" , "Perez", fecha);
        CajaDeAhorro caja = new CajaDeAhorro(6969,p1,5000);
        
        
        caja.mostrar();
        caja.extraer(300);
        caja.mostrar();
        
        CuentaCorriente cc= new CuentaCorriente(6969,p1,1205);
        cc.mostrar();
    }
}
