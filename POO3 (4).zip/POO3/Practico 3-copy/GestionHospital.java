import java.util.Scanner;
public class GestionHospital{
    public static void main(String args[]){
        
        
        Scanner teclado = new Scanner(System.in);
        teclado.useDelimiter("\n");
        System.out.println("\nIngrese nombre Hospital");
        String nombreH = teclado.next();
        System.out.println("\nIngrese nombre Director del Hospital");
        String nombreD = teclado.next();
        Hospital hospi = new Hospital(nombreH, nombreD);
        System.out.print("\nIngrese el numero de historia Clinica: ");
        int p_historiac = teclado.nextInt();
        System.out.print("\nIngrese el nombre del paciente: ");
        String p_nom = teclado.next();
        System.out.print("\nIngrese el domicilio del paciente: ");
        String p_dom = teclado.next();
        Localidad loc1 = new Localidad("Santo Tome","Corrientes");  
        Localidad loc2 = new Localidad("Corrientes","Corrientes Capital");
        Paciente p1 = new Paciente (p_historiac, p_nom, p_dom, loc1, loc2);
        hospi.consultaDatosFiliatorios(p1);
        

   }
}
