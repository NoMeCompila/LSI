public class RegistroCivil{
    public static void main(String args[]){
        
        
        Hombre H = new Hombre("Juan","Perez",27);
        Mujer M = new Mujer("Maria","Gomez",25);
        Mujer M2 = new Mujer("Mariana","ramirez",19);
        
        
        
        
        
         
        H.casarseCon(M);
       H.casarseCon(M2);
        
       M.datos();
       System.out.println(M.getEstadoCivil());
       H.datos();
       System.out.println(H.getEstadoCivil());
       
       System.out.println(H.getEstadoCivil());
       System.out.println(M2.getEstadoCivil());
        
    }
}
