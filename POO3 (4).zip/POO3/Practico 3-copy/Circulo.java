import java.lang.Math;
import java.util.Random;
/**
 * Descripcion: permite crear objetos de tipo circulo y desplazarlos
 * 
 * @author (Caballero, Fernando) 
 * @version (1) Fecha: 29/08/2019
 */
public class Circulo{
    //atributos
    private double radio;
    private Punto centro;
    
    //setters
   /**
     * Descripcion: setter para el artributo radio
     * @param recibe un double p_radio
    */
    private void setRadio(double p_radio){
        this.radio  =   p_radio;
   }
    
    /**
     * Descripcion: setter para el atributo centro
     * @param recibe un aprametro de tipo Punto p_centro
     */
    private void setCentro(Punto p_centro){
        this.centro =    p_centro;
   }
    
    //getters
    
    /**
     * Descripcion: getter para el atributo radio
     * @return retorna un double radio
     */
    public double getRadio(){
        return this.radio;
   }
    
    /**
     * Descripcion: getter para el atributo centro
     * @return retorna un double de tipo Punto centro
     */
    public Punto getCentro(){
        return this.centro;
   }
    
    //constructor
    /**
   * Descripcion: costructor para la clase Circulo
   * @param recibe un double pradio y un atributo de clase Punto
   */
       
   public Circulo(){
        this.setRadio(0);
        this.setCentro(new Punto ());
   }

   /**
   * Descripcion: costructor sobrecargado para la clase Circulo
   */
   public Circulo(double p_radio, Punto p_centro){
        this.setRadio(p_radio);
        this.setCentro(p_centro);
   }
    
   /**
   * Descripcion: permite desplazar un circulo desde su centro sin modificar su radio
   * @param recibe 2 parametros double p_dx y double p_dy
   */
   public void desplazar(double p_dx, double p_dy){
        this.getCentro().desplazar(p_dx,p_dy);
   }
    
   /**
     * Descripcion: metodo que permite saber el perimetro de un circulo
     * @return retorna un double 
     */
    
    public double perimetro(){
        return this.getRadio() * 2 * Math.PI;  
   }
    
    /**
     * Descripcion: metodo que permite conocer la superficie de un circulo 
     * @return double
     */
    
    public double superficie(){
        return Math.PI * Math.pow(this.getRadio(), 2);
   }
    
   /**
   * Descripcion: Permite mostrar en pantalla las caracteristicas de un circulo
   */
    
   public void caracteristicas(){
        System.out.println("*******CiRCULO *******");
        System.out.println("Centro: "+this.getCentro().coordenadas()+" - Radio: "+this.getRadio());
        System.out.println("Superficie: "+ this.superficie()+" - Perimetro: "+this.perimetro()); 
   }
    
   /**
    * Descripcion: permite calcular la distancia entre 2 circulos teniendo como referencia su centro
    * @return retorna un double que sera la distancia entre los 2 circulos
    */
    
   public double distanciaA(Circulo p_circulo){
       return Math.sqrt( (Math.pow(this.centro.getX() - p_circulo.centro.getX(),2)) +  (Math.pow(this.centro.getY() - p_circulo.centro.getY(),2)));
   }
   
   /**
    * Descripcion: permite saber cual es el mayor de 2 circulos
    * @return retorna un tipo Circulo el ams grande
    */
   /*public Circulo elMayor(Circulo p_circulo){
      Circulo cir = new Circulo(this.getRadio(),this.getCentro());
       
      if(this.superficie() > p_circulo.superficie() ){
           return cir;
      }else 
           return p_circulo;
     
   }*/
   
   public Circulo elMayor(Circulo p_circulo){
      if(this.superficie() > p_circulo.superficie() ){
           return this;
      }else if(this.superficie() < p_circulo.superficie()){
           return p_circulo;
      }else return null;
   }
}
