
/**
 * Descripcion: en esta clase se pueden crearobjetos de la clase Hospital y mostrar los datos en pantalla
 * 
 * @author (Caballero,Fernando) 
 * @version (1) Fecha: 31/08/2019
 */
public class Hospital{
    //atributos
    private String nombreHospital;
    private String nombreDoctor;
    //setters
    /**
     * Descripcion: setter para el atributo nombreHospital
     * @param String String p_nombreHospital
     */
    private void setNombreHospital(String p_nombreHospital){
        this.nombreHospital = p_nombreHospital;
    }
     /**
     * Descripcion: setter para el atributo nombreDoctor
     * @param String p_nombreDoctor
     */
    
    private void setNombreDoctor(String p_nombreDoctor){
        this.nombreDoctor = p_nombreDoctor;
    }
    
    //getters
    /**
     * Descripcion: getter para el atributo
     * @return String nombreDoctor
     */
    public String getNombreHospital(){
        return this.nombreHospital;
    }
     /**
     * Descripcion: getter para el atributo
     * @return String nombreDoctor
     */
    public String getNombreDoctor(){
        return this.nombreDoctor;
    }
    
    //cosntructor
    /**
     * Descripcion: constructor de la clase Hospital
     * @param 
     */
    
    public Hospital(String p_nombreHospital, String p_nombreDoctor){
        this.setNombreHospital(p_nombreHospital);
        this.setNombreDoctor(p_nombreDoctor);
    }
    
    //metodos
    /**
     * Descripcion: muestra en pantalla los datos de un afiliado
     * @param Paciente p_paciente
     */
    
    public void consultaDatosFiliatorios(Paciente p_paciente){
        System.out.println("Hospital: "+this.getNombreHospital()+"\tDirector: "+this.getNombreDoctor());
        System.out.println("------------------------------------------------");
        System.out.println("Paciente: "+p_paciente.getNombre()+"\tHistoria Clinica: "+p_paciente.getHistoriaClinica()+"\tDomicilio: "
        +p_paciente.getDomicilio());
        System.out.println("Localidad: "+p_paciente.getLocalidadNacido()+"\tProvincia: "+p_paciente.getLocalidadVive());
    }
}
